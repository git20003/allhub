<?php
	require_once("core.php");
	header("location: user_authentication.php?".$url);
?>